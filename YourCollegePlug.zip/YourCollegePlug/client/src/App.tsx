import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";

import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import Dashboard from "@/pages/dashboard";
import DiscoverPage from "@/pages/DiscoverPage";
import ConnectPage from "@/pages/ConnectPage";
import EssayFeedbackPage from "@/pages/EssayFeedbackPage";
import Layout from "@/components/layout";

function Router() {
  return (
    <Switch>
      <Route path="/auth" component={AuthPage} />
      
      <ProtectedRoute path="/" component={Dashboard} />
      <ProtectedRoute path="/discover" component={DiscoverPage} />
      <ProtectedRoute path="/connect" component={ConnectPage} />
      <ProtectedRoute path="/essays" component={EssayFeedbackPage} />
      <ProtectedRoute path="/colleges" component={() => (
        <Layout>
          <div className="p-6">
            <h1 className="text-2xl font-bold mb-4">My Colleges</h1>
            <p>The college list page will be implemented next.</p>
          </div>
        </Layout>
      )} />
      
      <ProtectedRoute path="/calendar" component={() => (
        <Layout>
          <div className="p-6">
            <h1 className="text-2xl font-bold mb-4">Application Calendar</h1>
            <p>The application calendar will be implemented next.</p>
          </div>
        </Layout>
      )} />

      <ProtectedRoute path="/tasks" component={() => (
        <Layout>
          <div className="p-6">
            <h1 className="text-2xl font-bold mb-4">Application Tasks</h1>
            <p>The application tasks will be implemented next.</p>
          </div>
        </Layout>
      )} />

      <ProtectedRoute path="/resources" component={() => (
        <Layout>
          <div className="p-6">
            <h1 className="text-2xl font-bold mb-4">Resources</h1>
            <p>College application resources will be implemented next.</p>
          </div>
        </Layout>
      )} />

      <ProtectedRoute path="/profile" component={() => (
        <Layout>
          <div className="p-6">
            <h1 className="text-2xl font-bold mb-4">Profile</h1>
            <p>Student profile page will be implemented next.</p>
          </div>
        </Layout>
      )} />

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
