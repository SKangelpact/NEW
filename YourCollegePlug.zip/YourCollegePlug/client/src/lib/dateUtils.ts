import { format, isToday, isTomorrow, isThisWeek, isThisMonth, addDays, differenceInDays } from 'date-fns';

/**
 * Format a date for display in the deadlines list
 * @param dateString ISO date string
 * @returns Formatted date string
 */
export function formatDeadlineDate(dateString: string | Date): string {
  const date = new Date(dateString);
  
  if (isToday(date)) {
    return 'Today';
  }
  
  if (isTomorrow(date)) {
    return 'Tomorrow';
  }
  
  if (isThisWeek(date) && !isTomorrow(date) && !isToday(date)) {
    return format(date, 'EEEE'); // Day of week
  }
  
  if (isThisMonth(date) && !isThisWeek(date)) {
    return format(date, 'MMMM d'); // Month + day
  }
  
  return format(date, 'MMM d, yyyy'); // Full date
}

/**
 * Format a date with relative time information
 * @param dateString ISO date string
 * @returns Formatted date with relative time
 */
export function formatDeadlineWithRelativeTime(dateString: string | Date): string {
  const date = new Date(dateString);
  const today = new Date();
  const daysDiff = differenceInDays(date, today);
  
  let relativeInfo = '';
  
  if (daysDiff < 0) {
    relativeInfo = ' (Past due)';
  } else if (daysDiff === 0) {
    relativeInfo = ' (Today)';
  } else if (daysDiff === 1) {
    relativeInfo = ' (Tomorrow)';
  } else if (daysDiff <= 7) {
    relativeInfo = ` (${daysDiff} days left)`;
  }
  
  return `${format(date, 'MMM d, yyyy')}${relativeInfo}`;
}

/**
 * Get deadline urgency level based on date
 * @param dateString ISO date string
 * @returns 'high', 'medium', 'low', or 'past' urgency
 */
export function getDeadlineUrgency(dateString: string | Date): 'high' | 'medium' | 'low' | 'past' {
  const date = new Date(dateString);
  const today = new Date();
  const daysDiff = differenceInDays(date, today);
  
  if (daysDiff < 0) return 'past';
  if (daysDiff <= 3) return 'high';
  if (daysDiff <= 14) return 'medium';
  return 'low';
}

/**
 * Get color class based on deadline urgency
 * @param dateString ISO date string
 * @returns Tailwind CSS class for color
 */
export function getDeadlineColorClass(dateString: string | Date): string {
  const urgency = getDeadlineUrgency(dateString);
  
  switch (urgency) {
    case 'high':
      return 'bg-red-500';
    case 'medium':
      return 'bg-yellow-500';
    case 'low':
      return 'bg-blue-500';
    case 'past':
      return 'bg-gray-500';
    default:
      return 'bg-gray-500';
  }
}

/**
 * Get upcoming deadlines (today and future)
 * @param deadlines Array of deadline objects with date property
 * @returns Filtered array of upcoming deadlines
 */
export function getUpcomingDeadlines<T extends { date: string | Date }>(deadlines: T[]): T[] {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  return deadlines.filter(deadline => {
    const deadlineDate = new Date(deadline.date);
    deadlineDate.setHours(0, 0, 0, 0);
    return deadlineDate >= today;
  }).sort((a, b) => {
    return new Date(a.date).getTime() - new Date(b.date).getTime();
  });
}

/**
 * Get immediate deadlines (within next 7 days)
 * @param deadlines Array of deadline objects with date property
 * @returns Filtered array of immediate deadlines
 */
export function getImmediateDeadlines<T extends { date: string | Date }>(deadlines: T[]): T[] {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const nextWeek = addDays(today, 7);
  
  return deadlines.filter(deadline => {
    const deadlineDate = new Date(deadline.date);
    deadlineDate.setHours(0, 0, 0, 0);
    return deadlineDate >= today && deadlineDate <= nextWeek;
  }).sort((a, b) => {
    return new Date(a.date).getTime() - new Date(b.date).getTime();
  });
}

/**
 * Format the deadline date into a calendar-friendly object
 * @param dateString ISO date string
 * @returns Object with year, month, day properties
 */
export function getCalendarDate(dateString: string | Date): { year: number; month: number; day: number } {
  const date = new Date(dateString);
  return {
    year: date.getFullYear(),
    month: date.getMonth() + 1, // JavaScript months are 0-indexed
    day: date.getDate()
  };
}
