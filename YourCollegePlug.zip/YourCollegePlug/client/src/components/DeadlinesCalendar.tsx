import { useState } from 'react';
import { format, addMonths, subMonths, startOfMonth, endOfMonth, eachDayOfInterval, getDay, isSameMonth, isToday, isEqual, parseISO } from 'date-fns';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { Deadline } from '@shared/schema';

interface DeadlinesCalendarProps {
  deadlines: Deadline[];
}

export default function DeadlinesCalendar({ deadlines }: DeadlinesCalendarProps) {
  const [currentDate, setCurrentDate] = useState(new Date());
  
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const startDate = monthStart;
  const endDate = monthEnd;
  
  const dateFormat = "MMMM yyyy";
  const days = eachDayOfInterval({ start: startDate, end: endDate });
  
  const startDay = getDay(monthStart);
  
  // Add empty cells for days of the week before the first day of the month
  const blanks = Array.from({ length: startDay }, (_, i) => i);
  
  const previousMonth = () => {
    setCurrentDate(subMonths(currentDate, 1));
  };
  
  const nextMonth = () => {
    setCurrentDate(addMonths(currentDate, 1));
  };
  
  // Function to check if a date has any deadlines
  const getDeadlinesForDay = (day: Date) => {
    return deadlines.filter(deadline => {
      const deadlineDate = new Date(deadline.date);
      return isEqual(
        new Date(day.getFullYear(), day.getMonth(), day.getDate()),
        new Date(deadlineDate.getFullYear(), deadlineDate.getMonth(), deadlineDate.getDate())
      );
    });
  };
  
  // Function to determine the color class for a deadline indicator
  const getDeadlineColorClass = (deadline: Deadline) => {
    // Here we could implement logic to return different colors based on deadline type
    // For now, using a simple approach where non-completed = red, completed = primary
    return deadline.completed ? 'bg-primary-500' : 'bg-red-500';
  };

  return (
    <div className="bg-white shadow rounded-lg p-6 mb-6">
      <div className="flex justify-between mb-4">
        <h3 className="font-medium">{format(currentDate, dateFormat)}</h3>
        <div>
          <Button variant="ghost" size="icon" onClick={previousMonth} className="text-gray-400 hover:text-gray-500 p-1">
            <ChevronLeft className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" onClick={nextMonth} className="text-gray-400 hover:text-gray-500 p-1">
            <ChevronRight className="h-5 w-5" />
          </Button>
        </div>
      </div>
      
      {/* Calendar */}
      <div className="grid grid-cols-7 gap-px bg-gray-200 rounded overflow-hidden text-center">
        {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((day, i) => (
          <div key={i} className="bg-gray-50 p-2 text-xs font-medium text-gray-500">{day}</div>
        ))}
        
        {/* Blank days */}
        {blanks.map(i => (
          <div key={`blank-${i}`} className="bg-white p-2 text-sm"></div>
        ))}
        
        {/* Calendar days */}
        {days.map((day, i) => {
          const dayDeadlines = getDeadlinesForDay(day);
          const hasDeadlines = dayDeadlines.length > 0;
          
          return (
            <div 
              key={i} 
              className={cn(
                "p-2 text-sm",
                isSameMonth(day, currentDate) ? "bg-white" : "bg-gray-50 text-gray-400",
                isToday(day) ? "bg-primary-100" : "",
                hasDeadlines ? "rounded" : ""
              )}
            >
              <span className="block">{format(day, 'd')}</span>
              {hasDeadlines && (
                <div className="flex justify-center mt-1 space-x-1">
                  {dayDeadlines.slice(0, 2).map((deadline, i) => (
                    <span 
                      key={i}
                      className={cn("block w-2 h-2 rounded-full", getDeadlineColorClass(deadline))}
                    ></span>
                  ))}
                  {dayDeadlines.length > 2 && (
                    <span className="block w-2 h-2 rounded-full bg-gray-400"></span>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
      
      {/* Deadline List */}
      <div className="mt-4 space-y-3">
        {deadlines.length > 0 ? (
          deadlines
            .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
            .slice(0, 3)
            .map((deadline) => (
              <div key={deadline.id} className="flex items-start py-2 border-b border-gray-100">
                <div 
                  className={cn(
                    "flex-shrink-0 w-2 h-2 mt-1.5 rounded-full",
                    getDeadlineColorClass(deadline)
                  )}
                ></div>
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-900">{deadline.title}</p>
                  <p className="text-xs text-gray-500">
                    {format(new Date(deadline.date), 'MMM d')}
                    {deadline.description ? ` - ${deadline.description}` : ''}
                  </p>
                </div>
              </div>
            ))
        ) : (
          <div className="py-2 text-center text-sm text-gray-500">
            No upcoming deadlines. Add some to keep track of important dates.
          </div>
        )}
      </div>
      
      <Button variant="link" className="mt-4 text-primary-600 text-sm font-medium flex items-center hover:text-primary-700" asChild>
        <a href="/calendar">
          View all deadlines
          <ChevronRight className="h-4 w-4 ml-1" />
        </a>
      </Button>
    </div>
  );
}
