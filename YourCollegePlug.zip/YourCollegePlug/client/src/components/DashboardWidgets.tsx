import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Loader2, GraduationCap, Users, Calendar, FileText, Edit, Trash, Plus } from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { useAuth } from "@/hooks/use-auth";

// Widget types
export type WidgetType = 
  | "profile-completion" 
  | "college-stats" 
  | "upcoming-deadlines" 
  | "application-status" 
  | "counselor-notes"
  | "essay-progress"
  | "recent-activities";

interface WidgetConfig {
  id: string;
  type: WidgetType;
  title: string;
  size: "small" | "medium" | "large";
  settings?: Record<string, any>;
}

// Preset widget configurations
const WIDGET_PRESETS: Record<WidgetType, Omit<WidgetConfig, "id">> = {
  "profile-completion": {
    type: "profile-completion",
    title: "Profile Completion",
    size: "small"
  },
  "college-stats": {
    type: "college-stats",
    title: "My College List",
    size: "medium"
  },
  "upcoming-deadlines": {
    type: "upcoming-deadlines",
    title: "Upcoming Deadlines",
    size: "medium"
  },
  "application-status": {
    type: "application-status",
    title: "Application Status",
    size: "large"
  },
  "counselor-notes": {
    type: "counselor-notes",
    title: "Counselor Notes",
    size: "medium"
  },
  "essay-progress": {
    type: "essay-progress",
    title: "Essay Progress",
    size: "medium"
  },
  "recent-activities": {
    type: "recent-activities",
    title: "Recent Activities",
    size: "small"
  }
};

// Individual widget components
const ProfileCompletionWidget = () => {
  const { user } = useAuth();
  const completionPercentage = user?.profileCompleted || 0;

  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center">
        <span className="text-sm font-medium">Profile Completion</span>
        <span className="text-sm font-medium">{completionPercentage}%</span>
      </div>
      <div className="w-full bg-secondary h-2 rounded-full overflow-hidden">
        <div 
          className="bg-primary h-full rounded-full transition-all duration-500 ease-in-out"
          style={{ width: `${completionPercentage}%` }}
        />
      </div>
      <Button variant="outline" size="sm" className="w-full mt-2">
        Complete Your Profile
      </Button>
    </div>
  );
};

const CollegeStatsWidget = () => {
  // Mock data - would come from API in actual implementation
  const collegeStats = {
    total: 8,
    reach: 2,
    match: 4,
    safety: 2
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-4 gap-2 text-center">
        <div className="bg-secondary/30 p-2 rounded-md">
          <div className="text-2xl font-bold">{collegeStats.total}</div>
          <div className="text-xs text-muted-foreground">Total</div>
        </div>
        <div className="bg-red-100 dark:bg-red-900/20 p-2 rounded-md">
          <div className="text-2xl font-bold text-red-600 dark:text-red-400">{collegeStats.reach}</div>
          <div className="text-xs text-muted-foreground">Reach</div>
        </div>
        <div className="bg-yellow-100 dark:bg-yellow-900/20 p-2 rounded-md">
          <div className="text-2xl font-bold text-yellow-600 dark:text-yellow-400">{collegeStats.match}</div>
          <div className="text-xs text-muted-foreground">Match</div>
        </div>
        <div className="bg-green-100 dark:bg-green-900/20 p-2 rounded-md">
          <div className="text-2xl font-bold text-green-600 dark:text-green-400">{collegeStats.safety}</div>
          <div className="text-xs text-muted-foreground">Safety</div>
        </div>
      </div>
      <Button variant="outline" size="sm" className="w-full">
        <GraduationCap className="h-4 w-4 mr-2" />
        View College List
      </Button>
    </div>
  );
};

const UpcomingDeadlinesWidget = () => {
  // Mock data - would come from API in actual implementation
  const deadlines = [
    { id: 1, college: "Harvard University", type: "Early Action", date: "Nov 1, 2025" },
    { id: 2, college: "Stanford University", type: "Regular Decision", date: "Jan 5, 2026" },
    { id: 3, college: "MIT", type: "Early Action", date: "Nov 1, 2025" }
  ];

  return (
    <div className="space-y-3">
      {deadlines.map(deadline => (
        <div key={deadline.id} className="flex justify-between items-center border-b pb-2">
          <div>
            <div className="font-medium">{deadline.college}</div>
            <div className="text-sm text-muted-foreground">{deadline.type}</div>
          </div>
          <div className="text-sm font-medium">{deadline.date}</div>
        </div>
      ))}
      <Button variant="outline" size="sm" className="w-full">
        <Calendar className="h-4 w-4 mr-2" />
        View All Deadlines
      </Button>
    </div>
  );
};

const ApplicationStatusWidget = () => {
  // Mock data - would come from API in actual implementation
  const applications = [
    { id: 1, college: "Harvard University", status: "In Progress", lastUpdated: "2 days ago" },
    { id: 2, college: "Stanford University", status: "Not Started", lastUpdated: "N/A" },
    { id: 3, college: "MIT", status: "In Progress", lastUpdated: "Yesterday" },
    { id: 4, college: "University of Michigan", status: "Completed", lastUpdated: "1 week ago" }
  ];

  return (
    <div className="space-y-2">
      <div className="grid grid-cols-3 text-sm font-medium">
        <div>College</div>
        <div>Status</div>
        <div>Last Updated</div>
      </div>
      <div className="space-y-1">
        {applications.map(app => (
          <div key={app.id} className="grid grid-cols-3 text-sm py-2 border-b">
            <div>{app.college}</div>
            <div>
              <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium
                ${app.status === 'Completed' ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300' : 
                  app.status === 'In Progress' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300' : 
                  'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300'}`
              }>
                {app.status}
              </span>
            </div>
            <div className="text-muted-foreground">{app.lastUpdated}</div>
          </div>
        ))}
      </div>
      <Button variant="outline" size="sm" className="w-full mt-2">
        View All Applications
      </Button>
    </div>
  );
};

const CounselorNotesWidget = () => {
  // Mock data - would come from API in actual implementation
  const notes = [
    { id: 1, date: "May 15, 2025", note: "Discussed potential essay topics. Focus on community service experience." },
    { id: 2, date: "April 30, 2025", note: "Reviewed college list. Suggested adding 2 more safety schools." }
  ];

  return (
    <div className="space-y-3">
      {notes.map(note => (
        <div key={note.id} className="border-b pb-2">
          <div className="text-sm text-muted-foreground">{note.date}</div>
          <div className="text-sm mt-1">{note.note}</div>
        </div>
      ))}
      <Button variant="outline" size="sm" className="w-full">
        <Users className="h-4 w-4 mr-2" />
        Schedule Counselor Meeting
      </Button>
    </div>
  );
};

const EssayProgressWidget = () => {
  // Mock data - would come from API in actual implementation
  const essays = [
    { id: 1, title: "Common App Personal Statement", progress: 70 },
    { id: 2, title: "Why Harvard?", progress: 30 },
    { id: 3, title: "Community Impact", progress: 0 }
  ];

  return (
    <div className="space-y-3">
      {essays.map(essay => (
        <div key={essay.id} className="space-y-1">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium">{essay.title}</span>
            <span className="text-xs text-muted-foreground">{essay.progress}%</span>
          </div>
          <div className="w-full bg-secondary h-1.5 rounded-full overflow-hidden">
            <div 
              className="bg-primary h-full rounded-full transition-all duration-500 ease-in-out"
              style={{ width: `${essay.progress}%` }}
            />
          </div>
        </div>
      ))}
      <Button variant="outline" size="sm" className="w-full mt-2">
        <FileText className="h-4 w-4 mr-2" />
        View Essays
      </Button>
    </div>
  );
};

const RecentActivitiesWidget = () => {
  // Mock data - would come from API in actual implementation
  const activities = [
    { id: 1, activity: "Added Stanford to your college list", time: "2 hours ago" },
    { id: 2, activity: "Updated your GPA information", time: "Yesterday" },
    { id: 3, activity: "Scheduled a tour at University of Michigan", time: "3 days ago" }
  ];

  return (
    <div className="space-y-2">
      {activities.map(activity => (
        <div key={activity.id} className="text-sm border-b pb-2">
          <div>{activity.activity}</div>
          <div className="text-xs text-muted-foreground">{activity.time}</div>
        </div>
      ))}
    </div>
  );
};

// Widget renderer based on widget type
const WidgetRenderer = ({ widget }: { widget: WidgetConfig }) => {
  switch (widget.type) {
    case "profile-completion":
      return <ProfileCompletionWidget />;
    case "college-stats":
      return <CollegeStatsWidget />;
    case "upcoming-deadlines":
      return <UpcomingDeadlinesWidget />;
    case "application-status":
      return <ApplicationStatusWidget />;
    case "counselor-notes":
      return <CounselorNotesWidget />;
    case "essay-progress":
      return <EssayProgressWidget />;
    case "recent-activities":
      return <RecentActivitiesWidget />;
    default:
      return <div>Unknown widget type</div>;
  }
};

// Widget card component
export const WidgetCard = ({ 
  widget, 
  onEdit, 
  onDelete,
  isDragging = false 
}: { 
  widget: WidgetConfig; 
  onEdit: (id: string) => void;
  onDelete: (id: string) => void;
  isDragging?: boolean;
}) => {
  return (
    <Card className={`overflow-hidden ${isDragging ? 'opacity-50' : ''}`}>
      <CardHeader className="p-4 pb-0 flex flex-row items-center justify-between space-y-0">
        <CardTitle className="text-md font-medium">{widget.title}</CardTitle>
        <div className="flex space-x-1">
          <Button variant="ghost" size="icon" onClick={() => onEdit(widget.id)}>
            <Edit className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" onClick={() => onDelete(widget.id)}>
            <Trash className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-4">
        <WidgetRenderer widget={widget} />
      </CardContent>
    </Card>
  );
};

// Add Widget dialog
export const AddWidgetDialog = ({ 
  onAddWidget 
}: { 
  onAddWidget: (widgetType: WidgetType) => void 
}) => {
  const [widgetType, setWidgetType] = useState<WidgetType | "">("");
  
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Add Widget
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add Dashboard Widget</DialogTitle>
          <DialogDescription>
            Choose a widget to add to your dashboard.
          </DialogDescription>
        </DialogHeader>
        
        <div className="py-4">
          <Select
            value={widgetType}
            onValueChange={(value) => setWidgetType(value as WidgetType)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select widget type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="profile-completion">Profile Completion</SelectItem>
              <SelectItem value="college-stats">College Stats</SelectItem>
              <SelectItem value="upcoming-deadlines">Upcoming Deadlines</SelectItem>
              <SelectItem value="application-status">Application Status</SelectItem>
              <SelectItem value="counselor-notes">Counselor Notes</SelectItem>
              <SelectItem value="essay-progress">Essay Progress</SelectItem>
              <SelectItem value="recent-activities">Recent Activities</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <DialogFooter>
          <Button 
            disabled={!widgetType} 
            onClick={() => {
              if (widgetType) {
                onAddWidget(widgetType as WidgetType);
              }
            }}
          >
            Add to Dashboard
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

// Main dashboard container
export const DashboardContainer = () => {
  const { user } = useAuth();
  const [widgets, setWidgets] = useState<WidgetConfig[]>([
    { id: "widget-1", ...WIDGET_PRESETS["profile-completion"] },
    { id: "widget-2", ...WIDGET_PRESETS["college-stats"] },
    { id: "widget-3", ...WIDGET_PRESETS["upcoming-deadlines"] },
    { id: "widget-4", ...WIDGET_PRESETS["application-status"] }
  ]);

  const handleAddWidget = (widgetType: WidgetType) => {
    const newWidget = {
      id: `widget-${Date.now()}`,
      ...WIDGET_PRESETS[widgetType]
    };
    setWidgets([...widgets, newWidget]);
  };

  const handleEditWidget = (id: string) => {
    // In a real app, this would open a dialog to edit the widget
    console.log(`Editing widget ${id}`);
  };

  const handleDeleteWidget = (id: string) => {
    setWidgets(widgets.filter(widget => widget.id !== id));
  };

  const handleDragEnd = (result: any) => {
    if (!result.destination) return;
    
    const items = Array.from(widgets);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);
    
    setWidgets(items);
  };

  const getColumnClass = (size: WidgetConfig["size"]) => {
    switch (size) {
      case "small":
        return "col-span-1";
      case "medium":
        return "col-span-2";
      case "large":
        return "col-span-3";
      default:
        return "col-span-1";
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Your Dashboard</h2>
        <AddWidgetDialog onAddWidget={handleAddWidget} />
      </div>
      
      <DragDropContext onDragEnd={handleDragEnd}>
        <Droppable droppableId="dashboard" direction="horizontal">
          {(provided) => (
            <div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
              ref={provided.innerRef}
              {...provided.droppableProps}
            >
              {widgets.map((widget, index) => (
                <Draggable key={widget.id} draggableId={widget.id} index={index}>
                  {(provided, snapshot) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      {...provided.dragHandleProps}
                      className={getColumnClass(widget.size)}
                    >
                      <WidgetCard 
                        widget={widget} 
                        onEdit={handleEditWidget} 
                        onDelete={handleDeleteWidget}
                        isDragging={snapshot.isDragging}
                      />
                    </div>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>
    </div>
  );
};