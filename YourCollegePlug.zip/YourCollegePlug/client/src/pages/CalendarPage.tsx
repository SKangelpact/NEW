import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useAuth } from '@/components/AuthContext';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { format, addMonths, subMonths, startOfMonth, endOfMonth, eachDayOfInterval, getDay, isSameMonth, isToday, isEqual } from 'date-fns';
import { ChevronLeft, ChevronRight, Plus, Calendar as CalendarIcon, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Deadline } from '@shared/schema';
import { formatDeadlineDate } from '@/lib/dateUtils';

const formSchema = z.object({
  title: z.string().min(2, {
    message: "Title must be at least 2 characters.",
  }),
  description: z.string().optional(),
  date: z.date({
    required_error: "A date is required.",
  }),
  collegeId: z.number().optional(),
  completed: z.boolean().default(false),
});

export default function CalendarPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [isAddingDeadline, setIsAddingDeadline] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  
  // Fetch deadlines
  const { data: deadlines, isLoading } = useQuery({
    queryKey: ['/api/deadlines'],
    enabled: !!user,
  });
  
  // Add deadline mutation
  const addDeadlineMutation = useMutation({
    mutationFn: async (values: z.infer<typeof formSchema>) => {
      await apiRequest('POST', '/api/deadlines', values);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/deadlines'] });
      toast({
        title: "Deadline added",
        description: "The deadline has been added to your calendar.",
      });
      setIsAddingDeadline(false);
      form.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Could not add deadline. Please try again.",
        variant: "destructive"
      });
    }
  });
  
  // Toggle deadline completion mutation
  const toggleCompletionMutation = useMutation({
    mutationFn: async ({ id, completed }: { id: number; completed: boolean }) => {
      await apiRequest('PATCH', `/api/deadlines/${id}`, { completed });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/deadlines'] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Could not update deadline status. Please try again.",
        variant: "destructive"
      });
    }
  });
  
  // Delete deadline mutation
  const deleteDeadlineMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/deadlines/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/deadlines'] });
      toast({
        title: "Deadline deleted",
        description: "The deadline has been removed from your calendar.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Could not delete deadline. Please try again.",
        variant: "destructive"
      });
    }
  });
  
  // Form setup
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      completed: false,
    },
  });
  
  // Calendar navigation
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const startDate = monthStart;
  const endDate = monthEnd;
  
  const dateFormat = "MMMM yyyy";
  const days = eachDayOfInterval({ start: startDate, end: endDate });
  
  const startDay = getDay(monthStart);
  
  // Add empty cells for days of the week before the first day of the month
  const blanks = Array.from({ length: startDay }, (_, i) => i);
  
  const previousMonth = () => {
    setCurrentDate(subMonths(currentDate, 1));
  };
  
  const nextMonth = () => {
    setCurrentDate(addMonths(currentDate, 1));
  };
  
  // Function to check if a date has any deadlines
  const getDeadlinesForDay = (day: Date) => {
    if (!deadlines) return [];
    
    return deadlines.filter(deadline => {
      const deadlineDate = new Date(deadline.date);
      return isEqual(
        new Date(day.getFullYear(), day.getMonth(), day.getDate()),
        new Date(deadlineDate.getFullYear(), deadlineDate.getMonth(), deadlineDate.getDate())
      );
    });
  };
  
  // Add deadline form handlers
  const onSubmit = (values: z.infer<typeof formSchema>) => {
    addDeadlineMutation.mutate(values);
  };
  
  const handleDateSelect = (date: Date | undefined) => {
    if (date) {
      setSelectedDate(date);
      form.setValue('date', date);
    }
  };
  
  const handleAddDeadline = () => {
    setIsAddingDeadline(true);
    if (!selectedDate) {
      setSelectedDate(new Date());
      form.setValue('date', new Date());
    }
  };
  
  // Group deadlines by month for list view
  const groupDeadlinesByMonth = () => {
    if (!deadlines) return [];
    
    const grouped: { month: string; deadlines: Deadline[] }[] = [];
    const sortedDeadlines = [...deadlines].sort((a, b) => 
      new Date(a.date).getTime() - new Date(b.date).getTime()
    );
    
    sortedDeadlines.forEach(deadline => {
      const date = new Date(deadline.date);
      const monthYear = format(date, 'MMMM yyyy');
      
      const existingGroup = grouped.find(group => group.month === monthYear);
      if (existingGroup) {
        existingGroup.deadlines.push(deadline);
      } else {
        grouped.push({ month: monthYear, deadlines: [deadline] });
      }
    });
    
    return grouped;
  };
  
  const deadlineGroups = groupDeadlinesByMonth();

  return (
    <div className="max-w-7xl mx-auto py-10 px-4 sm:px-6 lg:px-8">
      <div className="flex flex-col sm:flex-row justify-between items-start mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Application Calendar</h1>
          <p className="mt-1 text-gray-500">
            Keep track of all your important application deadlines
          </p>
        </div>
        <div className="mt-4 sm:mt-0">
          <Button 
            className="bg-primary-600 hover:bg-primary-700 text-white flex items-center"
            onClick={handleAddDeadline}
          >
            <Plus className="mr-2 h-4 w-4" />
            Add Deadline
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Calendar View */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-center">
                <CardTitle>{format(currentDate, dateFormat)}</CardTitle>
                <div className="flex space-x-2">
                  <Button variant="ghost" size="icon" onClick={previousMonth} className="text-gray-400 hover:text-gray-500">
                    <ChevronLeft className="h-5 w-5" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={nextMonth} className="text-gray-400 hover:text-gray-500">
                    <ChevronRight className="h-5 w-5" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-96 w-full rounded-md" />
              ) : (
                <div className="grid grid-cols-7 gap-px bg-gray-200 rounded overflow-hidden text-center">
                  {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((day, i) => (
                    <div key={i} className="bg-gray-50 p-3 text-xs font-medium text-gray-500">{day}</div>
                  ))}
                  
                  {/* Blank days */}
                  {blanks.map(i => (
                    <div key={`blank-${i}`} className="bg-white p-3 min-h-[80px]"></div>
                  ))}
                  
                  {/* Calendar days */}
                  {days.map((day, i) => {
                    const dayDeadlines = getDeadlinesForDay(day);
                    const hasDeadlines = dayDeadlines.length > 0;
                    
                    return (
                      <div 
                        key={i} 
                        className={cn(
                          "p-2 min-h-[80px] text-left cursor-pointer hover:bg-gray-50",
                          isSameMonth(day, currentDate) ? "bg-white" : "bg-gray-50 text-gray-400",
                          isToday(day) ? "bg-primary-50" : "",
                          isEqual(day, selectedDate || new Date()) ? "ring-2 ring-primary-500" : ""
                        )}
                        onClick={() => handleDateSelect(day)}
                      >
                        <div className="font-medium">{format(day, 'd')}</div>
                        {hasDeadlines && (
                          <div className="mt-1 space-y-1">
                            {dayDeadlines.slice(0, 2).map((deadline, idx) => (
                              <div 
                                key={idx} 
                                className={cn(
                                  "text-xs p-1 rounded truncate",
                                  deadline.completed 
                                    ? "bg-green-100 text-green-800" 
                                    : "bg-red-100 text-red-800"
                                )}
                                title={deadline.title}
                              >
                                {deadline.title}
                              </div>
                            ))}
                            {dayDeadlines.length > 2 && (
                              <div className="text-xs text-gray-500">
                                +{dayDeadlines.length - 2} more
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Deadlines List */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Upcoming Deadlines</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  <Skeleton className="h-16 w-full rounded-md" />
                  <Skeleton className="h-16 w-full rounded-md" />
                  <Skeleton className="h-16 w-full rounded-md" />
                </div>
              ) : deadlines && deadlines.length > 0 ? (
                <div className="space-y-6">
                  {deadlineGroups.map((group, groupIndex) => (
                    <div key={groupIndex}>
                      <h3 className="font-medium text-sm text-gray-500 mb-2">{group.month}</h3>
                      <div className="space-y-3">
                        {group.deadlines.map(deadline => (
                          <div key={deadline.id} className="flex items-start justify-between bg-gray-50 p-3 rounded-md">
                            <div className="flex items-start space-x-3">
                              <Checkbox
                                checked={deadline.completed}
                                onCheckedChange={(checked) => 
                                  toggleCompletionMutation.mutate({ 
                                    id: deadline.id, 
                                    completed: checked === true 
                                  })
                                }
                                className="mt-1"
                              />
                              <div>
                                <h4 className={cn(
                                  "font-medium",
                                  deadline.completed && "line-through text-gray-500"
                                )}>
                                  {deadline.title}
                                </h4>
                                <div className="text-xs text-gray-500">
                                  {formatDeadlineDate(deadline.date)}
                                </div>
                                {deadline.description && (
                                  <p className="text-sm mt-1 text-gray-600">{deadline.description}</p>
                                )}
                              </div>
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => deleteDeadlineMutation.mutate(deadline.id)}
                              className="text-gray-400 hover:text-red-500"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-10">
                  <CalendarIcon className="h-10 w-10 text-gray-400 mx-auto mb-3" />
                  <h3 className="text-sm font-medium text-gray-900 mb-1">No deadlines yet</h3>
                  <p className="text-sm text-gray-500 mb-4">Add important dates to keep track of your applications</p>
                  <Button 
                    className="bg-primary-600 hover:bg-primary-700 text-white"
                    onClick={handleAddDeadline}
                  >
                    Add Your First Deadline
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Add Deadline Dialog */}
      <Dialog open={isAddingDeadline} onOpenChange={setIsAddingDeadline}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Deadline</DialogTitle>
            <DialogDescription>
              Create a new deadline or important date for your college applications.
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Title</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Submit Application to Stanford" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description (Optional)</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Add any additional details here" 
                        {...field} 
                        value={field.value || ''}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="date"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Date</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className={cn(
                              "pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "PPP")
                            ) : (
                              <span>Pick a date</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="completed"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>
                        Mark as completed
                      </FormLabel>
                      <FormDescription>
                        Check this if you've already completed this task
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsAddingDeadline(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  className="bg-primary-600 hover:bg-primary-700 text-white"
                  disabled={addDeadlineMutation.isPending}
                >
                  {addDeadlineMutation.isPending ? "Adding..." : "Add Deadline"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
