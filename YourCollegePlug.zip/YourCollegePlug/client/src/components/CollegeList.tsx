import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import { College, UserCollege } from '@shared/schema';

interface CollegeListProps {
  userColleges: (UserCollege & { college: College })[];
  selectedColleges: number[];
  onToggleSelection: (collegeId: number) => void;
}

export default function CollegeList({ userColleges, selectedColleges, onToggleSelection }: CollegeListProps) {
  // Group colleges by selectivity
  const reachColleges = userColleges.filter(uc => uc.college.selectivity === 'Reach');
  const matchColleges = userColleges.filter(uc => uc.college.selectivity === 'Match');
  const safetyColleges = userColleges.filter(uc => uc.college.selectivity === 'Safety');
  
  const totalColleges = userColleges.length;
  const isCompareDisabled = selectedColleges.length < 2;

  return (
    <div className="bg-white shadow rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <div className="text-gray-500 text-sm">Based on your profile</div>
          <div className="text-gray-700 font-medium">
            {totalColleges} {totalColleges === 1 ? 'college' : 'colleges'} recommended
          </div>
        </div>
        <Button
          className="bg-primary-600 text-white hover:bg-primary-700"
          disabled={isCompareDisabled}
        >
          Compare Selected
        </Button>
      </div>
      
      {/* Categories */}
      <div className="space-y-6">
        {/* Reach Schools */}
        {reachColleges.length > 0 && (
          <div>
            <div className="flex items-center mb-3">
              <div className="bg-red-100 text-red-800 text-xs font-medium px-2.5 py-0.5 rounded-full">Reach</div>
              <div className="ml-2 text-sm text-gray-500">Lower chance of acceptance</div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              {reachColleges.map(({ college, isSelected }) => (
                <CollegeCard
                  key={college.id}
                  college={college}
                  isSelected={selectedColleges.includes(college.id)}
                  onToggleSelection={() => onToggleSelection(college.id)}
                />
              ))}
            </div>
          </div>
        )}
        
        {/* Match Schools */}
        {matchColleges.length > 0 && (
          <div>
            <div className="flex items-center mb-3">
              <div className="bg-yellow-100 text-yellow-800 text-xs font-medium px-2.5 py-0.5 rounded-full">Match</div>
              <div className="ml-2 text-sm text-gray-500">Moderate chance of acceptance</div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              {matchColleges.map(({ college, isSelected }) => (
                <CollegeCard
                  key={college.id}
                  college={college}
                  isSelected={selectedColleges.includes(college.id)}
                  onToggleSelection={() => onToggleSelection(college.id)}
                />
              ))}
            </div>
          </div>
        )}
        
        {/* Safety Schools */}
        {safetyColleges.length > 0 && (
          <div>
            <div className="flex items-center mb-3">
              <div className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded-full">Safety</div>
              <div className="ml-2 text-sm text-gray-500">Higher chance of acceptance</div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {safetyColleges.map(({ college, isSelected }) => (
                <CollegeCard
                  key={college.id}
                  college={college}
                  isSelected={selectedColleges.includes(college.id)}
                  onToggleSelection={() => onToggleSelection(college.id)}
                />
              ))}
            </div>
          </div>
        )}
        
        {/* Empty state */}
        {totalColleges === 0 && (
          <div className="text-center py-8">
            <p className="text-gray-500 mb-4">
              You haven't added any colleges to your list yet.
            </p>
            <Button className="bg-primary-600 hover:bg-primary-700 text-white">
              Generate Recommendations
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}

interface CollegeCardProps {
  college: College;
  isSelected: boolean;
  onToggleSelection: () => void;
}

function CollegeCard({ college, isSelected, onToggleSelection }: CollegeCardProps) {
  return (
    <div className={cn(
      "college-card bg-white border rounded-lg p-4 transition-all duration-200",
      isSelected ? "border-primary-300" : "border-gray-200",
      "hover:border-primary-300 card-hover"
    )}>
      <div className="flex justify-between">
        <h3 className="font-medium">{college.name}</h3>
        <Checkbox 
          checked={isSelected}
          onCheckedChange={() => onToggleSelection()}
          className="h-4 w-4 text-primary-600"
        />
      </div>
      <p className="text-sm text-gray-600 mt-1">
        Strong fit for your academic profile and extracurricular activities.
      </p>
      <div className="mt-3 flex justify-between text-xs text-gray-500">
        <span>Acceptance Rate: {college.acceptanceRate}</span>
        <span>{college.tuition}/yr</span>
      </div>
    </div>
  );
}
