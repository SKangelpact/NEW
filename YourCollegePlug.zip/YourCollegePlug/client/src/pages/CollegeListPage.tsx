import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useAuth } from '@/components/AuthContext';
import { apiRequest, queryClient } from '@/lib/queryClient';
import CollegeList from '@/components/CollegeList';
import CollegeComparisonTool from '@/components/CollegeComparisonTool';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { College } from '@shared/schema';
import { RefreshCw } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function CollegeListPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedColleges, setSelectedColleges] = useState<number[]>([]);
  
  // Fetch user's college list
  const { 
    data: userColleges, 
    isLoading: isLoadingUserColleges 
  } = useQuery({
    queryKey: ['/api/user-colleges'],
    enabled: !!user,
  });
  
  // Fetch college recommendations
  const { 
    data: recommendations, 
    isLoading: isLoadingRecommendations 
  } = useQuery({
    queryKey: ['/api/recommendations'],
    enabled: !!user,
  });
  
  // Mutation to add a college to user's list
  const addCollegeMutation = useMutation({
    mutationFn: async (collegeId: number) => {
      await apiRequest('POST', '/api/user-colleges', { collegeId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user-colleges'] });
      toast({
        title: "College added",
        description: "The college has been added to your list.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Could not add college to your list. Please try again.",
        variant: "destructive"
      });
    }
  });
  
  // Handle adding a recommended college to the user's list
  const addRecommendedCollege = (college: College) => {
    addCollegeMutation.mutate(college.id);
  };
  
  // Handle toggling college selection for comparison
  const toggleCollegeSelection = (collegeId: number) => {
    setSelectedColleges(prev => 
      prev.includes(collegeId) 
        ? prev.filter(id => id !== collegeId)
        : [...prev, collegeId]
    );
  };
  
  // Get the selected colleges from the user's list
  const getSelectedCollegesData = () => {
    if (!userColleges) return [];
    return userColleges
      .filter(uc => selectedColleges.includes(uc.college.id))
      .map(uc => uc.college);
  };

  // Generate new recommendations
  const refreshRecommendations = () => {
    queryClient.invalidateQueries({ queryKey: ['/api/recommendations'] });
    toast({
      title: "Refreshing recommendations",
      description: "Building new college recommendations based on your profile.",
    });
  };

  return (
    <div className="max-w-7xl mx-auto py-10 px-4 sm:px-6 lg:px-8">
      <div className="flex flex-col sm:flex-row justify-between items-start mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">College List</h1>
          <p className="mt-1 text-gray-500">
            Explore college recommendations and manage your application list
          </p>
        </div>
        <div className="mt-4 sm:mt-0">
          <Button 
            className="bg-primary-600 hover:bg-primary-700 text-white flex items-center"
            onClick={refreshRecommendations}
            disabled={isLoadingRecommendations}
          >
            <RefreshCw className="mr-2 h-4 w-4" />
            Generate New Recommendations
          </Button>
        </div>
      </div>

      <Tabs defaultValue="mylist" className="space-y-6">
        <TabsList>
          <TabsTrigger value="mylist">My College List</TabsTrigger>
          <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
          {selectedColleges.length >= 2 && (
            <TabsTrigger value="compare">Compare ({selectedColleges.length})</TabsTrigger>
          )}
        </TabsList>
        
        <TabsContent value="mylist">
          {isLoadingUserColleges ? (
            <Card>
              <CardContent className="pt-6">
                <Skeleton className="h-8 w-48 mb-6" />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Skeleton className="h-32 w-full rounded-lg" />
                  <Skeleton className="h-32 w-full rounded-lg" />
                  <Skeleton className="h-32 w-full rounded-lg" />
                  <Skeleton className="h-32 w-full rounded-lg" />
                </div>
              </CardContent>
            </Card>
          ) : (
            <CollegeList 
              userColleges={userColleges || []}
              selectedColleges={selectedColleges}
              onToggleSelection={toggleCollegeSelection}
            />
          )}
        </TabsContent>
        
        <TabsContent value="recommendations">
          {isLoadingRecommendations ? (
            <Card>
              <CardContent className="pt-6">
                <Skeleton className="h-8 w-48 mb-6" />
                <div className="space-y-6">
                  <div>
                    <Skeleton className="h-6 w-24 mb-3" />
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Skeleton className="h-32 w-full rounded-lg" />
                      <Skeleton className="h-32 w-full rounded-lg" />
                    </div>
                  </div>
                  <div>
                    <Skeleton className="h-6 w-24 mb-3" />
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Skeleton className="h-32 w-full rounded-lg" />
                      <Skeleton className="h-32 w-full rounded-lg" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : !recommendations ? (
            <Card>
              <CardContent className="py-10 text-center">
                <p className="text-gray-500 mb-4">
                  No recommendations available. Complete your profile to get tailored suggestions.
                </p>
                <Button className="bg-primary-600 hover:bg-primary-700 text-white">
                  Complete Your Profile
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-8">
              {/* Reach Schools */}
              {recommendations.reach.length > 0 && (
                <RecommendationSection
                  title="Reach Schools"
                  description="Lower chance of acceptance, but worth shooting for"
                  badgeColor="red"
                  colleges={recommendations.reach}
                  onAddCollege={addRecommendedCollege}
                />
              )}
              
              {/* Match Schools */}
              {recommendations.match.length > 0 && (
                <RecommendationSection
                  title="Match Schools"
                  description="Good alignment with your academic profile"
                  badgeColor="yellow"
                  colleges={recommendations.match}
                  onAddCollege={addRecommendedCollege}
                />
              )}
              
              {/* Safety Schools */}
              {recommendations.safety.length > 0 && (
                <RecommendationSection
                  title="Safety Schools"
                  description="Higher chance of acceptance, good backup options"
                  badgeColor="green"
                  colleges={recommendations.safety}
                  onAddCollege={addRecommendedCollege}
                />
              )}
            </div>
          )}
        </TabsContent>
        
        {selectedColleges.length >= 2 && (
          <TabsContent value="compare">
            <CollegeComparisonTool colleges={getSelectedCollegesData()} />
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
}

interface RecommendationSectionProps {
  title: string;
  description: string;
  badgeColor: 'red' | 'yellow' | 'green';
  colleges: (College & { recommendation: string })[];
  onAddCollege: (college: College) => void;
}

function RecommendationSection({
  title,
  description,
  badgeColor,
  colleges,
  onAddCollege
}: RecommendationSectionProps) {
  const badgeClasses = {
    red: "bg-red-100 text-red-800",
    yellow: "bg-yellow-100 text-yellow-800",
    green: "bg-green-100 text-green-800",
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center">
          <div className={`${badgeClasses[badgeColor]} text-xs font-medium px-2.5 py-0.5 rounded-full`}>
            {title}
          </div>
          <CardDescription className="ml-2">{description}</CardDescription>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {colleges.map(college => (
            <div key={college.id} className="border border-gray-200 rounded-lg p-4 hover:border-primary-300 transition-all duration-200">
              <div className="flex justify-between items-start">
                <h3 className="font-medium">{college.name}</h3>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="text-primary-600 border-primary-300 hover:bg-primary-50"
                  onClick={() => onAddCollege(college)}
                >
                  Add
                </Button>
              </div>
              <p className="text-sm text-gray-600 mt-1">{college.recommendation}</p>
              <div className="mt-3 flex justify-between text-xs text-gray-500">
                <span>Acceptance Rate: {college.acceptanceRate}</span>
                <span>{college.tuition}/yr</span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
