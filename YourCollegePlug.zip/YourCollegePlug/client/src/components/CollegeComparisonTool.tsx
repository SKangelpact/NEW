import { College } from '@shared/schema';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Table, 
  TableHeader, 
  TableRow, 
  TableHead, 
  TableBody, 
  TableCell
} from '@/components/ui/table';

interface CollegeComparisonToolProps {
  colleges: College[];
}

export default function CollegeComparisonTool({ colleges }: CollegeComparisonToolProps) {
  if (colleges.length < 2) {
    return null;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-medium">College Comparison</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader className="bg-gray-50">
              <TableRow>
                <TableHead className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Criteria</TableHead>
                {colleges.map(college => (
                  <TableHead 
                    key={college.id}
                    className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    {college.name}
                  </TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody className="bg-white divide-y divide-gray-200">
              <TableRow>
                <TableCell className="px-3 py-3 whitespace-nowrap text-sm font-medium text-gray-900">Location</TableCell>
                {colleges.map(college => (
                  <TableCell key={`${college.id}-location`} className="px-3 py-3 whitespace-nowrap text-sm text-gray-500">
                    {college.location || 'N/A'}
                  </TableCell>
                ))}
              </TableRow>
              <TableRow>
                <TableCell className="px-3 py-3 whitespace-nowrap text-sm font-medium text-gray-900">Enrollment</TableCell>
                {colleges.map(college => (
                  <TableCell key={`${college.id}-enrollment`} className="px-3 py-3 whitespace-nowrap text-sm text-gray-500">
                    {college.enrollment?.toLocaleString() || 'N/A'}
                  </TableCell>
                ))}
              </TableRow>
              <TableRow>
                <TableCell className="px-3 py-3 whitespace-nowrap text-sm font-medium text-gray-900">Acceptance Rate</TableCell>
                {colleges.map(college => (
                  <TableCell key={`${college.id}-acceptanceRate`} className="px-3 py-3 whitespace-nowrap text-sm text-gray-500">
                    {college.acceptanceRate || 'N/A'}
                  </TableCell>
                ))}
              </TableRow>
              <TableRow>
                <TableCell className="px-3 py-3 whitespace-nowrap text-sm font-medium text-gray-900">Tuition (out-of-state)</TableCell>
                {colleges.map(college => (
                  <TableCell key={`${college.id}-tuition`} className="px-3 py-3 whitespace-nowrap text-sm text-gray-500">
                    {college.tuition || 'N/A'}
                  </TableCell>
                ))}
              </TableRow>
              <TableRow>
                <TableCell className="px-3 py-3 whitespace-nowrap text-sm font-medium text-gray-900">Financial Aid %</TableCell>
                {colleges.map(college => (
                  <TableCell key={`${college.id}-financialAid`} className="px-3 py-3 whitespace-nowrap text-sm text-gray-500">
                    {college.financialAidPercentage || 'N/A'}
                  </TableCell>
                ))}
              </TableRow>
              <TableRow>
                <TableCell className="px-3 py-3 whitespace-nowrap text-sm font-medium text-gray-900">Popular Majors</TableCell>
                {colleges.map(college => (
                  <TableCell key={`${college.id}-majors`} className="px-3 py-3 text-sm text-gray-500">
                    {college.popularMajors || 'N/A'}
                  </TableCell>
                ))}
              </TableRow>
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
