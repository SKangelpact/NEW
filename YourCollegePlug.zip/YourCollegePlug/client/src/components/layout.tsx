import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { 
  BarChart3, 
  Calendar, 
  User, 
  Users, 
  FileText, 
  Menu, 
  LogOut, 
  Settings,
  Briefcase,
  CheckSquare
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();

  const isActive = (path: string) => {
    return location === path;
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const navItems = [
    {
      title: "Dashboard",
      href: "/",
      icon: <BarChart3 className="h-5 w-5" />,
    },
    {
      title: "My Colleges",
      href: "/colleges",
      icon: <Briefcase className="h-5 w-5" />,
    },
    {
      title: "Discover",
      href: "/discover",
      icon: <Users className="h-5 w-5" />,
    },
    {
      title: "Connect",
      href: "/connect",
      icon: <Users className="h-5 w-5" />,
    },
    {
      title: "Calendar",
      href: "/calendar",
      icon: <Calendar className="h-5 w-5" />,
    },
    {
      title: "Application Tasks",
      href: "/tasks",
      icon: <CheckSquare className="h-5 w-5" />,
    },
    {
      title: "Resources",
      href: "/resources",
      icon: <FileText className="h-5 w-5" />,
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Mobile navbar */}
      <div className="md:hidden border-b bg-card">
        <div className="flex items-center h-16 px-4">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="mr-2">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="pr-0">
              <div className="px-7">
                <Link to="/" className="flex items-center">
                  <span className="font-bold text-lg">YourCollegePlug</span>
                </Link>
              </div>
              <nav className="flex flex-col gap-4 mt-8">
                {navItems.map((item) => (
                  <Link 
                    key={item.href} 
                    href={item.href}
                    className={cn(
                      "flex items-center gap-2 px-7 py-2 text-base hover:text-primary",
                      isActive(item.href) 
                        ? "text-primary font-medium" 
                        : "text-muted-foreground"
                    )}
                  >
                    {item.icon}
                    {item.title}
                  </Link>
                ))}
              </nav>
            </SheetContent>
          </Sheet>
          <div className="flex-1 flex justify-center">
            <Link to="/" className="flex items-center">
              <span className="font-bold text-lg">YourCollegePlug</span>
            </Link>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <User className="h-5 w-5" />
                <span className="sr-only">User menu</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>
                {user?.name || user?.username}
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild>
                <Link href="/profile">
                  <User className="mr-2 h-4 w-4" />
                  <span>Profile</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/settings">
                  <Settings className="mr-2 h-4 w-4" />
                  <span>Settings</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleLogout}>
                <LogOut className="mr-2 h-4 w-4" />
                <span>Log out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Desktop layout */}
      <div className="hidden md:flex flex-1 min-h-screen">
        <aside className="fixed inset-y-0 left-0 bg-card border-r w-64 pt-5 flex flex-col">
          <div className="px-6 mb-8">
            <Link to="/" className="flex items-center">
              <span className="font-bold text-xl">YourCollegePlug</span>
            </Link>
          </div>
          <nav className="flex-1 px-2">
            <div className="space-y-1">
              {navItems.map((item) => (
                <Link 
                  key={item.href} 
                  href={item.href}
                  className={cn(
                    "flex items-center gap-3 px-4 py-2.5 text-sm rounded-md hover:bg-muted transition-colors",
                    isActive(item.href) 
                      ? "bg-primary/10 text-primary font-medium" 
                      : "text-muted-foreground"
                  )}
                >
                  {item.icon}
                  {item.title}
                </Link>
              ))}
            </div>
          </nav>
          <div className="border-t p-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="w-full justify-start px-2">
                  <div className="flex items-center">
                    <div className="bg-primary/10 text-primary p-1 rounded mr-3">
                      <User className="h-5 w-5" />
                    </div>
                    <div className="text-left flex-1 overflow-hidden">
                      <div className="font-medium truncate">
                        {user?.name || user?.username}
                      </div>
                      <div className="text-xs text-muted-foreground truncate">
                        {user?.role || "User"}
                      </div>
                    </div>
                  </div>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuItem asChild>
                  <Link href="/profile">
                    <User className="mr-2 h-4 w-4" />
                    <span>Profile</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/settings">
                    <Settings className="mr-2 h-4 w-4" />
                    <span>Settings</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Log out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </aside>
        <main className="pl-64 flex-1">
          <div className="p-6">{children}</div>
        </main>
      </div>

      {/* Mobile content */}
      <div className="md:hidden">
        <main className="p-4">{children}</main>
      </div>
    </div>
  );
}