import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from "ws";
import * as schema from "@shared/schema";

// Configure Neon database connection for Serverless use
neonConfig.webSocketConstructor = ws;

// Get connection string from environment variables
const connectionString = process.env.DATABASE_URL;

if (!connectionString) {
  throw new Error(
    "DATABASE_URL environment variable is not set. Please make sure you have a database configured."
  );
}

// Create database pool
export const pool = new Pool({ connectionString });

// Initialize Drizzle with the schema
export const db = drizzle(pool, { schema });

// Export schema to allow easier migration when hosting elsewhere
export { schema };