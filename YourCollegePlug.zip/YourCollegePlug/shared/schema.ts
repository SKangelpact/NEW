import { pgTable, text, serial, integer, boolean, jsonb, timestamp, real, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table - authentication and user profiles
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name"),
  role: text("role"), // "admin", "manager", "procurement_specialist"
  department: text("department"),
  email: text("email"),
  phone: text("phone"),
  profileCompleted: integer("profile_completed").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  name: true,
  role: true,
  department: true,
  email: true,
  phone: true,
  profileCompleted: true,
});

export const updateUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

// Clients table - keep track of all clients
export const clients = pgTable("clients", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  contactPerson: text("contact_person"),
  email: text("email"),
  phone: text("phone"),
  address: text("address"),
  industry: text("industry"),
  notes: text("notes"),
  priority: text("priority"), // "high", "medium", "low"
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertClientSchema = createInsertSchema(clients).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Meetings table - schedule and track client meetings
export const meetings = pgTable("meetings", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  userId: integer("user_id").notNull(), // Owner/creator of the meeting
  title: text("title").notNull(),
  description: text("description"),
  meetingType: text("meeting_type"), // "initial", "follow-up", "negotiation", "review", "other"
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date"),
  location: text("location"),
  status: text("status").default("scheduled"), // "scheduled", "completed", "cancelled", "rescheduled"
  notes: text("notes"),
  outcome: text("outcome"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertMeetingSchema = createInsertSchema(meetings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Attendees - track who's attending each meeting (many-to-many)
export const attendees = pgTable("attendees", {
  id: serial("id").primaryKey(),
  meetingId: integer("meeting_id").notNull(),
  userId: integer("user_id"), // Internal attendee (nullable)
  name: text("name"), // For external attendees
  email: text("email"),
  role: text("role"),
  organization: text("organization"),
  attendance: text("attendance").default("pending"), // "confirmed", "pending", "declined"
});

export const insertAttendeeSchema = createInsertSchema(attendees).omit({
  id: true,
});

// Action items from meetings
export const actionItems = pgTable("action_items", {
  id: serial("id").primaryKey(),
  meetingId: integer("meeting_id").notNull(),
  description: text("description").notNull(),
  assignedTo: integer("assigned_to"), // userId
  dueDate: timestamp("due_date"),
  status: text("status").default("open"), // "open", "in_progress", "completed", "blocked"
  priority: text("priority").default("medium"), // "high", "medium", "low"
  completedDate: timestamp("completed_date"),
  notes: text("notes"),
});

export const insertActionItemSchema = createInsertSchema(actionItems).omit({
  id: true,
  completedDate: true,
});

// Documents related to meetings or clients
export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id"),
  meetingId: integer("meeting_id"),
  name: text("name").notNull(),
  type: text("type"), // "contract", "proposal", "minutes", "other"
  path: text("path").notNull(),
  uploadedBy: integer("uploaded_by").notNull(), // userId
  uploadedAt: timestamp("uploaded_at").defaultNow(),
  description: text("description"),
});

export const insertDocumentSchema = createInsertSchema(documents).omit({
  id: true,
  uploadedAt: true,
});

// Report configurations for customizable dashboards
export const reports = pgTable("reports", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  config: jsonb("config").$type<{
    type: string; // "meetings", "clients", "action_items"
    filters?: Record<string, any>;
    groupBy?: string;
    timeRange?: string;
    chartType?: string;
  }>(),
  isDefault: boolean("is_default").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertReportSchema = createInsertSchema(reports).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// College tables for YourCollegePlug
export const colleges = pgTable("colleges", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  selectivityCategory: text("selectivity_category"), // "Reach", "Match", "Safety"
  averageGPA: real("average_gpa"),
  tuitionCost: integer("tuition_cost"),
  popularMajors: text("popular_majors"), // Comma-separated list
  location: text("location"),
  size: text("size"), // Small, Medium, Large
  acceptanceRate: real("acceptance_rate"),
  website: text("website"),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertCollegeSchema = createInsertSchema(colleges).omit({
  id: true,
  createdAt: true,
});

// Student profiles extending user table
export const studentProfiles = pgTable("student_profiles", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().unique(),
  highSchoolGPA: real("high_school_gpa"),
  testScores: jsonb("test_scores").$type<{
    SAT_Math?: number,
    SAT_Reading?: number,
    SAT_Total?: number,
    ACT_Composite?: number,
    ACT_Math?: number,
    ACT_Reading?: number,
    ACT_Science?: number,
    ACT_English?: number,
  }>(),
  extracurriculars: text("extracurriculars"), // Comma-separated list
  academicInterests: text("academic_interests"), // Comma-separated list
  gradYear: text("grad_year"),
  profileCompleted: integer("profile_completed").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertStudentProfileSchema = createInsertSchema(studentProfiles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const updateStudentProfileSchema = createInsertSchema(studentProfiles).omit({
  id: true,
  userId: true,
  createdAt: true,
  updatedAt: true,
});

// User-College relationship (favorites/applications)
export const userColleges = pgTable("user_colleges", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  collegeId: integer("college_id").notNull(),
  status: text("status").default("interested"), // "interested", "applying", "applied", "accepted", "rejected", "waitlisted", "committed"
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertUserCollegeSchema = createInsertSchema(userColleges).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Application deadlines
export const deadlines = pgTable("deadlines", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  collegeId: integer("college_id").notNull(),
  applicationType: text("application_type"), // "Early Decision", "Early Action", "Regular Decision", "Rolling"
  dueDate: date("due_date").notNull(),
  isCompleted: boolean("is_completed").default(false),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertDeadlineSchema = createInsertSchema(deadlines).omit({
  id: true,
  createdAt: true,
});

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type UpdateUser = z.infer<typeof updateUserSchema>;

export type Client = typeof clients.$inferSelect;
export type InsertClient = z.infer<typeof insertClientSchema>;

export type Meeting = typeof meetings.$inferSelect;
export type InsertMeeting = z.infer<typeof insertMeetingSchema>;

export type Attendee = typeof attendees.$inferSelect;
export type InsertAttendee = z.infer<typeof insertAttendeeSchema>;

export type ActionItem = typeof actionItems.$inferSelect;
export type InsertActionItem = z.infer<typeof insertActionItemSchema>;

export type Document = typeof documents.$inferSelect;
export type InsertDocument = z.infer<typeof insertDocumentSchema>;

export type Report = typeof reports.$inferSelect;
export type InsertReport = z.infer<typeof insertReportSchema>;

// College-related types
export type College = typeof colleges.$inferSelect;
export type InsertCollege = z.infer<typeof insertCollegeSchema>;

export type StudentProfile = typeof studentProfiles.$inferSelect;
export type InsertStudentProfile = z.infer<typeof insertStudentProfileSchema>;
export type UpdateStudentProfile = z.infer<typeof updateStudentProfileSchema>;

export type UserCollege = typeof userColleges.$inferSelect;
export type InsertUserCollege = z.infer<typeof insertUserCollegeSchema>;

export type Deadline = typeof deadlines.$inferSelect;
export type InsertDeadline = z.infer<typeof insertDeadlineSchema>;
