import { College } from '@shared/schema';

/**
 * College selectivity type
 */
export type Selectivity = 'Reach' | 'Match' | 'Safety';

/**
 * Function to determine college selectivity based on acceptance rate
 * @param acceptanceRate Acceptance rate as a string (e.g., "15%")
 * @returns Selectivity category
 */
export function getSelectivityFromAcceptanceRate(acceptanceRate: string): Selectivity {
  if (!acceptanceRate) return 'Match';
  
  // Parse the percentage to a number
  const percentage = parseFloat(acceptanceRate.replace('%', ''));
  
  if (percentage <= 20) return 'Reach';
  if (percentage <= 50) return 'Match';
  return 'Safety';
}

/**
 * Function to format tuition for display
 * @param tuition Tuition string (e.g., "$45,000")
 * @returns Formatted tuition string
 */
export function formatTuition(tuition: string): string {
  if (!tuition) return 'N/A';
  return tuition.startsWith('$') ? tuition : `$${tuition}`;
}

/**
 * Function to get selectivity badge color
 * @param selectivity Selectivity category
 * @returns Tailwind CSS color class name
 */
export function getSelectivityColor(selectivity: Selectivity | string): string {
  switch (selectivity) {
    case 'Reach':
      return 'bg-red-100 text-red-800';
    case 'Match':
      return 'bg-yellow-100 text-yellow-800';
    case 'Safety':
      return 'bg-green-100 text-green-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
}

/**
 * Function to get selectivity description
 * @param selectivity Selectivity category
 * @returns Description string
 */
export function getSelectivityDescription(selectivity: Selectivity | string): string {
  switch (selectivity) {
    case 'Reach':
      return 'Lower chance of acceptance';
    case 'Match':
      return 'Moderate chance of acceptance';
    case 'Safety':
      return 'Higher chance of acceptance';
    default:
      return '';
  }
}

/**
 * Function to filter colleges by criteria
 * @param colleges Array of colleges
 * @param filters Filter criteria
 * @returns Filtered array of colleges
 */
export function filterColleges(
  colleges: College[],
  filters: {
    search?: string;
    selectivity?: Selectivity[];
    maxTuition?: number;
  }
): College[] {
  return colleges.filter(college => {
    // Apply search filter
    if (filters.search && !college.name.toLowerCase().includes(filters.search.toLowerCase())) {
      return false;
    }
    
    // Apply selectivity filter
    if (filters.selectivity && filters.selectivity.length > 0) {
      if (!filters.selectivity.includes(college.selectivity as Selectivity)) {
        return false;
      }
    }
    
    // Apply tuition filter
    if (filters.maxTuition) {
      const tuitionValue = parseTuitionToNumber(college.tuition);
      if (tuitionValue > filters.maxTuition) {
        return false;
      }
    }
    
    return true;
  });
}

/**
 * Function to parse tuition string to number
 * @param tuition Tuition string (e.g., "$45,000")
 * @returns Tuition as a number
 */
export function parseTuitionToNumber(tuition: string): number {
  if (!tuition) return 0;
  return parseInt(tuition.replace(/[^0-9]/g, ''));
}

/**
 * Function to group colleges by selectivity
 * @param colleges Array of colleges
 * @returns Object with colleges grouped by selectivity
 */
export function groupCollegesBySelectivity(colleges: College[]): Record<Selectivity, College[]> {
  return {
    Reach: colleges.filter(c => c.selectivity === 'Reach'),
    Match: colleges.filter(c => c.selectivity === 'Match'),
    Safety: colleges.filter(c => c.selectivity === 'Safety')
  };
}

/**
 * Function to generate a generic recommendation based on college and student profile
 * @param college College object
 * @param interests Student interests (comma-separated string)
 * @returns Recommendation string
 */
export function generateRecommendation(college: College, interests?: string): string {
  if (!interests) {
    return `Strong academic program with excellent opportunities.`;
  }
  
  const interestsList = interests.split(',').map(i => i.trim().toLowerCase());
  const majors = college.majorsOffered?.toLowerCase() || '';
  
  // Check if any of the student's interests match the college's majors
  const matchingInterests = interestsList.filter(interest => 
    majors.includes(interest)
  );
  
  if (matchingInterests.length > 0) {
    return `Great match for your interest in ${matchingInterests.join(', ')}.`;
  }
  
  return `Strong academic programs that may align with your interests.`;
}
