import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Layout from "@/components/layout";
import { useAuth } from "@/hooks/use-auth";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { DashboardContainer } from "@/components/DashboardWidgets";
import { Loader2 } from "lucide-react";

export default function Dashboard() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("dashboard");

  const { data: dashboardStats, isLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    enabled: !!user,
  });

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-col space-y-2">
          <h1 className="text-3xl font-bold">Welcome, {user?.name || user?.username}!</h1>
          <p className="text-muted-foreground">
            Track your college applications, deadlines, and progress
          </p>
        </div>

        <Tabs defaultValue="dashboard" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            {user?.role === "admin" && (
              <TabsTrigger value="admin">Admin Portal</TabsTrigger>
            )}
            {user?.role === "counselor" && (
              <TabsTrigger value="counselor">Counselor Portal</TabsTrigger>
            )}
          </TabsList>

          <TabsContent value="dashboard">
            {isLoading ? (
              <div className="flex justify-center py-10">
                <Loader2 className="h-10 w-10 animate-spin text-primary" />
              </div>
            ) : (
              <DashboardContainer />
            )}
          </TabsContent>

          <TabsContent value="analytics">
            <div className="bg-muted/50 p-8 rounded-lg text-center">
              <h3 className="text-lg font-medium mb-4">Advanced Application Analytics</h3>
              <p className="text-muted-foreground mb-4">
                Track your application performance, engagement metrics, and receive AI-powered insights
                to improve your chances of acceptance.
              </p>
              <Button>View Analytics</Button>
            </div>
          </TabsContent>

          {user?.role === "admin" && (
            <TabsContent value="admin">
              <AdminPortal />
            </TabsContent>
          )}

          {user?.role === "counselor" && (
            <TabsContent value="counselor">
              <CounselorPortal />
            </TabsContent>
          )}
        </Tabs>
      </div>
    </Layout>
  );
}

function AdminPortal() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Admin Portal</h2>
      <p className="text-muted-foreground">
        Manage users, colleges, and system settings
      </p>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <div className="bg-card rounded-lg border shadow-sm p-6">
          <h3 className="text-lg font-medium">User Management</h3>
          <p className="text-sm text-muted-foreground mt-2 mb-4">
            Manage student, counselor, and admin accounts
          </p>
          <Button variant="outline" className="w-full">
            Manage Users
          </Button>
        </div>

        <div className="bg-card rounded-lg border shadow-sm p-6">
          <h3 className="text-lg font-medium">College Database</h3>
          <p className="text-sm text-muted-foreground mt-2 mb-4">
            Add, edit, or remove colleges from the system
          </p>
          <Button variant="outline" className="w-full">
            Edit College Database
          </Button>
        </div>

        <div className="bg-card rounded-lg border shadow-sm p-6">
          <h3 className="text-lg font-medium">System Analytics</h3>
          <p className="text-sm text-muted-foreground mt-2 mb-4">
            View platform usage statistics and performance metrics
          </p>
          <Button variant="outline" className="w-full">
            View Analytics
          </Button>
        </div>

        <div className="bg-card rounded-lg border shadow-sm p-6">
          <h3 className="text-lg font-medium">Common App Integration</h3>
          <p className="text-sm text-muted-foreground mt-2 mb-4">
            Configure settings for Common App integration
          </p>
          <Button variant="outline" className="w-full">
            Manage Integrations
          </Button>
        </div>

        <div className="bg-card rounded-lg border shadow-sm p-6">
          <h3 className="text-lg font-medium">AI Configuration</h3>
          <p className="text-sm text-muted-foreground mt-2 mb-4">
            Adjust settings for AI-powered essay feedback and college matching
          </p>
          <Button variant="outline" className="w-full">
            AI Settings
          </Button>
        </div>
      </div>
    </div>
  );
}

function CounselorPortal() {
  // Mock data for student list
  const students = [
    { id: 1, name: "Alex Johnson", grade: "12th", colleges: 8, nextMeeting: "Jun 1, 2025" },
    { id: 2, name: "Maria Garcia", grade: "11th", colleges: 5, nextMeeting: "May 28, 2025" },
    { id: 3, name: "Jason Kim", grade: "12th", colleges: 12, nextMeeting: "Jun 5, 2025" },
    { id: 4, name: "Sophia Williams", grade: "11th", colleges: 3, nextMeeting: "May 30, 2025" },
  ];

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Counselor Portal</h2>
      <p className="text-muted-foreground">
        Manage your student roster, schedule meetings, and provide application feedback
      </p>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-card rounded-lg border shadow-sm p-6">
            <h3 className="text-lg font-medium mb-4">Your Students</h3>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-left text-sm text-muted-foreground">
                    <th className="pb-2">Name</th>
                    <th className="pb-2">Grade</th>
                    <th className="pb-2">Colleges</th>
                    <th className="pb-2">Next Meeting</th>
                    <th className="pb-2">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {students.map((student) => (
                    <tr key={student.id} className="border-t">
                      <td className="py-3">{student.name}</td>
                      <td className="py-3">{student.grade}</td>
                      <td className="py-3">{student.colleges}</td>
                      <td className="py-3">{student.nextMeeting}</td>
                      <td className="py-3">
                        <Button variant="ghost" size="sm">View</Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="mt-4 flex justify-between">
              <Button variant="outline">All Students</Button>
              <Button>Add Student</Button>
            </div>
          </div>

          <div className="bg-card rounded-lg border shadow-sm p-6">
            <h3 className="text-lg font-medium mb-4">Essays Pending Review</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center p-3 bg-muted/50 rounded-md">
                <div>
                  <p className="font-medium">Common App Personal Statement</p>
                  <p className="text-sm text-muted-foreground">Alex Johnson • Submitted 2 days ago</p>
                </div>
                <Button size="sm">Review</Button>
              </div>
              <div className="flex justify-between items-center p-3 bg-muted/50 rounded-md">
                <div>
                  <p className="font-medium">Why Stanford?</p>
                  <p className="text-sm text-muted-foreground">Maria Garcia • Submitted yesterday</p>
                </div>
                <Button size="sm">Review</Button>
              </div>
              <div className="flex justify-between items-center p-3 bg-muted/50 rounded-md">
                <div>
                  <p className="font-medium">Community Impact Essay</p>
                  <p className="text-sm text-muted-foreground">Jason Kim • Submitted 3 days ago</p>
                </div>
                <Button size="sm">Review</Button>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="bg-card rounded-lg border shadow-sm p-6">
            <h3 className="text-lg font-medium mb-4">Today's Schedule</h3>
            <div className="space-y-3">
              <div className="border-l-4 border-blue-400 pl-3 py-1">
                <p className="font-medium">9:00 AM - 10:00 AM</p>
                <p className="text-sm">Meeting with Alex Johnson</p>
              </div>
              <div className="border-l-4 border-green-400 pl-3 py-1">
                <p className="font-medium">11:30 AM - 12:30 PM</p>
                <p className="text-sm">College Board Webinar</p>
              </div>
              <div className="border-l-4 border-purple-400 pl-3 py-1">
                <p className="font-medium">2:00 PM - 3:00 PM</p>
                <p className="text-sm">Meeting with Sophia Williams</p>
              </div>
            </div>
            <Button variant="outline" className="w-full mt-4">View Full Schedule</Button>
          </div>

          <div className="bg-card rounded-lg border shadow-sm p-6">
            <h3 className="text-lg font-medium mb-4">AI Assistant</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Use AI to generate essay feedback, college recommendations, and more.
            </p>
            <div className="space-y-2">
              <Button variant="outline" className="w-full justify-start">Generate Essay Feedback</Button>
              <Button variant="outline" className="w-full justify-start">College Recommendations</Button>
              <Button variant="outline" className="w-full justify-start">Create Student Summary</Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}