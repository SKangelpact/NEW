import { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, updateUserSchema, 
  insertClientSchema, insertMeetingSchema,
  insertAttendeeSchema, insertActionItemSchema,
  insertDocumentSchema, insertReportSchema,
  User, Client, Meeting, Attendee, ActionItem 
} from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import session from "express-session";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import bcrypt from "bcryptjs";
import * as fs from 'fs';
import * as path from 'path';
import { format } from 'date-fns';

// Import the authentication setup function
import { setupAuth } from "./auth";
// Import the college-related routes
import { registerCollegeRoutes } from "./collegeRoutes";
// Import DatabaseStorage for initialization
import { DatabaseStorage } from "./DatabaseStorage";

// Helper function to generate dashboard stats for overview
async function generateDashboardStats(userId: number) {
  const upcomingMeetings = await storage.getMeetingsByUserId(userId);
  const clients = await storage.getClients();
  const highPriorityClients = await storage.getClientsByPriority("high");
  
  // Get action items assigned to the user
  const actionItems = await storage.getActionItemsByAssignedTo(userId);
  const openActionItems = actionItems.filter(item => item.status === "open").length;
  
  // Count meetings by status
  const meetingsByStatus = {
    scheduled: upcomingMeetings.filter(m => m.status === "scheduled").length,
    completed: upcomingMeetings.filter(m => m.status === "completed").length,
    cancelled: upcomingMeetings.filter(m => m.status === "cancelled").length
  };
  
  // Get upcoming meetings (next 7 days)
  const today = new Date();
  const nextWeek = new Date();
  nextWeek.setDate(today.getDate() + 7);
  
  const upcomingMeetingsThisWeek = upcomingMeetings.filter(meeting => {
    const meetingDate = new Date(meeting.startDate);
    return meetingDate >= today && meetingDate <= nextWeek;
  });
  
  // Sort upcoming meetings by date
  upcomingMeetingsThisWeek.sort((a, b) => 
    new Date(a.startDate).getTime() - new Date(b.startDate).getTime()
  );
  
  return {
    totalClients: clients.length,
    highPriorityClients: highPriorityClients.length,
    totalMeetings: upcomingMeetings.length,
    meetingsByStatus,
    openActionItems,
    upcomingMeetings: upcomingMeetingsThisWeek.slice(0, 5)
  };
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  setupAuth(app);
  
  // Initialize college-related routes
  registerCollegeRoutes(app);
  
  // Initialize sample data if using database storage
  if (storage instanceof DatabaseStorage) {
    try {
      await storage.initializeUserSampleData();
      await storage.initializeCollegeSampleData();
      console.log("Sample data initialized successfully");
    } catch (error) {
      console.error("Error initializing sample data:", error);
    }
  }

  // Authorization middleware
  const requireAuth = (req: Request, res: Response, next: Function) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "Authentication required" });
  };

  // API Routes
  // ----------------------------------------

  // Auth routes are now handled in auth.ts

  // User routes
  app.get('/api/users', requireAuth, async (req, res) => {
    try {
      const users = await storage.getUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: "Error fetching users" });
    }
  });

  app.get('/api/users/:id', requireAuth, async (req, res) => {
    try {
      const user = await storage.getUser(parseInt(req.params.id));
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Error fetching user" });
    }
  });

  app.patch('/api/users/:id', requireAuth, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      
      // Make sure the user is updating their own profile or is an admin
      if (req.user && (req.user as User).id !== userId && (req.user as User).role !== "admin") {
        return res.status(403).json({ message: "Not authorized to update this user" });
      }
      
      // Parse and validate input
      const updateData = updateUserSchema.partial().parse(req.body);
      
      // Update user
      const updatedUser = await storage.updateUser(userId, updateData);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(updatedUser);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      res.status(500).json({ message: "Error updating user" });
    }
  });

  // Client routes
  app.get('/api/clients', requireAuth, async (req, res) => {
    try {
      const clients = await storage.getClients();
      res.json(clients);
    } catch (error) {
      res.status(500).json({ message: "Error fetching clients" });
    }
  });

  app.get('/api/clients/:id', requireAuth, async (req, res) => {
    try {
      const client = await storage.getClient(parseInt(req.params.id));
      if (!client) {
        return res.status(404).json({ message: "Client not found" });
      }
      res.json(client);
    } catch (error) {
      res.status(500).json({ message: "Error fetching client" });
    }
  });

  app.post('/api/clients', requireAuth, async (req, res) => {
    try {
      const clientData = insertClientSchema.parse(req.body);
      const client = await storage.createClient(clientData);
      res.status(201).json(client);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      res.status(500).json({ message: "Error creating client" });
    }
  });

  app.patch('/api/clients/:id', requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      // Parse and validate input
      const updateData = insertClientSchema.partial().parse(req.body);
      
      // Update client
      const updatedClient = await storage.updateClient(id, updateData);
      if (!updatedClient) {
        return res.status(404).json({ message: "Client not found" });
      }
      
      res.json(updatedClient);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      res.status(500).json({ message: "Error updating client" });
    }
  });

  app.delete('/api/clients/:id', requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      // Check if client exists
      const client = await storage.getClient(id);
      if (!client) {
        return res.status(404).json({ message: "Client not found" });
      }
      
      // Only allow admins or managers to delete clients
      if ((req.user as User).role !== "admin" && (req.user as User).role !== "manager") {
        return res.status(403).json({ message: "Not authorized to delete clients" });
      }
      
      await storage.deleteClient(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Error deleting client" });
    }
  });

  // Meeting routes
  app.get('/api/meetings', requireAuth, async (req, res) => {
    try {
      const meetings = await storage.getMeetings();
      res.json(meetings);
    } catch (error) {
      res.status(500).json({ message: "Error fetching meetings" });
    }
  });

  app.get('/api/meetings/user/:userId', requireAuth, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const meetings = await storage.getMeetingsByUserId(userId);
      res.json(meetings);
    } catch (error) {
      res.status(500).json({ message: "Error fetching user meetings" });
    }
  });

  app.get('/api/meetings/client/:clientId', requireAuth, async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      const meetings = await storage.getMeetingsByClientId(clientId);
      res.json(meetings);
    } catch (error) {
      res.status(500).json({ message: "Error fetching client meetings" });
    }
  });

  app.get('/api/meetings/:id', requireAuth, async (req, res) => {
    try {
      const meeting = await storage.getMeeting(parseInt(req.params.id));
      if (!meeting) {
        return res.status(404).json({ message: "Meeting not found" });
      }
      
      // Get meeting attendees
      const attendees = await storage.getAttendeesByMeetingId(meeting.id);
      
      // Get meeting action items
      const actionItems = await storage.getActionItemsByMeetingId(meeting.id);
      
      // Get meeting documents
      const documents = await storage.getDocumentsByMeetingId(meeting.id);
      
      res.json({
        ...meeting,
        attendees,
        actionItems,
        documents
      });
    } catch (error) {
      res.status(500).json({ message: "Error fetching meeting" });
    }
  });

  app.post('/api/meetings', requireAuth, async (req, res) => {
    try {
      // Set the current user as the meeting creator
      const userId = (req.user as User).id;
      const meetingData = insertMeetingSchema.parse({
        ...req.body,
        userId
      });
      
      const meeting = await storage.createMeeting(meetingData);
      res.status(201).json(meeting);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      res.status(500).json({ message: "Error creating meeting" });
    }
  });

  app.patch('/api/meetings/:id', requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      // Check if the meeting exists
      const meeting = await storage.getMeeting(id);
      if (!meeting) {
        return res.status(404).json({ message: "Meeting not found" });
      }
      
      // Only allow the meeting creator, admins, or managers to update meetings
      const userId = (req.user as User).id;
      const userRole = (req.user as User).role;
      if (meeting.userId !== userId && userRole !== "admin" && userRole !== "manager") {
        return res.status(403).json({ message: "Not authorized to update this meeting" });
      }
      
      // Parse and validate input
      const updateData = insertMeetingSchema.partial().parse(req.body);
      
      // Update meeting
      const updatedMeeting = await storage.updateMeeting(id, updateData);
      
      res.json(updatedMeeting);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      res.status(500).json({ message: "Error updating meeting" });
    }
  });

  app.delete('/api/meetings/:id', requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      // Check if the meeting exists
      const meeting = await storage.getMeeting(id);
      if (!meeting) {
        return res.status(404).json({ message: "Meeting not found" });
      }
      
      // Only allow the meeting creator, admins, or managers to delete meetings
      const userId = (req.user as User).id;
      const userRole = (req.user as User).role;
      if (meeting.userId !== userId && userRole !== "admin" && userRole !== "manager") {
        return res.status(403).json({ message: "Not authorized to delete this meeting" });
      }
      
      await storage.deleteMeeting(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Error deleting meeting" });
    }
  });

  // Attendee routes
  app.get('/api/meetings/:meetingId/attendees', requireAuth, async (req, res) => {
    try {
      const meetingId = parseInt(req.params.meetingId);
      const attendees = await storage.getAttendeesByMeetingId(meetingId);
      res.json(attendees);
    } catch (error) {
      res.status(500).json({ message: "Error fetching attendees" });
    }
  });

  app.post('/api/attendees', requireAuth, async (req, res) => {
    try {
      const attendeeData = insertAttendeeSchema.parse(req.body);
      
      // Check if meeting exists
      const meeting = await storage.getMeeting(attendeeData.meetingId);
      if (!meeting) {
        return res.status(404).json({ message: "Meeting not found" });
      }
      
      const attendee = await storage.createAttendee(attendeeData);
      res.status(201).json(attendee);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      res.status(500).json({ message: "Error creating attendee" });
    }
  });

  app.patch('/api/attendees/:id', requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      // Parse and validate input
      const updateData = insertAttendeeSchema.partial().parse(req.body);
      
      // Update attendee
      const updatedAttendee = await storage.updateAttendee(id, updateData);
      if (!updatedAttendee) {
        return res.status(404).json({ message: "Attendee not found" });
      }
      
      res.json(updatedAttendee);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      res.status(500).json({ message: "Error updating attendee" });
    }
  });

  app.delete('/api/attendees/:id', requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteAttendee(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Error deleting attendee" });
    }
  });

  // Action Item routes
  app.get('/api/meetings/:meetingId/action-items', requireAuth, async (req, res) => {
    try {
      const meetingId = parseInt(req.params.meetingId);
      const actionItems = await storage.getActionItemsByMeetingId(meetingId);
      res.json(actionItems);
    } catch (error) {
      res.status(500).json({ message: "Error fetching action items" });
    }
  });

  app.get('/api/action-items/assigned/:userId', requireAuth, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const actionItems = await storage.getActionItemsByAssignedTo(userId);
      res.json(actionItems);
    } catch (error) {
      res.status(500).json({ message: "Error fetching assigned action items" });
    }
  });

  app.post('/api/action-items', requireAuth, async (req, res) => {
    try {
      const actionItemData = insertActionItemSchema.parse(req.body);
      
      // Check if meeting exists
      const meeting = await storage.getMeeting(actionItemData.meetingId);
      if (!meeting) {
        return res.status(404).json({ message: "Meeting not found" });
      }
      
      const actionItem = await storage.createActionItem(actionItemData);
      res.status(201).json(actionItem);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      res.status(500).json({ message: "Error creating action item" });
    }
  });

  app.patch('/api/action-items/:id', requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      // Get the action item to check if it exists
      const actionItem = await storage.getActionItem(id);
      if (!actionItem) {
        return res.status(404).json({ message: "Action item not found" });
      }
      
      // Parse and validate input
      const updateData = insertActionItemSchema.partial().parse(req.body);
      
      // If status is being updated to completed, set completedDate to now
      if (updateData.status === "completed" && actionItem.status !== "completed") {
        updateData.completedDate = new Date();
      }
      
      // Update action item
      const updatedActionItem = await storage.updateActionItem(id, updateData);
      
      res.json(updatedActionItem);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      res.status(500).json({ message: "Error updating action item" });
    }
  });

  app.delete('/api/action-items/:id', requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteActionItem(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Error deleting action item" });
    }
  });

  // Document routes
  app.get('/api/documents/client/:clientId', requireAuth, async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      const documents = await storage.getDocumentsByClientId(clientId);
      res.json(documents);
    } catch (error) {
      res.status(500).json({ message: "Error fetching client documents" });
    }
  });

  app.get('/api/documents/meeting/:meetingId', requireAuth, async (req, res) => {
    try {
      const meetingId = parseInt(req.params.meetingId);
      const documents = await storage.getDocumentsByMeetingId(meetingId);
      res.json(documents);
    } catch (error) {
      res.status(500).json({ message: "Error fetching meeting documents" });
    }
  });

  app.post('/api/documents', requireAuth, async (req, res) => {
    try {
      // Set the current user as the document uploader
      const userId = (req.user as User).id;
      const documentData = insertDocumentSchema.parse({
        ...req.body,
        uploadedBy: userId
      });
      
      const document = await storage.createDocument(documentData);
      res.status(201).json(document);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      res.status(500).json({ message: "Error creating document" });
    }
  });

  app.delete('/api/documents/:id', requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteDocument(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Error deleting document" });
    }
  });

  // Report routes
  app.get('/api/reports/user/:userId', requireAuth, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      
      // Check if it's the current user or an admin
      if ((req.user as User).id !== userId && (req.user as User).role !== "admin") {
        return res.status(403).json({ message: "Not authorized to access these reports" });
      }
      
      const reports = await storage.getReportsByUserId(userId);
      res.json(reports);
    } catch (error) {
      res.status(500).json({ message: "Error fetching user reports" });
    }
  });

  app.post('/api/reports', requireAuth, async (req, res) => {
    try {
      // Set the current user as the report creator
      const userId = (req.user as User).id;
      const reportData = insertReportSchema.parse({
        ...req.body,
        userId
      });
      
      const report = await storage.createReport(reportData);
      res.status(201).json(report);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      res.status(500).json({ message: "Error creating report" });
    }
  });

  app.patch('/api/reports/:id', requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      // Get the report to check if it exists and belongs to the user
      const report = await storage.getReport(id);
      if (!report) {
        return res.status(404).json({ message: "Report not found" });
      }
      
      // Check if it's the owner or an admin
      if (report.userId !== (req.user as User).id && (req.user as User).role !== "admin") {
        return res.status(403).json({ message: "Not authorized to update this report" });
      }
      
      // Parse and validate input
      const updateData = insertReportSchema.partial().parse(req.body);
      
      // Update report
      const updatedReport = await storage.updateReport(id, updateData);
      
      res.json(updatedReport);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      res.status(500).json({ message: "Error updating report" });
    }
  });

  app.delete('/api/reports/:id', requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      // Get the report to check if it exists and belongs to the user
      const report = await storage.getReport(id);
      if (!report) {
        return res.status(404).json({ message: "Report not found" });
      }
      
      // Check if it's the owner or an admin
      if (report.userId !== (req.user as User).id && (req.user as User).role !== "admin") {
        return res.status(403).json({ message: "Not authorized to delete this report" });
      }
      
      await storage.deleteReport(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Error deleting report" });
    }
  });

  // Dashboard stats
  app.get('/api/dashboard/stats', requireAuth, async (req, res) => {
    try {
      const userId = (req.user as User).id;
      const stats = await generateDashboardStats(userId);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Error generating dashboard stats" });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);

  return httpServer;
}
