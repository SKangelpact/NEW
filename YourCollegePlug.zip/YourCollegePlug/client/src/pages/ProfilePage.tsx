import { useState } from 'react';
import { useAuth } from '@/components/AuthContext';
import ProfileEditor from '@/components/ProfileEditor';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Check, X, Edit } from 'lucide-react';

export default function ProfilePage() {
  const { user } = useAuth();
  const [showProfileEditor, setShowProfileEditor] = useState(false);
  
  // Parse extracurriculars from comma-separated string
  const extracurriculars = user?.extracurriculars
    ? user.extracurriculars.split(',').map(item => item.trim()).filter(Boolean)
    : [];
  
  // Parse academic interests
  const academicInterests = user?.academicInterests
    ? user.academicInterests.split(',').map(item => item.trim()).filter(Boolean)
    : [];
  
  // Helper to determine status icon
  const getStatusIcon = (condition: boolean | undefined) => {
    if (condition) {
      return <Check className="h-5 w-5 text-green-500" />;
    } else {
      return <X className="h-5 w-5 text-red-500" />;
    }
  };

  return (
    <div className="max-w-7xl mx-auto py-10 px-4 sm:px-6 lg:px-8">
      <div className="flex flex-col md:flex-row justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">My Profile</h1>
          <p className="mt-1 text-gray-500">
            Manage your personal information and academic details
          </p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button 
            className="flex items-center bg-primary-600 hover:bg-primary-700 text-white"
            onClick={() => setShowProfileEditor(true)}
          >
            <Edit className="mr-2 h-4 w-4" />
            Edit Profile
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Personal Information */}
        <Card>
          <CardHeader>
            <CardTitle>Personal Information</CardTitle>
            <CardDescription>Your basic profile details</CardDescription>
          </CardHeader>
          <CardContent>
            <dl className="space-y-4">
              <div>
                <dt className="text-sm font-medium text-gray-500">Name</dt>
                <dd className="mt-1 text-sm text-gray-900">{user?.name || 'Not provided'}</dd>
              </div>
              <div>
                <dt className="text-sm font-medium text-gray-500">Username</dt>
                <dd className="mt-1 text-sm text-gray-900">{user?.username}</dd>
              </div>
              <div>
                <dt className="text-sm font-medium text-gray-500">Profile Completion</dt>
                <dd className="mt-1 text-sm text-gray-900">
                  {user?.profileCompleted || 0}% complete
                </dd>
              </div>
            </dl>
          </CardContent>
        </Card>

        {/* Academic Information */}
        <Card>
          <CardHeader>
            <CardTitle>Academic Information</CardTitle>
            <CardDescription>Your grades and test scores</CardDescription>
          </CardHeader>
          <CardContent>
            <dl className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <dt className="text-sm font-medium text-gray-500">GPA</dt>
                  <dd className="mt-1 text-sm text-gray-900">{user?.gpa || 'Not provided'}</dd>
                </div>
                {getStatusIcon(!!user?.gpa)}
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <dt className="text-sm font-medium text-gray-500">SAT Score</dt>
                  <dd className="mt-1 text-sm text-gray-900">{user?.testScores?.sat || 'Not provided'}</dd>
                </div>
                {getStatusIcon(!!user?.testScores?.sat)}
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <dt className="text-sm font-medium text-gray-500">ACT Score</dt>
                  <dd className="mt-1 text-sm text-gray-900">{user?.testScores?.act || 'Not provided'}</dd>
                </div>
                {getStatusIcon(!!user?.testScores?.act)}
              </div>
            </dl>
          </CardContent>
        </Card>

        {/* Extracurricular Activities */}
        <Card>
          <CardHeader>
            <CardTitle>Extracurricular Activities</CardTitle>
            <CardDescription>Activities outside of academics</CardDescription>
          </CardHeader>
          <CardContent>
            {extracurriculars.length > 0 ? (
              <ul className="space-y-2">
                {extracurriculars.map((activity, index) => (
                  <li key={index} className="flex items-center text-sm">
                    <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                    <span className="ml-2 text-gray-900">{activity}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-gray-500">No activities added yet</p>
            )}
          </CardContent>
        </Card>

        {/* Academic Interests */}
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Academic Interests</CardTitle>
            <CardDescription>Fields of study you're interested in</CardDescription>
          </CardHeader>
          <CardContent>
            {academicInterests.length > 0 ? (
              <div className="flex flex-wrap gap-2">
                {academicInterests.map((interest, index) => (
                  <Badge key={index} variant="secondary" className="text-sm">
                    {interest}
                  </Badge>
                ))}
              </div>
            ) : (
              <p className="text-sm text-gray-500">No academic interests added yet</p>
            )}
          </CardContent>
        </Card>

        {/* Documents */}
        <Card>
          <CardHeader>
            <CardTitle>Required Documents</CardTitle>
            <CardDescription>Application materials</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              <li className="flex items-center justify-between text-sm">
                <span className="text-gray-900">Personal Statement</span>
                <Badge variant="outline" className="bg-yellow-50 text-yellow-800 border-yellow-300">
                  Draft
                </Badge>
              </li>
              <li className="flex items-center justify-between text-sm">
                <span className="text-gray-900">Letters of Recommendation</span>
                <Badge variant="outline" className="bg-green-50 text-green-800 border-green-300">
                  Complete
                </Badge>
              </li>
              <li className="flex items-center justify-between text-sm">
                <span className="text-gray-900">Transcripts</span>
                <Badge variant="outline" className="bg-red-50 text-red-800 border-red-300">
                  Missing
                </Badge>
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>

      {/* Profile Editor Modal */}
      <ProfileEditor 
        isOpen={showProfileEditor} 
        onClose={() => setShowProfileEditor(false)} 
      />
    </div>
  );
}
