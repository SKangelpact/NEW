import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { FileText, BookOpen, Lightbulb, Award, Download, ExternalLink } from "lucide-react";

export default function ResourcesPage() {
  return (
    <div className="max-w-7xl mx-auto py-10 px-4 sm:px-6 lg:px-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Application Resources</h1>
        <p className="mt-1 text-gray-500">
          Helpful tools and guidance for your college application journey
        </p>
      </div>

      <Tabs defaultValue="essays" className="space-y-8">
        <TabsList className="grid grid-cols-1 md:grid-cols-4 w-full max-w-3xl">
          <TabsTrigger value="essays" className="flex items-center justify-center">
            <FileText className="h-4 w-4 mr-2" />
            Essays
          </TabsTrigger>
          <TabsTrigger value="recommendations" className="flex items-center justify-center">
            <Award className="h-4 w-4 mr-2" />
            Recommendations
          </TabsTrigger>
          <TabsTrigger value="financialAid" className="flex items-center justify-center">
            <BookOpen className="h-4 w-4 mr-2" />
            Financial Aid
          </TabsTrigger>
          <TabsTrigger value="help" className="flex items-center justify-center">
            <Lightbulb className="h-4 w-4 mr-2" />
            Help Center
          </TabsTrigger>
        </TabsList>

        {/* Essay Writing Resources */}
        <TabsContent value="essays">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Personal Statement Guide</CardTitle>
                  <CardDescription>
                    Tips and strategies for writing an effective personal statement
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <Accordion type="single" collapsible className="w-full">
                    <AccordionItem value="item-1">
                      <AccordionTrigger>Understanding the Prompt</AccordionTrigger>
                      <AccordionContent>
                        <p className="text-sm text-gray-600 mb-4">
                          Before you begin writing, take time to deeply understand what the prompt is asking. Common App and Coalition App have different prompts, but they're all designed to help admissions officers get to know you beyond your grades and test scores.
                        </p>
                        <p className="text-sm text-gray-600 mb-4">
                          Key questions to ask yourself:
                        </p>
                        <ul className="list-disc pl-5 text-sm text-gray-600 space-y-2">
                          <li>What specific aspects of your identity, background, or story does this prompt target?</li>
                          <li>How can you showcase your unique perspective?</li>
                          <li>What growth or learning experience can you highlight?</li>
                        </ul>
                      </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="item-2">
                      <AccordionTrigger>Brainstorming Meaningful Topics</AccordionTrigger>
                      <AccordionContent>
                        <p className="text-sm text-gray-600 mb-4">
                          The most compelling essays often come from personal experiences that have shaped your character or perspective. Consider moments of:
                        </p>
                        <ul className="list-disc pl-5 text-sm text-gray-600 space-y-2">
                          <li>Significant personal growth or change</li>
                          <li>Challenges you've overcome</li>
                          <li>Experiences that shaped your values or goals</li>
                          <li>Moments that demonstrate your character</li>
                        </ul>
                        <p className="text-sm text-gray-600 mt-4">
                          Remember, the topic itself doesn't need to be extraordinary—it's your reflection and insight that makes an essay stand out.
                        </p>
                      </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="item-3">
                      <AccordionTrigger>Structuring Your Essay</AccordionTrigger>
                      <AccordionContent>
                        <p className="text-sm text-gray-600 mb-4">
                          While there's no single "correct" structure, effective essays typically include:
                        </p>
                        <ol className="list-decimal pl-5 text-sm text-gray-600 space-y-2">
                          <li><strong>Engaging opening:</strong> Start with a compelling hook that draws readers in</li>
                          <li><strong>Context:</strong> Provide necessary background without overexplaining</li>
                          <li><strong>Development:</strong> Show the evolution of your experience or thinking</li>
                          <li><strong>Reflection:</strong> Demonstrate what you learned or how you changed</li>
                          <li><strong>Looking forward:</strong> Connect to your future goals or how this shapes your perspective</li>
                        </ol>
                        <p className="text-sm text-gray-600 mt-4">
                          Keep in mind the 650-word limit for the Common App essay—focus on depth rather than breadth.
                        </p>
                      </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="item-4">
                      <AccordionTrigger>Writing and Revision Tips</AccordionTrigger>
                      <AccordionContent>
                        <p className="text-sm text-gray-600 mb-4">
                          The strongest essays go through multiple drafts. Here's a process to follow:
                        </p>
                        <ol className="list-decimal pl-5 text-sm text-gray-600 space-y-2">
                          <li>Write a first draft without worrying about perfection</li>
                          <li>Let it sit for at least a day before returning to it</li>
                          <li>Read it aloud to check for flow and clarity</li>
                          <li>Get feedback from trusted readers (teachers, counselors, family)</li>
                          <li>Look for places to be more specific or vivid</li>
                          <li>Cut unnecessary words to stay within the limit</li>
                          <li>Check for grammar, spelling, and punctuation</li>
                        </ol>
                        <p className="text-sm text-gray-600 mt-4">
                          Remember: your essay should sound like you, not a thesaurus or what you think admissions officers want to hear.
                        </p>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>

                  <div className="flex flex-col sm:flex-row gap-4 pt-4">
                    <Button className="bg-primary-600 hover:bg-primary-700 text-white">
                      <Download className="mr-2 h-4 w-4" />
                      Download Essay Worksheet
                    </Button>
                    <Button variant="outline">
                      <ExternalLink className="mr-2 h-4 w-4" />
                      View Example Essays
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Essay Timeline</CardTitle>
                  <CardDescription>
                    Recommended schedule for essay preparation
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="border-l-2 border-primary-200 pl-4 py-1">
                      <h3 className="text-primary-600 font-medium">Junior Year Spring</h3>
                      <p className="text-sm text-gray-600">Begin brainstorming topics and collect feedback</p>
                    </div>
                    <div className="border-l-2 border-primary-300 pl-4 py-1">
                      <h3 className="text-primary-600 font-medium">Summer before Senior Year</h3>
                      <p className="text-sm text-gray-600">Write first drafts of personal statement and supplemental essays</p>
                    </div>
                    <div className="border-l-2 border-primary-400 pl-4 py-1">
                      <h3 className="text-primary-600 font-medium">September-October</h3>
                      <p className="text-sm text-gray-600">Revise and finalize essays for early applications</p>
                    </div>
                    <div className="border-l-2 border-primary-500 pl-4 py-1">
                      <h3 className="text-primary-600 font-medium">November-December</h3>
                      <p className="text-sm text-gray-600">Complete and polish essays for regular decision applications</p>
                    </div>
                  </div>

                  <div className="bg-gray-50 p-4 rounded-md mt-6">
                    <h3 className="font-medium text-gray-900 mb-2">Quick Tips</h3>
                    <ul className="space-y-2 text-sm text-gray-600">
                      <li className="flex items-start">
                        <span className="text-primary-500 mr-2">•</span>
                        Start early to avoid last-minute stress
                      </li>
                      <li className="flex items-start">
                        <span className="text-primary-500 mr-2">•</span>
                        Get feedback from multiple readers
                      </li>
                      <li className="flex items-start">
                        <span className="text-primary-500 mr-2">•</span>
                        Create unique essays for each school's supplements
                      </li>
                      <li className="flex items-start">
                        <span className="text-primary-500 mr-2">•</span>
                        Proofread carefully before submission
                      </li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Recommendation Letters */}
        <TabsContent value="recommendations">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Requesting Letters of Recommendation</CardTitle>
                  <CardDescription>
                    How to approach teachers and counselors for strong recommendation letters
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <Accordion type="single" collapsible className="w-full">
                    <AccordionItem value="item-1">
                      <AccordionTrigger>Who Should You Ask?</AccordionTrigger>
                      <AccordionContent>
                        <p className="text-sm text-gray-600 mb-4">
                          When selecting teachers to write your recommendation letters, consider:
                        </p>
                        <ul className="list-disc pl-5 text-sm text-gray-600 space-y-2">
                          <li>Teachers who know you well academically and personally</li>
                          <li>Teachers from core academic subjects (English, Math, Science, Social Studies, Foreign Language)</li>
                          <li>Teachers who have taught you recently, preferably in junior or senior year</li>
                          <li>Teachers in whose classes you've demonstrated growth, overcome challenges, or shown exceptional effort</li>
                        </ul>
                        <p className="text-sm text-gray-600 mt-4">
                          Typically, colleges request 1-2 teacher recommendations plus one from your counselor. Consider choosing teachers from different subject areas to show your range of abilities.
                        </p>
                      </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="item-2">
                      <AccordionTrigger>When and How to Ask</AccordionTrigger>
                      <AccordionContent>
                        <p className="text-sm text-gray-600 mb-4">
                          <strong>Timing:</strong> Request recommendations at least 4-6 weeks before they're due. Many teachers limit how many they'll write, so asking in spring of junior year is ideal.
                        </p>
                        <p className="text-sm text-gray-600 mb-4">
                          <strong>How to ask:</strong>
                        </p>
                        <ol className="list-decimal pl-5 text-sm text-gray-600 space-y-2">
                          <li>Ask in person rather than by email when possible</li>
                          <li>Be polite and understand that teachers may decline if they can't write a strong letter</li>
                          <li>Ask clearly: "Would you feel comfortable writing me a strong recommendation for my college applications?"</li>
                          <li>Provide a concrete deadline and list of schools</li>
                        </ol>
                      </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="item-3">
                      <AccordionTrigger>Supporting Materials to Provide</AccordionTrigger>
                      <AccordionContent>
                        <p className="text-sm text-gray-600 mb-4">
                          Help your recommenders write the strongest possible letter by providing:
                        </p>
                        <ul className="list-disc pl-5 text-sm text-gray-600 space-y-2">
                          <li>A resume or activities list highlighting your accomplishments</li>
                          <li>A "brag sheet" with specific examples of your contributions to their class</li>
                          <li>Description of challenging circumstances they may not be aware of</li>
                          <li>Your college list and intended major(s)</li>
                          <li>Deadline information and submission instructions</li>
                          <li>Any specific forms required by colleges</li>
                        </ul>
                        <p className="text-sm text-gray-600 mt-4">
                          Organize this information clearly in a folder or email to make the process as easy as possible for them.
                        </p>
                      </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="item-4">
                      <AccordionTrigger>Following Up and Saying Thank You</AccordionTrigger>
                      <AccordionContent>
                        <p className="text-sm text-gray-600 mb-4">
                          After asking for recommendations:
                        </p>
                        <ol className="list-decimal pl-5 text-sm text-gray-600 space-y-2">
                          <li>Send a polite reminder email 2 weeks before the deadline if they haven't submitted yet</li>
                          <li>Write a thoughtful thank-you note after they submit (handwritten is especially appreciated)</li>
                          <li>Keep recommenders updated on your college results</li>
                          <li>Let them know where you decide to attend</li>
                        </ol>
                        <p className="text-sm text-gray-600 mt-4">
                          Remember that writing recommendations takes significant time and effort. Expressing genuine gratitude shows respect for their support.
                        </p>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                  
                  <div className="mt-4 bg-primary-50 border border-primary-100 rounded-md p-4">
                    <h3 className="text-primary-800 font-medium mb-2">Pro Tip</h3>
                    <p className="text-sm text-primary-700">
                      Waiving your right to view recommendation letters demonstrates confidence in your recommenders and 
                      gives their assessments more credibility with admissions officers.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Recommendation Request Template</CardTitle>
                  <CardDescription>
                    Sample email for requesting recommendation letters
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="bg-gray-50 p-4 rounded-md text-sm text-gray-600 space-y-4">
                    <p>Subject: Recommendation Letter Request for [Your Name]</p>
                    <div>
                      <p>Dear [Teacher/Counselor Name],</p>
                      <p className="mt-4">I hope this email finds you well. I've greatly enjoyed and learned a lot from your [subject] class, especially our unit on [specific topic or project].</p>
                      <p className="mt-4">I'm writing to ask if you would feel comfortable writing me a strong letter of recommendation for my college applications. I'm applying to [number] schools, with my first deadline on [date].</p>
                      <p className="mt-4">I believe you could speak to my [specific qualities] that I demonstrated in your class. If you agree, I would be happy to provide you with my resume, a list of my activities, and any other information that might be helpful.</p>
                      <p className="mt-4">I understand that writing recommendations requires significant time and effort, so please let me know if you would prefer not to take this on.</p>
                      <p className="mt-4">Thank you for your consideration.</p>
                      <p className="mt-4">Sincerely,<br />[Your Name]<br />[Your Contact Information]</p>
                    </div>
                  </div>
                  
                  <Button className="w-full mt-4 bg-primary-600 hover:bg-primary-700 text-white">
                    <Download className="mr-2 h-4 w-4" />
                    Download Template
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Financial Aid */}
        <TabsContent value="financialAid">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Financial Aid Overview</CardTitle>
                  <CardDescription>
                    Understanding the different types of financial aid available
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <Accordion type="single" collapsible className="w-full">
                    <AccordionItem value="item-1">
                      <AccordionTrigger>Types of Financial Aid</AccordionTrigger>
                      <AccordionContent>
                        <p className="text-sm text-gray-600 mb-4">
                          Financial aid comes in several forms:
                        </p>
                        <ul className="list-disc pl-5 text-sm text-gray-600 space-y-3">
                          <li>
                            <strong>Grants:</strong> Free money based on financial need that doesn't need to be repaid. Examples include Federal Pell Grants, state grants, and institutional grants from colleges.
                          </li>
                          <li>
                            <strong>Scholarships:</strong> Free money based on merit, special talents, or other criteria that doesn't need to be repaid. These can come from colleges, private organizations, companies, or community groups.
                          </li>
                          <li>
                            <strong>Work-Study:</strong> A federal program that provides part-time jobs for students with financial need, allowing them to earn money to help pay for education expenses.
                          </li>
                          <li>
                            <strong>Loans:</strong> Borrowed money that must be repaid with interest. Federal student loans generally have more favorable terms than private loans.
                          </li>
                        </ul>
                      </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="item-2">
                      <AccordionTrigger>FAFSA and CSS Profile</AccordionTrigger>
                      <AccordionContent>
                        <p className="text-sm text-gray-600 mb-4">
                          The two main financial aid applications are:
                        </p>
                        <div className="space-y-4">
                          <div>
                            <h4 className="font-medium text-gray-900">FAFSA (Free Application for Federal Student Aid)</h4>
                            <ul className="list-disc pl-5 text-sm text-gray-600 mt-2 space-y-1">
                              <li>Required by all colleges for federal aid</li>
                              <li>Opens October 1st each year</li>
                              <li>Uses tax information from two years prior</li>
                              <li>Completely free to submit</li>
                              <li>Required annually for continuing students</li>
                            </ul>
                          </div>
                          
                          <div>
                            <h4 className="font-medium text-gray-900">CSS Profile</h4>
                            <ul className="list-disc pl-5 text-sm text-gray-600 mt-2 space-y-1">
                              <li>Required by ~400 mostly private colleges for institutional aid</li>
                              <li>More detailed than FAFSA and considers more assets</li>
                              <li>Has a fee, but fee waivers are available</li>
                              <li>Also opens October 1st each year</li>
                            </ul>
                          </div>
                        </div>
                        <p className="text-sm text-gray-600 mt-4">
                          Check each college's financial aid website to confirm which forms they require and their deadlines.
                        </p>
                      </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="item-3">
                      <AccordionTrigger>Scholarships</AccordionTrigger>
                      <AccordionContent>
                        <p className="text-sm text-gray-600 mb-4">
                          Beyond financial aid from colleges, you can apply for private scholarships from various sources:
                        </p>
                        <ul className="list-disc pl-5 text-sm text-gray-600 space-y-2">
                          <li>Local community organizations and businesses</li>
                          <li>Your or your parents' employers</li>
                          <li>Professional associations related to your intended major</li>
                          <li>Religious organizations</li>
                          <li>National scholarship search platforms</li>
                        </ul>
                        <p className="text-sm text-gray-600 mt-4">
                          Tips for scholarship searching:
                        </p>
                        <ul className="list-disc pl-5 text-sm text-gray-600 space-y-2 mt-2">
                          <li>Start early—many deadlines are in fall of senior year</li>
                          <li>Focus on local scholarships where the applicant pool is smaller</li>
                          <li>Look for scholarships specific to your background, interests, or intended major</li>
                          <li>Never pay to apply for scholarships—legitimate opportunities are free</li>
                        </ul>
                      </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="item-4">
                      <AccordionTrigger>Understanding Financial Aid Offers</AccordionTrigger>
                      <AccordionContent>
                        <p className="text-sm text-gray-600 mb-4">
                          After you're admitted and have submitted financial aid applications, colleges will send financial aid offers. When comparing them:
                        </p>
                        <ul className="list-disc pl-5 text-sm text-gray-600 space-y-2">
                          <li>Identify which awards are grants/scholarships (free money) versus loans (must be repaid)</li>
                          <li>Calculate the true "net cost" by subtracting only grants and scholarships from the total cost of attendance</li>
                          <li>Compare the amount of student loans offered</li>
                          <li>Check if scholarships are renewable for all four years and what criteria must be met to maintain them</li>
                          <li>Consider additional costs like travel to/from campus, books, and personal expenses</li>
                        </ul>
                        <p className="text-sm text-gray-600 mt-4">
                          If your financial circumstances have changed since filing the FAFSA or CSS Profile, contact the financial aid office to inquire about a professional judgment review.
                        </p>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>

                  <div className="flex flex-col sm:flex-row gap-4 pt-4">
                    <Button className="bg-primary-600 hover:bg-primary-700 text-white">
                      <ExternalLink className="mr-2 h-4 w-4" />
                      Go to FAFSA Website
                    </Button>
                    <Button variant="outline">
                      <Download className="mr-2 h-4 w-4" />
                      Financial Aid Checklist
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Key Financial Aid Dates</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-start">
                      <div className="bg-primary-100 text-primary-800 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="font-medium">1</span>
                      </div>
                      <div className="ml-3">
                        <h3 className="font-medium">October 1</h3>
                        <p className="text-sm text-gray-600">FAFSA and CSS Profile open for application</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <div className="bg-primary-100 text-primary-800 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="font-medium">2</span>
                      </div>
                      <div className="ml-3">
                        <h3 className="font-medium">November-February</h3>
                        <p className="text-sm text-gray-600">Priority financial aid deadlines (varies by college)</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <div className="bg-primary-100 text-primary-800 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="font-medium">3</span>
                      </div>
                      <div className="ml-3">
                        <h3 className="font-medium">March-April</h3>
                        <p className="text-sm text-gray-600">Financial aid award letters sent to admitted students</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <div className="bg-primary-100 text-primary-800 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="font-medium">4</span>
                      </div>
                      <div className="ml-3">
                        <h3 className="font-medium">May 1</h3>
                        <p className="text-sm text-gray-600">National College Decision Day (deposit deadline)</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Scholarship Resources</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    <li>
                      <a href="https://www.fastweb.com" target="_blank" rel="noopener noreferrer" className="text-primary-600 hover:text-primary-700 flex items-center">
                        <ExternalLink className="h-4 w-4 mr-2" />
                        Fastweb
                      </a>
                    </li>
                    <li>
                      <a href="https://www.scholarships.com" target="_blank" rel="noopener noreferrer" className="text-primary-600 hover:text-primary-700 flex items-center">
                        <ExternalLink className="h-4 w-4 mr-2" />
                        Scholarships.com
                      </a>
                    </li>
                    <li>
                      <a href="https://www.collegedata.com" target="_blank" rel="noopener noreferrer" className="text-primary-600 hover:text-primary-700 flex items-center">
                        <ExternalLink className="h-4 w-4 mr-2" />
                        College Data
                      </a>
                    </li>
                    <li>
                      <a href="https://www.cappex.com" target="_blank" rel="noopener noreferrer" className="text-primary-600 hover:text-primary-700 flex items-center">
                        <ExternalLink className="h-4 w-4 mr-2" />
                        Cappex
                      </a>
                    </li>
                    <li>
                      <a href="https://www.chegg.com/scholarships" target="_blank" rel="noopener noreferrer" className="text-primary-600 hover:text-primary-700 flex items-center">
                        <ExternalLink className="h-4 w-4 mr-2" />
                        Chegg Scholarships
                      </a>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Help Center */}
        <TabsContent value="help">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Frequently Asked Questions</CardTitle>
                  <CardDescription>
                    Common questions about using CollegePlug and the application process
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Accordion type="single" collapsible className="w-full">
                    <AccordionItem value="item-1">
                      <AccordionTrigger>How do I update my academic information?</AccordionTrigger>
                      <AccordionContent>
                        <p className="text-sm text-gray-600">
                          You can update your GPA, test scores, and other academic information by clicking on "My Profile" in the navigation menu, then clicking the "Edit Profile" button. Make sure to save your changes before exiting the form.
                        </p>
                      </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="item-2">
                      <AccordionTrigger>How are college recommendations generated?</AccordionTrigger>
                      <AccordionContent>
                        <p className="text-sm text-gray-600">
                          Our college recommendation engine analyzes your academic profile (GPA and test scores), extracurricular activities, and preferred majors to generate personalized college suggestions. Colleges are categorized as "Reach," "Match," or "Safety" based on how your profile compares to their typical admitted student profile.
                        </p>
                        <p className="text-sm text-gray-600 mt-2">
                          The more information you provide in your profile, the more tailored your recommendations will be. You can regenerate recommendations at any time by clicking the "Generate New Recommendations" button on the College List page.
                        </p>
                      </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="item-3">
                      <AccordionTrigger>Can I add colleges that aren't in my recommendations?</AccordionTrigger>
                      <AccordionContent>
                        <p className="text-sm text-gray-600">
                          Yes! While our recommendation engine suggests colleges that may be a good fit based on your profile, you're welcome to add any colleges to your list. Use the search function on the College List page to find and add colleges that interest you, regardless of whether they appeared in your recommendations.
                        </p>
                      </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="item-4">
                      <AccordionTrigger>How do I track application deadlines?</AccordionTrigger>
                      <AccordionContent>
                        <p className="text-sm text-gray-600">
                          You can track all your important application deadlines using the Calendar feature. To add a deadline:
                        </p>
                        <ol className="list-decimal pl-5 text-sm text-gray-600 mt-2 space-y-1">
                          <li>Navigate to the Calendar page</li>
                          <li>Click "Add Deadline"</li>
                          <li>Enter the deadline details and date</li>
                          <li>Click "Save" to add it to your calendar</li>
                        </ol>
                        <p className="text-sm text-gray-600 mt-2">
                          You'll see your upcoming deadlines on both the Calendar page and on your Dashboard. You can mark deadlines as completed once you've finished the task.
                        </p>
                      </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="item-5">
                      <AccordionTrigger>How do I compare colleges side-by-side?</AccordionTrigger>
                      <AccordionContent>
                        <p className="text-sm text-gray-600">
                          To compare colleges:
                        </p>
                        <ol className="list-decimal pl-5 text-sm text-gray-600 mt-2 space-y-1">
                          <li>Go to your College List page</li>
                          <li>Select the colleges you want to compare by checking the box next to each one</li>
                          <li>Once you've selected at least two colleges, the comparison tool will appear automatically</li>
                          <li>You can also click the "Compare Selected" button to view a more detailed side-by-side comparison</li>
                        </ol>
                        <p className="text-sm text-gray-600 mt-2">
                          The comparison tool shows key information like acceptance rates, tuition, location, and popular majors to help you make informed decisions.
                        </p>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Contact Support</CardTitle>
                  <CardDescription>
                    Need help? We're here to assist you
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="bg-gray-50 p-4 rounded-md flex items-start">
                      <div className="mr-3 mt-1 text-primary-500">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                          <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" />
                          <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" />
                        </svg>
                      </div>
                      <div>
                        <h3 className="font-medium text-gray-900">Email Support</h3>
                        <p className="text-sm text-gray-600 mt-1">
                          Send us an email and we'll respond within 24 hours
                        </p>
                        <a href="mailto:support@collegeplug.com" className="text-primary-600 text-sm font-medium mt-2 inline-block hover:text-primary-700">
                          support@collegeplug.com
                        </a>
                      </div>
                    </div>
                    
                    <div className="bg-gray-50 p-4 rounded-md flex items-start">
                      <div className="mr-3 mt-1 text-primary-500">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                          <path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z" />
                        </svg>
                      </div>
                      <div>
                        <h3 className="font-medium text-gray-900">Phone Support</h3>
                        <p className="text-sm text-gray-600 mt-1">
                          Available Monday-Friday, 9am-5pm ET
                        </p>
                        <a href="tel:+18005551234" className="text-primary-600 text-sm font-medium mt-2 inline-block hover:text-primary-700">
                          1-800-555-1234
                        </a>
                      </div>
                    </div>
                    
                    <div className="bg-gray-50 p-4 rounded-md flex items-start">
                      <div className="mr-3 mt-1 text-primary-500">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.5 1 1 0 11-1.731-1A3 3 0 0113 8a3.001 3.001 0 01-2 2.83V11a1 1 0 11-2 0v-1a1 1 0 011-1 1 1 0 100-2zm0 8a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
                        </svg>
                      </div>
                      <div>
                        <h3 className="font-medium text-gray-900">Knowledge Base</h3>
                        <p className="text-sm text-gray-600 mt-1">
                          Browse our help documentation
                        </p>
                        <a href="#" className="text-primary-600 text-sm font-medium mt-2 inline-block hover:text-primary-700">
                          Visit Knowledge Base
                        </a>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Schedule a Counseling Session</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4">
                    Need personalized guidance? Schedule a one-on-one session with a college admissions expert.
                  </p>
                  <Button className="w-full bg-primary-600 hover:bg-primary-700 text-white">
                    Book Appointment
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
