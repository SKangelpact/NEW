import { Express, Request, Response } from "express";
import { storage } from "./storage";
import { User } from "@shared/schema";
import { DatabaseStorage } from "./DatabaseStorage";

/**
 * Registers all college-related routes for the YourCollegePlug application
 */
export function registerCollegeRoutes(app: Express) {
  // Authentication check middleware
  const requireAuth = (req: Request, res: Response, next: Function) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "Authentication required" });
  };

  // Initialize sample college data if using database storage
  app.get('/api/initialize-colleges', async (req, res) => {
    try {
      if (storage instanceof DatabaseStorage) {
        await storage.initializeCollegeSampleData();
        res.json({ message: "College data initialized successfully" });
      } else {
        res.status(400).json({ message: "This endpoint only works with database storage" });
      }
    } catch (error) {
      console.error("Error initializing college data:", error);
      res.status(500).json({ message: "Failed to initialize college data" });
    }
  });

  // College-related endpoints
  app.get('/api/colleges', async (req, res) => {
    try {
      const colleges = await storage.getColleges();
      res.json(colleges);
    } catch (error) {
      console.error("Error fetching colleges:", error);
      res.status(500).json({ message: "Failed to fetch colleges" });
    }
  });

  app.get('/api/colleges/:id', async (req, res) => {
    try {
      const college = await storage.getCollege(parseInt(req.params.id));
      if (!college) {
        return res.status(404).json({ message: "College not found" });
      }
      res.json(college);
    } catch (error) {
      console.error("Error fetching college:", error);
      res.status(500).json({ message: "Failed to fetch college" });
    }
  });

  app.get('/api/colleges/selectivity/:category', async (req, res) => {
    try {
      const colleges = await storage.getCollegesBySelectivity(req.params.category);
      res.json(colleges);
    } catch (error) {
      console.error("Error fetching colleges by selectivity:", error);
      res.status(500).json({ message: "Failed to fetch colleges by selectivity" });
    }
  });

  // User's college list endpoints
  app.get('/api/my-colleges', requireAuth, async (req, res) => {
    try {
      const userColleges = await storage.getUserColleges((req.user as User).id);
      res.json(userColleges);
    } catch (error) {
      console.error("Error fetching user's colleges:", error);
      res.status(500).json({ message: "Failed to fetch your college list" });
    }
  });

  app.post('/api/my-colleges', requireAuth, async (req, res) => {
    try {
      const newUserCollege = await storage.createUserCollege({
        userId: (req.user as User).id,
        collegeId: req.body.collegeId,
        status: req.body.status || "interested",
        notes: req.body.notes
      });
      res.status(201).json(newUserCollege);
    } catch (error) {
      console.error("Error adding college to user's list:", error);
      res.status(500).json({ message: "Failed to add college to your list" });
    }
  });

  app.patch('/api/my-colleges/:id', requireAuth, async (req, res) => {
    try {
      const updatedUserCollege = await storage.updateUserCollege(parseInt(req.params.id), {
        status: req.body.status,
        notes: req.body.notes
      });
      if (!updatedUserCollege) {
        return res.status(404).json({ message: "College entry not found" });
      }
      res.json(updatedUserCollege);
    } catch (error) {
      console.error("Error updating college in user's list:", error);
      res.status(500).json({ message: "Failed to update college in your list" });
    }
  });

  app.delete('/api/my-colleges/:id', requireAuth, async (req, res) => {
    try {
      const success = await storage.deleteUserCollege(parseInt(req.params.id));
      if (!success) {
        return res.status(404).json({ message: "College entry not found" });
      }
      res.status(204).end();
    } catch (error) {
      console.error("Error removing college from user's list:", error);
      res.status(500).json({ message: "Failed to remove college from your list" });
    }
  });
  
  // Application deadlines endpoints
  app.get('/api/deadlines', requireAuth, async (req, res) => {
    try {
      const deadlines = await storage.getDeadlinesByUserId((req.user as User).id);
      res.json(deadlines);
    } catch (error) {
      console.error("Error fetching deadlines:", error);
      res.status(500).json({ message: "Failed to fetch deadlines" });
    }
  });

  app.get('/api/deadlines/upcoming', requireAuth, async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 5;
      const upcomingDeadlines = await storage.getUpcomingDeadlines((req.user as User).id, limit);
      res.json(upcomingDeadlines);
    } catch (error) {
      console.error("Error fetching upcoming deadlines:", error);
      res.status(500).json({ message: "Failed to fetch upcoming deadlines" });
    }
  });
  
  app.post('/api/deadlines', requireAuth, async (req, res) => {
    try {
      const newDeadline = await storage.createDeadline({
        userId: (req.user as User).id,
        collegeId: req.body.collegeId,
        applicationType: req.body.applicationType,
        dueDate: new Date(req.body.dueDate),
        isCompleted: req.body.isCompleted || false,
        notes: req.body.notes
      });
      res.status(201).json(newDeadline);
    } catch (error) {
      console.error("Error creating deadline:", error);
      res.status(500).json({ message: "Failed to create deadline" });
    }
  });
  
  app.patch('/api/deadlines/:id', requireAuth, async (req, res) => {
    try {
      const updatedData: any = {};
      
      if (req.body.applicationType) updatedData.applicationType = req.body.applicationType;
      if (req.body.dueDate) updatedData.dueDate = new Date(req.body.dueDate);
      if (req.body.hasOwnProperty('isCompleted')) updatedData.isCompleted = req.body.isCompleted;
      if (req.body.notes) updatedData.notes = req.body.notes;
      
      const updatedDeadline = await storage.updateDeadline(parseInt(req.params.id), updatedData);
      if (!updatedDeadline) {
        return res.status(404).json({ message: "Deadline not found" });
      }
      res.json(updatedDeadline);
    } catch (error) {
      console.error("Error updating deadline:", error);
      res.status(500).json({ message: "Failed to update deadline" });
    }
  });
  
  app.delete('/api/deadlines/:id', requireAuth, async (req, res) => {
    try {
      const success = await storage.deleteDeadline(parseInt(req.params.id));
      if (!success) {
        return res.status(404).json({ message: "Deadline not found" });
      }
      res.status(204).end();
    } catch (error) {
      console.error("Error deleting deadline:", error);
      res.status(500).json({ message: "Failed to delete deadline" });
    }
  });
  
  // Student profile endpoints
  app.get('/api/student-profile', requireAuth, async (req, res) => {
    try {
      const profile = await storage.getStudentProfile((req.user as User).id);
      if (!profile) {
        // Return empty profile if none exists
        return res.json({
          userId: (req.user as User).id,
          highSchoolGPA: null,
          testScores: null,
          extracurriculars: null,
          academicInterests: null,
          gradYear: null,
          profileCompleted: 0
        });
      }
      res.json(profile);
    } catch (error) {
      console.error("Error fetching student profile:", error);
      res.status(500).json({ message: "Failed to fetch student profile" });
    }
  });
  
  app.post('/api/student-profile', requireAuth, async (req, res) => {
    try {
      // Check if profile already exists
      const existingProfile = await storage.getStudentProfile((req.user as User).id);
      if (existingProfile) {
        return res.status(400).json({ message: "Profile already exists, use PATCH to update" });
      }
      
      // Create new profile
      const newProfile = await storage.createStudentProfile({
        userId: (req.user as User).id,
        highSchoolGPA: req.body.highSchoolGPA,
        testScores: req.body.testScores,
        extracurriculars: req.body.extracurriculars,
        academicInterests: req.body.academicInterests,
        gradYear: req.body.gradYear,
        profileCompleted: req.body.profileCompleted || 0
      });
      res.status(201).json(newProfile);
    } catch (error) {
      console.error("Error creating student profile:", error);
      res.status(500).json({ message: "Failed to create student profile" });
    }
  });
  
  app.patch('/api/student-profile', requireAuth, async (req, res) => {
    try {
      const updatedProfile = await storage.updateStudentProfile((req.user as User).id, req.body);
      if (!updatedProfile) {
        // If profile doesn't exist, create it
        return res.status(404).json({ message: "Profile not found. Create a profile first." });
      }
      res.json(updatedProfile);
    } catch (error) {
      console.error("Error updating student profile:", error);
      res.status(500).json({ message: "Failed to update student profile" });
    }
  });

  // Migration endpoints for self-hosting  
  app.get('/api/export-data', requireAuth, async (req, res) => {
    try {
      // Check if user is admin
      if ((req.user as User).role !== 'admin') {
        return res.status(403).json({ message: "Only administrators can export data" });
      }
      
      const allUsers = await storage.getUsers();
      const allColleges = await storage.getColleges();
      
      // Remove sensitive information from exported data
      const safeUsers = allUsers.map(user => ({
        ...user,
        password: '**********' // Hide passwords
      }));
      
      const exportData = {
        exportDate: new Date(),
        users: safeUsers,
        colleges: allColleges,
      };
      
      res.json(exportData);
    } catch (error) {
      console.error("Error exporting data:", error);
      res.status(500).json({ message: "Failed to export data" });
    }
  });
}