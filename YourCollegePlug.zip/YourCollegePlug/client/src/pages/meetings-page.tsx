import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { format } from "date-fns";
import {
  PlusCircle,
  Search,
  Calendar,
  Clock,
  Filter,
  ArrowUpDown,
  MoreHorizontal,
  Briefcase,
  User,
  MapPin,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Meeting, Client } from "@shared/schema";

interface MeetingWithClient extends Meeting {
  client: Client;
}

export default function MeetingsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string | null>(null);
  const [typeFilter, setTypeFilter] = useState<string | null>(null);

  const { data: meetings, isLoading } = useQuery<MeetingWithClient[]>({
    queryKey: ["/api/meetings"],
  });

  // Get unique meeting types for the filter
  const meetingTypes = meetings
    ? [...new Set(meetings.map((meeting) => meeting.meetingType).filter(Boolean))]
    : [];

  // Filter meetings based on search term and filters
  const filteredMeetings = meetings
    ? meetings.filter((meeting) => {
        // Search filter
        const searchMatch =
          !searchTerm ||
          meeting.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          (meeting.client?.name &&
            meeting.client.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
          (meeting.description &&
            meeting.description.toLowerCase().includes(searchTerm.toLowerCase()));

        // Status filter
        const statusMatch = !statusFilter || meeting.status === statusFilter;

        // Type filter
        const typeMatch = !typeFilter || meeting.meetingType === typeFilter;

        return searchMatch && statusMatch && typeMatch;
      })
    : [];

  // Function to render status badge
  const getStatusBadge = (status: string | null) => {
    if (!status) return null;
    
    switch (status.toLowerCase()) {
      case "scheduled":
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 hover:bg-blue-50">Scheduled</Badge>;
      case "completed":
        return <Badge variant="outline" className="bg-green-50 text-green-700 hover:bg-green-50">Completed</Badge>;
      case "cancelled":
        return <Badge variant="outline" className="bg-red-50 text-red-700 hover:bg-red-50">Cancelled</Badge>;
      case "rescheduled":
        return <Badge variant="outline" className="bg-amber-50 text-amber-700 hover:bg-amber-50">Rescheduled</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6 p-6">
      <div className="flex flex-col space-y-2">
        <h1 className="text-3xl font-bold tracking-tight">Meetings</h1>
        <p className="text-muted-foreground">
          Schedule and manage client meetings
        </p>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
          <div className="relative w-full sm:w-[280px]">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search meetings..."
              className="pl-8 w-full"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="flex gap-2 w-full sm:w-auto">
            <Select
              value={statusFilter || ""}
              onValueChange={(value) => setStatusFilter(value || null)}
            >
              <SelectTrigger className="w-full sm:w-[160px]">
                <div className="flex items-center gap-2">
                  <Filter className="h-4 w-4" />
                  <SelectValue placeholder="Status" />
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Statuses</SelectItem>
                <SelectItem value="scheduled">Scheduled</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
                <SelectItem value="rescheduled">Rescheduled</SelectItem>
              </SelectContent>
            </Select>

            <Select
              value={typeFilter || ""}
              onValueChange={(value) => setTypeFilter(value || null)}
            >
              <SelectTrigger className="w-full sm:w-[180px]">
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  <SelectValue placeholder="Meeting Type" />
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Types</SelectItem>
                {meetingTypes.map((type) => (
                  <SelectItem key={type} value={type || ""}>
                    {type}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <Link href="/meetings/new">
          <Button>
            <PlusCircle className="mr-2 h-4 w-4" />
            Schedule Meeting
          </Button>
        </Link>
      </div>

      {isLoading ? (
        <div className="space-y-4">
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
        </div>
      ) : filteredMeetings.length > 0 ? (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[300px]">
                  <div className="flex items-center gap-1">
                    Meeting Title
                    <ArrowUpDown className="ml-1 h-3 w-3" />
                  </div>
                </TableHead>
                <TableHead>Client</TableHead>
                <TableHead>Date & Time</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Location</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredMeetings.map((meeting) => (
                <TableRow key={meeting.id}>
                  <TableCell className="font-medium">
                    <Link href={`/meetings/${meeting.id}`}>
                      <div className="flex items-center gap-2 hover:underline cursor-pointer">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        {meeting.title}
                      </div>
                    </Link>
                  </TableCell>
                  <TableCell>
                    {meeting.client ? (
                      <Link href={`/clients/${meeting.client.id}`}>
                        <div className="flex items-center gap-2 hover:underline cursor-pointer">
                          <Briefcase className="h-4 w-4 text-muted-foreground" />
                          {meeting.client.name}
                        </div>
                      </Link>
                    ) : (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      {format(new Date(meeting.startDate), "MMM d, yyyy h:mm a")}
                    </div>
                  </TableCell>
                  <TableCell>
                    {getStatusBadge(meeting.status)}
                  </TableCell>
                  <TableCell>
                    {meeting.meetingType || <span className="text-muted-foreground">—</span>}
                  </TableCell>
                  <TableCell>
                    {meeting.location ? (
                      <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4 text-muted-foreground" />
                        {meeting.location}
                      </div>
                    ) : (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">Open menu</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem asChild>
                          <Link href={`/meetings/${meeting.id}`}>View Details</Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem asChild>
                          <Link href={`/meetings/${meeting.id}/edit`}>Edit Meeting</Link>
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        {meeting.status === "scheduled" && (
                          <>
                            <DropdownMenuItem asChild>
                              <Link href={`/meetings/${meeting.id}/complete`}>Mark as Completed</Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem asChild>
                              <Link href={`/meetings/${meeting.id}/cancel`}>Cancel Meeting</Link>
                            </DropdownMenuItem>
                          </>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center rounded-lg border border-dashed p-8 text-center">
          <div className="rounded-full bg-primary/10 p-3 text-primary">
            <Calendar className="h-6 w-6" />
          </div>
          <h3 className="mt-4 text-lg font-semibold">No meetings found</h3>
          <p className="mt-2 text-sm text-muted-foreground">
            {searchTerm || statusFilter || typeFilter
              ? "Try adjusting your search or filters"
              : "Get started by scheduling a new meeting"}
          </p>
          <Link href="/meetings/new">
            <Button className="mt-4">
              <PlusCircle className="mr-2 h-4 w-4" />
              Schedule Meeting
            </Button>
          </Link>
        </div>
      )}
    </div>
  );
}