import { 
  users, type User, type InsertUser, type UpdateUser,
  clients, type Client, type InsertClient,
  meetings, type Meeting, type InsertMeeting,
  attendees, type Attendee, type InsertAttendee,
  actionItems, type ActionItem, type InsertActionItem,
  documents, type Document, type InsertDocument,
  reports, type Report, type InsertReport
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<UpdateUser>): Promise<User | undefined>;
  getUsers(): Promise<User[]>;
  
  // Client methods
  getClient(id: number): Promise<Client | undefined>;
  getClients(): Promise<Client[]>;
  getClientsByPriority(priority: string): Promise<Client[]>;
  createClient(client: InsertClient): Promise<Client>;
  updateClient(id: number, client: Partial<Client>): Promise<Client | undefined>;
  deleteClient(id: number): Promise<boolean>;
  
  // Meeting methods
  getMeeting(id: number): Promise<Meeting | undefined>;
  getMeetings(): Promise<Meeting[]>;
  getMeetingsByUserId(userId: number): Promise<Meeting[]>;
  getMeetingsByClientId(clientId: number): Promise<Meeting[]>;
  getMeetingsByStatus(status: string): Promise<Meeting[]>;
  getMeetingsByDateRange(startDate: Date, endDate: Date): Promise<Meeting[]>;
  createMeeting(meeting: InsertMeeting): Promise<Meeting>;
  updateMeeting(id: number, meeting: Partial<Meeting>): Promise<Meeting | undefined>;
  deleteMeeting(id: number): Promise<boolean>;
  
  // Attendee methods
  getAttendeesByMeetingId(meetingId: number): Promise<Attendee[]>;
  createAttendee(attendee: InsertAttendee): Promise<Attendee>;
  updateAttendee(id: number, attendee: Partial<Attendee>): Promise<Attendee | undefined>;
  deleteAttendee(id: number): Promise<boolean>;
  
  // Action Item methods
  getActionItem(id: number): Promise<ActionItem | undefined>;
  getActionItemsByMeetingId(meetingId: number): Promise<ActionItem[]>;
  getActionItemsByAssignedTo(userId: number): Promise<ActionItem[]>;
  getActionItemsByStatus(status: string): Promise<ActionItem[]>;
  createActionItem(actionItem: InsertActionItem): Promise<ActionItem>;
  updateActionItem(id: number, actionItem: Partial<ActionItem>): Promise<ActionItem | undefined>;
  deleteActionItem(id: number): Promise<boolean>;
  
  // Document methods
  getDocument(id: number): Promise<Document | undefined>;
  getDocumentsByClientId(clientId: number): Promise<Document[]>;
  getDocumentsByMeetingId(meetingId: number): Promise<Document[]>;
  createDocument(document: InsertDocument): Promise<Document>;
  updateDocument(id: number, document: Partial<Document>): Promise<Document | undefined>;
  deleteDocument(id: number): Promise<boolean>;
  
  // Report methods
  getReport(id: number): Promise<Report | undefined>;
  getReportsByUserId(userId: number): Promise<Report[]>;
  createReport(report: InsertReport): Promise<Report>;
  updateReport(id: number, report: Partial<Report>): Promise<Report | undefined>;
  deleteReport(id: number): Promise<boolean>;
  
  // Session store for auth
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private clients: Map<number, Client>;
  private meetings: Map<number, Meeting>;
  private attendees: Map<number, Attendee>;
  private actionItems: Map<number, ActionItem>;
  private documents: Map<number, Document>;
  private reports: Map<number, Report>;
  
  private userIdCounter: number;
  private clientIdCounter: number;
  private meetingIdCounter: number;
  private attendeeIdCounter: number;
  private actionItemIdCounter: number;
  private documentIdCounter: number;
  private reportIdCounter: number;
  
  sessionStore: session.SessionStore;

  constructor() {
    this.users = new Map();
    this.clients = new Map();
    this.meetings = new Map();
    this.attendees = new Map();
    this.actionItems = new Map();
    this.documents = new Map();
    this.reports = new Map();
    
    this.userIdCounter = 1;
    this.clientIdCounter = 1;
    this.meetingIdCounter = 1;
    this.attendeeIdCounter = 1;
    this.actionItemIdCounter = 1;
    this.documentIdCounter = 1;
    this.reportIdCounter = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
    
    // Initialize with sample data
    this.initializeSampleData();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const createdAt = new Date();
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt,
      role: insertUser.role || null,
      department: insertUser.department || null,
      email: insertUser.email || null,
      phone: insertUser.phone || null,
      profileCompleted: insertUser.profileCompleted || 0
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, updateData: Partial<UpdateUser>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updateData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Client methods
  async getClient(id: number): Promise<Client | undefined> {
    return this.clients.get(id);
  }

  async getClients(): Promise<Client[]> {
    return Array.from(this.clients.values());
  }

  async getClientsByPriority(priority: string): Promise<Client[]> {
    return Array.from(this.clients.values()).filter(
      (client) => client.priority === priority
    );
  }

  async createClient(insertClient: InsertClient): Promise<Client> {
    const id = this.clientIdCounter++;
    const createdAt = new Date();
    const updatedAt = new Date();
    const client: Client = { 
      ...insertClient, 
      id, 
      createdAt, 
      updatedAt,
      contactPerson: insertClient.contactPerson || null,
      email: insertClient.email || null,
      phone: insertClient.phone || null,
      address: insertClient.address || null,
      industry: insertClient.industry || null,
      notes: insertClient.notes || null,
      priority: insertClient.priority || "medium"
    };
    this.clients.set(id, client);
    return client;
  }

  async updateClient(id: number, updateData: Partial<Client>): Promise<Client | undefined> {
    const client = await this.getClient(id);
    if (!client) return undefined;
    
    const updatedClient = { 
      ...client, 
      ...updateData, 
      updatedAt: new Date() 
    };
    this.clients.set(id, updatedClient);
    return updatedClient;
  }

  async deleteClient(id: number): Promise<boolean> {
    return this.clients.delete(id);
  }

  // Meeting methods
  async getMeeting(id: number): Promise<Meeting | undefined> {
    return this.meetings.get(id);
  }

  async getMeetings(): Promise<Meeting[]> {
    return Array.from(this.meetings.values());
  }

  async getMeetingsByUserId(userId: number): Promise<Meeting[]> {
    return Array.from(this.meetings.values()).filter(
      (meeting) => meeting.userId === userId
    );
  }

  async getMeetingsByClientId(clientId: number): Promise<Meeting[]> {
    return Array.from(this.meetings.values()).filter(
      (meeting) => meeting.clientId === clientId
    );
  }

  async getMeetingsByStatus(status: string): Promise<Meeting[]> {
    return Array.from(this.meetings.values()).filter(
      (meeting) => meeting.status === status
    );
  }

  async getMeetingsByDateRange(startDate: Date, endDate: Date): Promise<Meeting[]> {
    return Array.from(this.meetings.values()).filter(
      (meeting) => {
        const meetingStart = new Date(meeting.startDate);
        return meetingStart >= startDate && meetingStart <= endDate;
      }
    );
  }

  async createMeeting(insertMeeting: InsertMeeting): Promise<Meeting> {
    const id = this.meetingIdCounter++;
    const createdAt = new Date();
    const updatedAt = new Date();
    const meeting: Meeting = { 
      ...insertMeeting, 
      id, 
      createdAt, 
      updatedAt,
      description: insertMeeting.description || null,
      meetingType: insertMeeting.meetingType || null,
      endDate: insertMeeting.endDate || null,
      location: insertMeeting.location || null,
      status: insertMeeting.status || "scheduled",
      notes: insertMeeting.notes || null,
      outcome: insertMeeting.outcome || null
    };
    this.meetings.set(id, meeting);
    return meeting;
  }

  async updateMeeting(id: number, updateData: Partial<Meeting>): Promise<Meeting | undefined> {
    const meeting = await this.getMeeting(id);
    if (!meeting) return undefined;
    
    const updatedMeeting = { 
      ...meeting, 
      ...updateData, 
      updatedAt: new Date() 
    };
    this.meetings.set(id, updatedMeeting);
    return updatedMeeting;
  }

  async deleteMeeting(id: number): Promise<boolean> {
    return this.meetings.delete(id);
  }

  // Attendee methods
  async getAttendeesByMeetingId(meetingId: number): Promise<Attendee[]> {
    return Array.from(this.attendees.values()).filter(
      (attendee) => attendee.meetingId === meetingId
    );
  }

  async createAttendee(insertAttendee: InsertAttendee): Promise<Attendee> {
    const id = this.attendeeIdCounter++;
    const attendee: Attendee = { 
      ...insertAttendee, 
      id,
      userId: insertAttendee.userId || null,
      name: insertAttendee.name || null,
      email: insertAttendee.email || null,
      role: insertAttendee.role || null,
      organization: insertAttendee.organization || null,
      attendance: insertAttendee.attendance || "pending"
    };
    this.attendees.set(id, attendee);
    return attendee;
  }

  async updateAttendee(id: number, updateData: Partial<Attendee>): Promise<Attendee | undefined> {
    const attendee = this.attendees.get(id);
    if (!attendee) return undefined;
    
    const updatedAttendee = { ...attendee, ...updateData };
    this.attendees.set(id, updatedAttendee);
    return updatedAttendee;
  }

  async deleteAttendee(id: number): Promise<boolean> {
    return this.attendees.delete(id);
  }

  // Action Item methods
  async getActionItem(id: number): Promise<ActionItem | undefined> {
    return this.actionItems.get(id);
  }

  async getActionItemsByMeetingId(meetingId: number): Promise<ActionItem[]> {
    return Array.from(this.actionItems.values()).filter(
      (actionItem) => actionItem.meetingId === meetingId
    );
  }

  async getActionItemsByAssignedTo(userId: number): Promise<ActionItem[]> {
    return Array.from(this.actionItems.values()).filter(
      (actionItem) => actionItem.assignedTo === userId
    );
  }

  async getActionItemsByStatus(status: string): Promise<ActionItem[]> {
    return Array.from(this.actionItems.values()).filter(
      (actionItem) => actionItem.status === status
    );
  }

  async createActionItem(insertActionItem: InsertActionItem): Promise<ActionItem> {
    const id = this.actionItemIdCounter++;
    const actionItem: ActionItem = { 
      ...insertActionItem, 
      id,
      assignedTo: insertActionItem.assignedTo || null,
      dueDate: insertActionItem.dueDate || null,
      status: insertActionItem.status || "open",
      priority: insertActionItem.priority || "medium",
      completedDate: null,
      notes: insertActionItem.notes || null
    };
    this.actionItems.set(id, actionItem);
    return actionItem;
  }

  async updateActionItem(id: number, updateData: Partial<ActionItem>): Promise<ActionItem | undefined> {
    const actionItem = await this.getActionItem(id);
    if (!actionItem) return undefined;
    
    const updatedActionItem = { ...actionItem, ...updateData };
    this.actionItems.set(id, updatedActionItem);
    return updatedActionItem;
  }

  async deleteActionItem(id: number): Promise<boolean> {
    return this.actionItems.delete(id);
  }

  // Document methods
  async getDocument(id: number): Promise<Document | undefined> {
    return this.documents.get(id);
  }

  async getDocumentsByClientId(clientId: number): Promise<Document[]> {
    return Array.from(this.documents.values()).filter(
      (document) => document.clientId === clientId
    );
  }

  async getDocumentsByMeetingId(meetingId: number): Promise<Document[]> {
    return Array.from(this.documents.values()).filter(
      (document) => document.meetingId === meetingId
    );
  }

  async createDocument(insertDocument: InsertDocument): Promise<Document> {
    const id = this.documentIdCounter++;
    const uploadedAt = new Date();
    const document: Document = { 
      ...insertDocument, 
      id, 
      uploadedAt,
      clientId: insertDocument.clientId || null,
      meetingId: insertDocument.meetingId || null,
      type: insertDocument.type || null,
      description: insertDocument.description || null
    };
    this.documents.set(id, document);
    return document;
  }

  async updateDocument(id: number, updateData: Partial<Document>): Promise<Document | undefined> {
    const document = await this.getDocument(id);
    if (!document) return undefined;
    
    const updatedDocument = { ...document, ...updateData };
    this.documents.set(id, updatedDocument);
    return updatedDocument;
  }

  async deleteDocument(id: number): Promise<boolean> {
    return this.documents.delete(id);
  }

  // Report methods
  async getReport(id: number): Promise<Report | undefined> {
    return this.reports.get(id);
  }

  async getReportsByUserId(userId: number): Promise<Report[]> {
    return Array.from(this.reports.values()).filter(
      (report) => report.userId === userId
    );
  }

  async createReport(insertReport: InsertReport): Promise<Report> {
    const id = this.reportIdCounter++;
    const createdAt = new Date();
    const updatedAt = new Date();
    const report: Report = { 
      ...insertReport, 
      id, 
      createdAt, 
      updatedAt,
      description: insertReport.description || null,
      isDefault: insertReport.isDefault || false
    };
    this.reports.set(id, report);
    return report;
  }

  async updateReport(id: number, updateData: Partial<Report>): Promise<Report | undefined> {
    const report = await this.getReport(id);
    if (!report) return undefined;
    
    const updatedReport = { 
      ...report, 
      ...updateData, 
      updatedAt: new Date() 
    };
    this.reports.set(id, updatedReport);
    return updatedReport;
  }

  async deleteReport(id: number): Promise<boolean> {
    return this.reports.delete(id);
  }

  // Initialize with sample data
  private initializeSampleData() {
    // Sample users for testing
    const usersData: InsertUser[] = [
      {
        username: "admin",
        password: "password",
        name: "Admin User",
        role: "admin",
        department: "Management",
        email: "admin@yourcollegeplug.com",
        phone: "555-123-4567",
        profileCompleted: 100
      },
      {
        username: "advisor",
        password: "password",
        name: "College Advisor",
        role: "advisor",
        department: "Counseling",
        email: "advisor@yourcollegeplug.com",
        phone: "555-987-6543",
        profileCompleted: 100
      },
      {
        username: "student",
        password: "password",
        name: "Student User",
        role: "student",
        department: "Applicants",
        email: "student@example.com",
        phone: "555-456-7890",
        profileCompleted: 80
      }
    ];

    // Add sample users
    usersData.forEach(user => {
      this.createUser(user);
    });
    
    // Sample clients
    const clientsData: InsertClient[] = [
      {
        name: "Harvard University",
        contactPerson: "John Smith",
        email: "admissions@harvard.edu",
        phone: "555-123-4567",
        address: "Cambridge, MA 02138",
        industry: "Education",
        priority: "high",
        notes: "Ivy League institution with strong research focus"
      },
      {
        name: "Stanford University",
        contactPerson: "Jane Doe",
        email: "admissions@stanford.edu",
        phone: "555-987-6543",
        address: "Stanford, CA 94305",
        industry: "Education",
        priority: "high",
        notes: "Strong programs in technology and entrepreneurship"
      },
      {
        name: "MIT",
        contactPerson: "James Wilson",
        email: "admissions@mit.edu",
        phone: "555-456-7890",
        address: "Cambridge, MA 02139",
        industry: "Education",
        priority: "high",
        notes: "Premier institution for science and engineering"
      },
      {
        name: "UC Berkeley",
        contactPerson: "Tony Clark",
        email: "admissions@berkeley.edu",
        phone: "555-789-0123",
        address: "Berkeley, CA 94720",
        industry: "Education",
        priority: "medium",
        notes: "Leading public research university"
      },
      {
        name: "NYU",
        contactPerson: "Alice Johnson",
        email: "admissions@nyu.edu",
        phone: "555-321-6547",
        address: "New York, NY 10012",
        industry: "Education",
        priority: "medium",
        notes: "Urban campus with strong arts programs"
      }
    ];

    // Add sample clients
    clientsData.forEach(client => {
      this.createClient(client);
    });
  }
}

// Import the database storage implementation
import { DatabaseStorage } from "./DatabaseStorage";

// Switch between memory storage and database storage based on environment
export const storage = process.env.USE_MEMORY_STORAGE === "true" 
  ? new MemStorage() 
  : new DatabaseStorage();
