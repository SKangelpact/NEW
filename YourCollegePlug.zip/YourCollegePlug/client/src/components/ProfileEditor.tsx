import { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useAuth } from './AuthContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { 
  Form, 
  FormControl, 
  FormDescription, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';

interface ProfileEditorProps {
  isOpen: boolean;
  onClose: () => void;
}

const formSchema = z.object({
  name: z.string().optional(),
  gpa: z.string().optional()
    .refine(val => !val || parseFloat(val) >= 0, {
      message: "GPA must be a positive number",
    })
    .refine(val => !val || parseFloat(val) <= 5.0, {
      message: "GPA cannot exceed 5.0",
    }),
  sat: z.string().optional()
    .refine(val => !val || (parseInt(val) >= 400 && parseInt(val) <= 1600), {
      message: "SAT score must be between 400 and 1600",
    }),
  act: z.string().optional()
    .refine(val => !val || (parseInt(val) >= 1 && parseInt(val) <= 36), {
      message: "ACT score must be between 1 and 36",
    }),
  extracurriculars: z.string().optional(),
  academicInterests: z.string().optional(),
});

export default function ProfileEditor({ isOpen, onClose }: ProfileEditorProps) {
  const { user, updateUser } = useAuth();
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: user?.name || '',
      gpa: user?.gpa || '',
      sat: user?.testScores?.sat?.toString() || '',
      act: user?.testScores?.act?.toString() || '',
      extracurriculars: user?.extracurriculars || '',
      academicInterests: user?.academicInterests || '',
    },
  });

  // Update form values when user data changes
  useEffect(() => {
    if (user) {
      form.reset({
        name: user.name || '',
        gpa: user.gpa || '',
        sat: user.testScores?.sat?.toString() || '',
        act: user.testScores?.act?.toString() || '',
        extracurriculars: user.extracurriculars || '',
        academicInterests: user.academicInterests || '',
      });
    }
  }, [user, form.reset, form]);

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    try {
      const updateData = {
        name: values.name,
        gpa: values.gpa,
        testScores: {
          ...(user?.testScores || {}),
          sat: values.sat ? parseInt(values.sat) : undefined,
          act: values.act ? parseInt(values.act) : undefined,
        },
        extracurriculars: values.extracurriculars,
        academicInterests: values.academicInterests,
      };
      
      // Calculate profile completion percentage (simple version)
      let completedSections = 0;
      if (values.name) completedSections++;
      if (values.gpa) completedSections++;
      if (values.sat || values.act) completedSections++;
      if (values.extracurriculars) completedSections++;
      if (values.academicInterests) completedSections++;
      
      const profileCompleted = Math.round((completedSections / 5) * 100);
      
      await updateUser({
        ...updateData,
        profileCompleted,
      });
      
      onClose();
    } catch (error) {
      console.error('Error updating profile:', error);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={isOpen => !isOpen && onClose()}>
      <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-lg font-medium text-gray-900">Update Your Profile</DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="mt-6 space-y-6">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Full Name</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., Alex Smith" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="gpa"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>GPA</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      step="0.01" 
                      placeholder="e.g., 3.85" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="sat"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>SAT Score</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      placeholder="e.g., 1400" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="act"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>ACT Score</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      placeholder="e.g., 32" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="extracurriculars"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Extracurricular Activities</FormLabel>
                  <FormDescription className="text-xs text-gray-500">
                    Separate activities with commas
                  </FormDescription>
                  <FormControl>
                    <Textarea 
                      rows={3} 
                      placeholder="e.g., Student Council, Robotics Club, Volunteer Work" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="academicInterests"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Academic Interests</FormLabel>
                  <FormDescription className="text-xs text-gray-500">
                    Separate interests with commas
                  </FormDescription>
                  <FormControl>
                    <Textarea 
                      rows={2} 
                      placeholder="e.g., Computer Science, Biology" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <DialogFooter className="flex justify-end pt-6 border-t border-gray-200">
              <Button 
                type="button" 
                variant="outline" 
                onClick={onClose}
                className="bg-white border-gray-300 text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                className="ml-3 bg-primary-600 hover:bg-primary-700 text-white"
              >
                Save
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
