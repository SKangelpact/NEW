import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import Layout from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { FileText, Upload, Check, Loader2, MessageSquare, ThumbsUp, ThumbsDown, Lightbulb, BarChart } from "lucide-react";

interface Essay {
  id: number;
  title: string;
  content: string;
  wordCount: number;
  prompt: string;
  college?: string;
  status: "draft" | "submitted" | "feedback" | "revised";
  lastUpdated: string;
}

interface Feedback {
  overall: string;
  strengths: string[];
  improvements: string[];
  suggestions: string;
  score: {
    clarity: number;
    originality: number;
    relevance: number;
    grammar: number;
    overall: number;
  };
}

export default function EssayFeedbackPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("my-essays");
  const [selectedEssay, setSelectedEssay] = useState<Essay | null>(null);
  const [essayFeedback, setEssayFeedback] = useState<Feedback | null>(null);
  const [newEssay, setNewEssay] = useState({
    title: "",
    prompt: "",
    college: "",
    content: ""
  });

  // Mock essays data
  const myEssays: Essay[] = [
    {
      id: 1,
      title: "Common App Personal Statement",
      content: "Throughout my high school career, I've always been drawn to solving complex problems...",
      wordCount: 647,
      prompt: "Some students have a background, identity, interest, or talent that is so meaningful...",
      status: "feedback",
      lastUpdated: "2 days ago"
    },
    {
      id: 2,
      title: "Why Harvard?",
      content: "Harvard's dedication to academic excellence and innovation resonates deeply with me...",
      wordCount: 412,
      prompt: "Please briefly elaborate on one of your extracurricular activities or work experiences.",
      college: "Harvard University",
      status: "draft",
      lastUpdated: "1 week ago"
    },
    {
      id: 3,
      title: "Leadership Experience",
      content: "When I was elected president of our school's environmental club, I faced numerous challenges...",
      wordCount: 523,
      prompt: "Describe a leadership experience that has been particularly meaningful to you.",
      college: "Stanford University",
      status: "submitted",
      lastUpdated: "3 days ago"
    }
  ];

  // Mock feedback data
  const mockFeedback: Feedback = {
    overall: "Your essay effectively shares your personal growth through problem-solving experiences. The narrative is engaging, but could benefit from more specific examples and a stronger conclusion.",
    strengths: [
      "Strong opening that immediately captures interest",
      "Clear narrative arc showing personal development",
      "Effective use of specific examples to illustrate growth",
      "Authentic voice that conveys genuine passion"
    ],
    improvements: [
      "Consider strengthening your conclusion to better reflect your future goals",
      "Add more detail about how this experience connects to your intended field of study",
      "Some sentences are overly complex and could be streamlined",
      "The middle section would benefit from more concrete examples"
    ],
    suggestions: "Try connecting your problem-solving experiences more directly to your academic interests. Consider adding a brief anecdote about a specific challenge you overcame that demonstrates your analytical skills. Your conclusion could be stronger if you explicitly connect your past experiences to your future goals at college.",
    score: {
      clarity: 8,
      originality: 7,
      relevance: 9,
      grammar: 8,
      overall: 8
    }
  };

  const getStatusBadge = (status: Essay["status"]) => {
    switch (status) {
      case "draft":
        return <Badge variant="outline">Draft</Badge>;
      case "submitted":
        return <Badge variant="secondary">Submitted for Review</Badge>;
      case "feedback":
        return <Badge variant="default">Feedback Available</Badge>;
      case "revised":
        return <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300">Revised</Badge>;
      default:
        return null;
    }
  };

  const submitEssayMutation = useMutation({
    mutationFn: async (essayId: number) => {
      // This would be an API call in a real implementation
      return { success: true };
    },
    onSuccess: () => {
      toast({
        title: "Essay Submitted",
        description: "Your essay has been submitted for review.",
      });
    }
  });

  const requestAiFeedbackMutation = useMutation({
    mutationFn: async (essayId: number) => {
      // This would be an API call in a real implementation
      // Simulating API delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      return mockFeedback;
    },
    onSuccess: (data) => {
      setEssayFeedback(data);
      toast({
        title: "AI Feedback Generated",
        description: "AI-powered feedback is now available for your essay.",
      });
    }
  });

  const createEssayMutation = useMutation({
    mutationFn: async (essay: typeof newEssay) => {
      // This would be an API call in a real implementation
      return { id: Date.now(), ...essay, wordCount: essay.content.split(' ').length, status: "draft" as const, lastUpdated: "Just now" };
    },
    onSuccess: (data) => {
      toast({
        title: "Essay Created",
        description: "Your new essay has been saved as a draft.",
      });
      setActiveTab("my-essays");
      setNewEssay({ title: "", prompt: "", college: "", content: "" });
    }
  });

  const handleSelectEssay = (essay: Essay) => {
    setSelectedEssay(essay);
    if (essay.status === "feedback") {
      setEssayFeedback(mockFeedback);
    } else {
      setEssayFeedback(null);
    }
  };

  const handleSubmitForReview = () => {
    if (selectedEssay) {
      submitEssayMutation.mutate(selectedEssay.id);
    }
  };

  const handleRequestFeedback = () => {
    if (selectedEssay) {
      requestAiFeedbackMutation.mutate(selectedEssay.id);
    }
  };

  const handleCreateEssay = () => {
    if (!newEssay.title || !newEssay.prompt || !newEssay.content) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }
    createEssayMutation.mutate(newEssay);
  };

  const ScoreIndicator = ({ score, label }: { score: number, label: string }) => (
    <div className="space-y-1">
      <div className="flex justify-between items-center">
        <span className="text-sm font-medium">{label}</span>
        <span className="text-sm font-medium">{score}/10</span>
      </div>
      <div className="w-full bg-secondary h-2 rounded-full overflow-hidden">
        <div 
          className="bg-primary h-full rounded-full transition-all duration-500 ease-in-out"
          style={{ width: `${score * 10}%` }}
        />
      </div>
    </div>
  );

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-col space-y-2">
          <h1 className="text-3xl font-bold">Essay Feedback</h1>
          <p className="text-muted-foreground">
            Write, review, and get AI-powered feedback on your college application essays
          </p>
        </div>

        <Tabs defaultValue="my-essays" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="my-essays">My Essays</TabsTrigger>
            <TabsTrigger value="new-essay">New Essay</TabsTrigger>
            <TabsTrigger value="templates">Templates</TabsTrigger>
          </TabsList>

          <TabsContent value="my-essays">
            <div className="grid gap-6 lg:grid-cols-3">
              {/* Essay List */}
              <div className="space-y-4">
                <h2 className="text-xl font-semibold">Your Essays</h2>
                <div className="space-y-3">
                  {myEssays.map((essay) => (
                    <Card 
                      key={essay.id} 
                      className={`cursor-pointer transition-colors ${
                        selectedEssay?.id === essay.id ? "border-primary" : ""
                      }`}
                      onClick={() => handleSelectEssay(essay)}
                    >
                      <CardHeader className="p-4 pb-2">
                        <div className="flex justify-between items-start">
                          <CardTitle className="text-base">{essay.title}</CardTitle>
                          {getStatusBadge(essay.status)}
                        </div>
                        <CardDescription>
                          {essay.college && `For: ${essay.college}`}
                          {!essay.college && "Common Application"}
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="p-4 pt-0 pb-2">
                        <p className="text-sm line-clamp-2">{essay.content}</p>
                      </CardContent>
                      <CardFooter className="p-4 pt-0 flex justify-between text-xs text-muted-foreground">
                        <span>{essay.wordCount} words</span>
                        <span>Updated {essay.lastUpdated}</span>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </div>

              {/* Essay Content and Feedback */}
              <div className="lg:col-span-2">
                {selectedEssay ? (
                  <div className="space-y-4">
                    <Card>
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle>{selectedEssay.title}</CardTitle>
                            <CardDescription>
                              {selectedEssay.college && `For: ${selectedEssay.college}`}
                              {!selectedEssay.college && "Common Application"}
                            </CardDescription>
                          </div>
                          <div className="flex space-x-2">
                            {selectedEssay.status === "draft" && (
                              <Button size="sm" onClick={handleSubmitForReview}>
                                <Upload className="h-4 w-4 mr-2" />
                                Submit for Review
                              </Button>
                            )}
                            {(selectedEssay.status === "draft" || selectedEssay.status === "submitted") && (
                              <Button size="sm" variant="outline" onClick={handleRequestFeedback} disabled={requestAiFeedbackMutation.isPending}>
                                {requestAiFeedbackMutation.isPending ? (
                                  <>
                                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                    Generating...
                                  </>
                                ) : (
                                  <>
                                    <MessageSquare className="h-4 w-4 mr-2" />
                                    Get AI Feedback
                                  </>
                                )}
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div>
                            <Label className="text-muted-foreground">Prompt</Label>
                            <p className="mt-1 text-sm">{selectedEssay.prompt}</p>
                          </div>
                          <Separator />
                          <div>
                            <Label>Essay Content</Label>
                            <div className="mt-2 p-4 border rounded-md bg-muted/30 whitespace-pre-wrap">
                              {selectedEssay.content}
                            </div>
                            <div className="mt-2 text-xs text-right text-muted-foreground">
                              {selectedEssay.wordCount} words
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {essayFeedback && (
                      <Card>
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2">
                            <FileText className="h-5 w-5 text-primary" />
                            AI-Powered Feedback
                          </CardTitle>
                          <CardDescription>
                            Analysis and suggestions to improve your essay
                          </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                          <div>
                            <h3 className="text-lg font-medium mb-2">Overall Assessment</h3>
                            <p className="text-sm">{essayFeedback.overall}</p>
                          </div>

                          <div className="grid md:grid-cols-2 gap-6">
                            <div>
                              <h3 className="text-lg font-medium mb-2 flex items-center gap-2">
                                <ThumbsUp className="h-5 w-5 text-green-500" />
                                Strengths
                              </h3>
                              <ul className="space-y-2">
                                {essayFeedback.strengths.map((strength, index) => (
                                  <li key={index} className="text-sm flex items-start gap-2">
                                    <Check className="h-4 w-4 text-green-500 mt-0.5" />
                                    <span>{strength}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>

                            <div>
                              <h3 className="text-lg font-medium mb-2 flex items-center gap-2">
                                <ThumbsDown className="h-5 w-5 text-amber-500" />
                                Areas for Improvement
                              </h3>
                              <ul className="space-y-2">
                                {essayFeedback.improvements.map((improvement, index) => (
                                  <li key={index} className="text-sm flex items-start gap-2">
                                    <span className="text-amber-500 mt-0.5">•</span>
                                    <span>{improvement}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          </div>

                          <div>
                            <h3 className="text-lg font-medium mb-2 flex items-center gap-2">
                              <Lightbulb className="h-5 w-5 text-blue-500" />
                              Suggestions for Improvement
                            </h3>
                            <p className="text-sm">{essayFeedback.suggestions}</p>
                          </div>

                          <div>
                            <h3 className="text-lg font-medium mb-3 flex items-center gap-2">
                              <BarChart className="h-5 w-5 text-violet-500" />
                              Essay Evaluation
                            </h3>
                            <div className="space-y-3">
                              <ScoreIndicator score={essayFeedback.score.clarity} label="Clarity" />
                              <ScoreIndicator score={essayFeedback.score.originality} label="Originality" />
                              <ScoreIndicator score={essayFeedback.score.relevance} label="Relevance to Prompt" />
                              <ScoreIndicator score={essayFeedback.score.grammar} label="Grammar & Style" />
                              <div className="pt-2 border-t mt-3">
                                <ScoreIndicator score={essayFeedback.score.overall} label="Overall Score" />
                              </div>
                            </div>
                          </div>
                        </CardContent>
                        <CardFooter>
                          <Button className="w-full">Apply AI Suggestions to Essay</Button>
                        </CardFooter>
                      </Card>
                    )}
                  </div>
                ) : (
                  <Card className="h-full flex items-center justify-center p-10">
                    <div className="text-center">
                      <FileText className="h-10 w-10 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-lg font-medium mb-2">Select an Essay</h3>
                      <p className="text-muted-foreground">
                        Choose an essay from the list to view its content and feedback
                      </p>
                    </div>
                  </Card>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="new-essay">
            <Card>
              <CardHeader>
                <CardTitle>Create a New Essay</CardTitle>
                <CardDescription>
                  Start a new college application essay from scratch
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="essay-title">Essay Title</Label>
                      <Input 
                        id="essay-title" 
                        placeholder="e.g., Personal Statement, Why This College" 
                        value={newEssay.title}
                        onChange={(e) => setNewEssay({...newEssay, title: e.target.value})}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="essay-college">College (Optional)</Label>
                      <Input 
                        id="essay-college" 
                        placeholder="e.g., Harvard University" 
                        value={newEssay.college}
                        onChange={(e) => setNewEssay({...newEssay, college: e.target.value})}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="essay-prompt">Essay Prompt</Label>
                    <Textarea 
                      id="essay-prompt" 
                      placeholder="Enter the essay prompt or question..."
                      rows={2}
                      value={newEssay.prompt}
                      onChange={(e) => setNewEssay({...newEssay, prompt: e.target.value})}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="essay-content">Essay Content</Label>
                    <Textarea 
                      id="essay-content" 
                      placeholder="Start writing your essay here..."
                      rows={10}
                      value={newEssay.content}
                      onChange={(e) => setNewEssay({...newEssay, content: e.target.value})}
                    />
                    <div className="text-xs text-right text-muted-foreground">
                      {newEssay.content.split(' ').filter(Boolean).length} words
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button 
                  variant="outline" 
                  onClick={() => setNewEssay({ title: "", prompt: "", college: "", content: "" })}
                >
                  Cancel
                </Button>
                <Button onClick={handleCreateEssay} disabled={createEssayMutation.isPending}>
                  {createEssayMutation.isPending ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    "Save Essay"
                  )}
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="templates">
            <div className="space-y-6">
              <div className="max-w-2xl mx-auto text-center">
                <h2 className="text-2xl font-bold mb-2">Essay Templates & Guides</h2>
                <p className="text-muted-foreground">
                  Use these templates and guides to kickstart your college application essays
                </p>
              </div>

              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <Card>
                  <CardHeader>
                    <CardTitle>Personal Statement Template</CardTitle>
                    <CardDescription>
                      For the Common Application main essay
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm mb-4">
                      A structured template for crafting a compelling personal statement that showcases your
                      unique qualities and experiences.
                    </p>
                    <div className="text-sm">
                      <div className="font-medium">Suggested Structure:</div>
                      <ul className="list-disc list-inside space-y-1 mt-2 text-muted-foreground">
                        <li>Engaging hook/anecdote</li>
                        <li>Background context</li>
                        <li>Challenge or obstacle</li>
                        <li>Growth and reflection</li>
                        <li>Connection to future goals</li>
                      </ul>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full">Use Template</Button>
                  </CardFooter>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>"Why This College" Template</CardTitle>
                    <CardDescription>
                      For school-specific supplemental essays
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm mb-4">
                      A framework for writing convincing essays about why you're a perfect fit for a specific college
                      or university.
                    </p>
                    <div className="text-sm">
                      <div className="font-medium">Key Components:</div>
                      <ul className="list-disc list-inside space-y-1 mt-2 text-muted-foreground">
                        <li>Specific academic programs</li>
                        <li>Unique campus opportunities</li>
                        <li>Faculty you want to work with</li>
                        <li>Campus culture elements</li>
                        <li>How you'll contribute</li>
                      </ul>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full">Use Template</Button>
                  </CardFooter>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Extracurricular Activity Essay</CardTitle>
                    <CardDescription>
                      For activity-focused supplemental essays
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm mb-4">
                      A template for essays that highlight your meaningful involvement in activities outside the classroom.
                    </p>
                    <div className="text-sm">
                      <div className="font-medium">Essay Framework:</div>
                      <ul className="list-disc list-inside space-y-1 mt-2 text-muted-foreground">
                        <li>Activity introduction</li>
                        <li>Your specific role</li>
                        <li>Challenges faced</li>
                        <li>Skills developed</li>
                        <li>Impact on you and others</li>
                      </ul>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full">Use Template</Button>
                  </CardFooter>
                </Card>
              </div>

              <div className="mt-8 max-w-2xl mx-auto">
                <Card>
                  <CardHeader>
                    <CardTitle>Essay Writing Resources</CardTitle>
                    <CardDescription>
                      Helpful guides and tools for crafting standout essays
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center p-3 bg-muted/50 rounded-md">
                        <div>
                          <p className="font-medium">College Essay Guide: Do's and Don'ts</p>
                          <p className="text-sm text-muted-foreground">Comprehensive tips for what works and what doesn't</p>
                        </div>
                        <Button variant="outline" size="sm">View</Button>
                      </div>
                      <div className="flex justify-between items-center p-3 bg-muted/50 rounded-md">
                        <div>
                          <p className="font-medium">Brainstorming Worksheet</p>
                          <p className="text-sm text-muted-foreground">Structured exercises to help generate essay topics</p>
                        </div>
                        <Button variant="outline" size="sm">Download</Button>
                      </div>
                      <div className="flex justify-between items-center p-3 bg-muted/50 rounded-md">
                        <div>
                          <p className="font-medium">Sample Essays with Analysis</p>
                          <p className="text-sm text-muted-foreground">Real successful essays with expert commentary</p>
                        </div>
                        <Button variant="outline" size="sm">View</Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}