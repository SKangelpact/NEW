import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Layout from "@/components/layout";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { College } from "@shared/schema";
import { Loader2, Search, Mail, Phone, Calendar, ExternalLink, User, Users, MapPin, DollarSign } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function ConnectPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [activeTab, setActiveTab] = useState("admissions");
  const [selectedCollege, setSelectedCollege] = useState<College | null>(null);
  const [messageForm, setMessageForm] = useState({
    subject: "",
    message: ""
  });

  const { data: colleges, isLoading } = useQuery<College[]>({
    queryKey: ["/api/colleges"],
    enabled: !!user,
  });

  const filteredColleges = colleges?.filter(college => 
    !searchTerm || college.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Mock colleges for initial development
  const mockColleges: College[] = [
    {
      id: 1,
      name: "Harvard University",
      selectivityCategory: "reach",
      averageGPA: 4.0,
      tuitionCost: 54000,
      popularMajors: "Computer Science, Economics, Biology",
      location: "Cambridge, MA",
      size: "Medium",
      acceptanceRate: 0.04,
      website: "https://www.harvard.edu",
      description: "Harvard University is a private Ivy League research university in Cambridge, Massachusetts.",
      createdAt: new Date(),
    },
    {
      id: 2,
      name: "Stanford University",
      selectivityCategory: "reach",
      averageGPA: 3.95,
      tuitionCost: 56000,
      popularMajors: "Engineering, Computer Science, Business",
      location: "Stanford, CA",
      size: "Medium",
      acceptanceRate: 0.04,
      website: "https://www.stanford.edu",
      description: "Stanford University is a private research university in Stanford, California.",
      createdAt: new Date(),
    },
    {
      id: 3,
      name: "University of Michigan",
      selectivityCategory: "match",
      averageGPA: 3.8,
      tuitionCost: 49000,
      popularMajors: "Business, Engineering, Psychology",
      location: "Ann Arbor, MI",
      size: "Large",
      acceptanceRate: 0.23,
      website: "https://www.umich.edu",
      description: "The University of Michigan is a public research university in Ann Arbor, Michigan.",
      createdAt: new Date(),
    },
    {
      id: 4,
      name: "Ohio State University",
      selectivityCategory: "safety",
      averageGPA: 3.6,
      tuitionCost: 32000,
      popularMajors: "Business, Engineering, Health Sciences",
      location: "Columbus, OH",
      size: "Large",
      acceptanceRate: 0.54,
      website: "https://www.osu.edu",
      description: "The Ohio State University is a public research university in Columbus, Ohio.",
      createdAt: new Date(),
    },
  ];

  const displayColleges = filteredColleges || mockColleges;

  const handleSelectCollege = (college: College) => {
    setSelectedCollege(college);
  };

  const handleSendMessage = () => {
    if (!messageForm.subject || !messageForm.message) {
      toast({
        title: "Error",
        description: "Please complete all fields in the message form",
        variant: "destructive",
      });
      return;
    }

    // API call would go here in a real implementation
    toast({
      title: "Message Sent",
      description: `Your message has been sent to ${selectedCollege?.name}`,
    });
    
    setMessageForm({
      subject: "",
      message: ""
    });
  };

  const handleScheduleTour = () => {
    toast({
      title: "Tour Scheduled",
      description: `Your campus tour request for ${selectedCollege?.name} has been submitted`,
    });
  };

  // Mock contact information
  const admissionsContact = {
    email: "admissions@example.edu",
    phone: "(555) 123-4567",
    hours: "Monday-Friday, 9am-5pm EST"
  };

  const financialAidContact = {
    email: "finaid@example.edu",
    phone: "(555) 987-6543",
    hours: "Monday-Friday, 10am-4pm EST"
  };

  // Mock events
  const upcomingEvents = [
    { id: 1, title: "Virtual Information Session", date: "June 15, 2025", type: "Virtual" },
    { id: 2, title: "Campus Tour", date: "July 10, 2025", type: "In-Person" },
    { id: 3, title: "Financial Aid Workshop", date: "July 25, 2025", type: "Virtual" },
  ];

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-col space-y-2">
          <h1 className="text-3xl font-bold">Connect with Colleges</h1>
          <p className="text-muted-foreground">
            Reach out to admissions offices, schedule tours, and attend events
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* College List */}
          <div className="lg:col-span-1 space-y-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle>Find a College</CardTitle>
                <CardDescription>
                  Search for a college to connect with
                </CardDescription>
                <div className="relative mt-2">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search colleges..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </CardHeader>
              <CardContent className="max-h-[60vh] overflow-y-auto">
                {isLoading ? (
                  <div className="flex justify-center py-10">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : (
                  <div className="space-y-2">
                    {displayColleges.map((college) => (
                      <div
                        key={college.id}
                        className={`p-3 rounded-md cursor-pointer transition-colors ${
                          selectedCollege?.id === college.id
                            ? "bg-primary text-primary-foreground"
                            : "hover:bg-muted"
                        }`}
                        onClick={() => handleSelectCollege(college)}
                      >
                        <div className="font-medium">{college.name}</div>
                        <div className="text-sm flex items-center gap-1 mt-1">
                          <MapPin className="h-3 w-3" />
                          {college.location}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Contact Details */}
          <div className="lg:col-span-2 space-y-4">
            {selectedCollege ? (
              <>
                <Card>
                  <CardHeader>
                    <CardTitle>{selectedCollege.name}</CardTitle>
                    <CardDescription>
                      Connect with admissions and learn about upcoming events
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Tabs defaultValue="admissions" value={activeTab} onValueChange={setActiveTab}>
                      <TabsList className="grid grid-cols-3 mb-6">
                        <TabsTrigger value="admissions">Admissions</TabsTrigger>
                        <TabsTrigger value="financialAid">Financial Aid</TabsTrigger>
                        <TabsTrigger value="events">Events</TabsTrigger>
                      </TabsList>

                      <TabsContent value="admissions" className="space-y-4">
                        <div className="grid gap-4 md:grid-cols-2">
                          <div className="space-y-2">
                            <h3 className="text-lg font-medium">Contact Information</h3>
                            <div className="space-y-2">
                              <div className="flex items-center gap-2">
                                <Mail className="h-4 w-4 text-muted-foreground" />
                                <span>{admissionsContact.email}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <Phone className="h-4 w-4 text-muted-foreground" />
                                <span>{admissionsContact.phone}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <Calendar className="h-4 w-4 text-muted-foreground" />
                                <span>{admissionsContact.hours}</span>
                              </div>
                            </div>
                          </div>
                          <div className="space-y-2">
                            <h3 className="text-lg font-medium">Quick Links</h3>
                            <div className="space-y-2">
                              <Button variant="outline" className="w-full justify-start" asChild>
                                <a href={selectedCollege.website} target="_blank" rel="noopener noreferrer">
                                  <ExternalLink className="mr-2 h-4 w-4" />
                                  Visit Website
                                </a>
                              </Button>
                              <Button variant="outline" className="w-full justify-start" onClick={handleScheduleTour}>
                                <Calendar className="mr-2 h-4 w-4" />
                                Schedule Campus Tour
                              </Button>
                              <Button variant="outline" className="w-full justify-start" asChild>
                                <a href={`${selectedCollege.website}/apply`} target="_blank" rel="noopener noreferrer">
                                  <User className="mr-2 h-4 w-4" />
                                  Apply Now
                                </a>
                              </Button>
                            </div>
                          </div>
                        </div>

                        <div className="space-y-2 mt-6">
                          <h3 className="text-lg font-medium">Send a Message</h3>
                          <div className="space-y-4">
                            <div className="space-y-2">
                              <Label htmlFor="subject">Subject</Label>
                              <Input
                                id="subject"
                                placeholder="e.g., Question about admissions requirements"
                                value={messageForm.subject}
                                onChange={(e) => setMessageForm({...messageForm, subject: e.target.value})}
                              />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="message">Message</Label>
                              <Textarea
                                id="message"
                                placeholder="Type your message here..."
                                rows={4}
                                value={messageForm.message}
                                onChange={(e) => setMessageForm({...messageForm, message: e.target.value})}
                              />
                            </div>
                            <Button onClick={handleSendMessage}>Send Message</Button>
                          </div>
                        </div>
                      </TabsContent>

                      <TabsContent value="financialAid" className="space-y-4">
                        <div className="grid gap-4 md:grid-cols-2">
                          <div className="space-y-2">
                            <h3 className="text-lg font-medium">Financial Aid Office</h3>
                            <div className="space-y-2">
                              <div className="flex items-center gap-2">
                                <Mail className="h-4 w-4 text-muted-foreground" />
                                <span>{financialAidContact.email}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <Phone className="h-4 w-4 text-muted-foreground" />
                                <span>{financialAidContact.phone}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <Calendar className="h-4 w-4 text-muted-foreground" />
                                <span>{financialAidContact.hours}</span>
                              </div>
                            </div>
                          </div>
                          <div className="space-y-2">
                            <h3 className="text-lg font-medium">Quick Info</h3>
                            <div className="space-y-2 text-sm">
                              <p><strong>Annual Tuition:</strong> ${selectedCollege.tuitionCost?.toLocaleString()}</p>
                              <p><strong>Financial Aid Deadline:</strong> February 1, 2026</p>
                              <p><strong>Average Financial Aid Package:</strong> $42,500</p>
                            </div>
                            <Button variant="outline" className="w-full justify-start mt-4" asChild>
                              <a href={`${selectedCollege.website}/financial-aid`} target="_blank" rel="noopener noreferrer">
                                <DollarSign className="mr-2 h-4 w-4" />
                                Financial Aid Resources
                              </a>
                            </Button>
                          </div>
                        </div>

                        <div className="space-y-2 mt-6">
                          <h3 className="text-lg font-medium">Request Financial Aid Information</h3>
                          <div className="space-y-4">
                            <div className="space-y-2">
                              <Label htmlFor="subject">Subject</Label>
                              <Input
                                id="subject"
                                placeholder="e.g., Question about scholarships"
                                value={messageForm.subject}
                                onChange={(e) => setMessageForm({...messageForm, subject: e.target.value})}
                              />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="message">Message</Label>
                              <Textarea
                                id="message"
                                placeholder="Type your message here..."
                                rows={4}
                                value={messageForm.message}
                                onChange={(e) => setMessageForm({...messageForm, message: e.target.value})}
                              />
                            </div>
                            <Button onClick={handleSendMessage}>Send Request</Button>
                          </div>
                        </div>
                      </TabsContent>

                      <TabsContent value="events" className="space-y-4">
                        <h3 className="text-lg font-medium">Upcoming Events</h3>
                        <div className="space-y-4">
                          {upcomingEvents.map((event) => (
                            <Card key={event.id}>
                              <CardHeader className="pb-2">
                                <CardTitle className="text-base">{event.title}</CardTitle>
                                <CardDescription>{event.date}</CardDescription>
                              </CardHeader>
                              <CardContent className="pb-2">
                                <div className="flex items-center gap-2 text-sm">
                                  <Users className="h-4 w-4 text-muted-foreground" />
                                  <span>Event Type: {event.type}</span>
                                </div>
                              </CardContent>
                              <CardFooter>
                                <Button variant="outline" size="sm" className="mr-2">
                                  More Info
                                </Button>
                                <Button size="sm">Register</Button>
                              </CardFooter>
                            </Card>
                          ))}
                        </div>

                        <div className="mt-4">
                          <Button variant="outline" className="w-full">
                            View All Events
                          </Button>
                        </div>
                      </TabsContent>
                    </Tabs>
                  </CardContent>
                </Card>
              </>
            ) : (
              <Card className="h-full flex items-center justify-center p-10">
                <div className="text-center">
                  <h3 className="text-lg font-medium mb-2">Select a College</h3>
                  <p className="text-muted-foreground">
                    Choose a college from the list to view contact information and connect with admissions officers
                  </p>
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}