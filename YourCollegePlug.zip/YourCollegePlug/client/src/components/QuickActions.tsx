import { Link } from 'wouter';
import { 
  Pencil, 
  FileText, 
  BarChart, 
  HelpCircle 
} from 'lucide-react';

export default function QuickActions() {
  return (
    <div className="bg-white shadow rounded-lg p-6">
      <div className="space-y-3">
        <Link href="/profile">
          <a className="block p-3 bg-gray-50 rounded-lg hover:bg-gray-100">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-primary-100 p-2 rounded-md">
                <Pencil className="h-5 w-5 text-primary-600" />
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-gray-900">Update Profile</h3>
                <p className="text-xs text-gray-500">Add missing test scores and activities</p>
              </div>
            </div>
          </a>
        </Link>
        
        <Link href="/resources#essays">
          <a className="block p-3 bg-gray-50 rounded-lg hover:bg-gray-100">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-primary-100 p-2 rounded-md">
                <FileText className="h-5 w-5 text-primary-600" />
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-gray-900">Work on Essays</h3>
                <p className="text-xs text-gray-500">Continue your personal statement draft</p>
              </div>
            </div>
          </a>
        </Link>
        
        <Link href="/colleges#stats">
          <a className="block p-3 bg-gray-50 rounded-lg hover:bg-gray-100">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-primary-100 p-2 rounded-md">
                <BarChart className="h-5 w-5 text-primary-600" />
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-gray-900">View Application Stats</h3>
                <p className="text-xs text-gray-500">Track your application progress</p>
              </div>
            </div>
          </a>
        </Link>
        
        <Link href="/resources#help">
          <a className="block p-3 bg-gray-50 rounded-lg hover:bg-gray-100">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-primary-100 p-2 rounded-md">
                <HelpCircle className="h-5 w-5 text-primary-600" />
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-gray-900">Get Help</h3>
                <p className="text-xs text-gray-500">Contact your college counselor</p>
              </div>
            </div>
          </a>
        </Link>
      </div>
    </div>
  );
}
