import { useAuth } from '@/components/AuthContext';
import { Check, X, AlertCircle } from 'lucide-react';

export default function ProfileChecklist() {
  const { user } = useAuth();
  
  // Parse extracurriculars from comma-separated string
  const extracurriculars = user?.extracurriculars
    ? user.extracurriculars.split(',').map(item => item.trim()).filter(Boolean)
    : [];
  
  // Helper to determine icon status
  const getStatusIcon = (condition: boolean | undefined, warningCondition?: boolean) => {
    if (condition) {
      return <Check className="h-5 w-5 text-green-500" />;
    } else if (warningCondition) {
      return <AlertCircle className="h-5 w-5 text-yellow-500" />;
    } else {
      return <X className="h-5 w-5 text-red-500" />;
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div className="bg-gray-50 p-4 rounded-md">
        <h3 className="font-medium mb-2 text-gray-900">Academic Information</h3>
        <ul className="space-y-2">
          <li className="flex items-center text-sm">
            {getStatusIcon(!!user?.gpa)}
            <span className="ml-2 text-gray-700">
              {user?.gpa ? `GPA: ${user.gpa}` : 'GPA: Not added'}
            </span>
          </li>
          <li className="flex items-center text-sm">
            {getStatusIcon(!!user?.testScores?.sat)}
            <span className="ml-2 text-gray-700">
              {user?.testScores?.sat ? `SAT: ${user.testScores.sat}` : 'SAT: Not added'}
            </span>
          </li>
          <li className="flex items-center text-sm">
            {getStatusIcon(!!user?.testScores?.act)}
            <span className="ml-2 text-gray-700">
              {user?.testScores?.act ? `ACT: ${user.testScores.act}` : 'ACT: Not added'}
            </span>
          </li>
        </ul>
      </div>
      
      <div className="bg-gray-50 p-4 rounded-md">
        <h3 className="font-medium mb-2 text-gray-900">Extracurricular Activities</h3>
        <ul className="space-y-2">
          {extracurriculars.length > 0 ? (
            extracurriculars.slice(0, 3).map((activity, index) => (
              <li key={index} className="flex items-center text-sm">
                <Check className="h-5 w-5 text-green-500" />
                <span className="ml-2 text-gray-700">{activity}</span>
              </li>
            ))
          ) : (
            <li className="flex items-center text-sm">
              <X className="h-5 w-5 text-red-500" />
              <span className="ml-2 text-gray-700">No activities added</span>
            </li>
          )}
          {extracurriculars.length > 3 && (
            <li className="text-sm text-gray-500 pl-7">
              +{extracurriculars.length - 3} more activities
            </li>
          )}
        </ul>
      </div>
      
      <div className="bg-gray-50 p-4 rounded-md">
        <h3 className="font-medium mb-2 text-gray-900">Required Documents</h3>
        <ul className="space-y-2">
          <li className="flex items-center text-sm">
            {getStatusIcon(false, true)}
            <span className="ml-2 text-gray-700">Personal Statement (Draft)</span>
          </li>
          <li className="flex items-center text-sm">
            {getStatusIcon(true)}
            <span className="ml-2 text-gray-700">Letters of Recommendation</span>
          </li>
          <li className="flex items-center text-sm">
            {getStatusIcon(false)}
            <span className="ml-2 text-gray-700">Transcripts</span>
          </li>
        </ul>
      </div>
    </div>
  );
}
