import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Layout from "@/components/layout";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { College } from "@shared/schema";
import { Loader2, Search, School, MapPin, Award, DollarSign, BookOpen } from "lucide-react";

export default function DiscoverPage() {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [filters, setFilters] = useState({
    gpaMin: 0,
    gpaMax: 4.0,
    selectivity: "all", // all, reach, match, safety
    costMax: 100000,
    region: "all",
  });

  const { data: colleges, isLoading } = useQuery<College[]>({
    queryKey: ["/api/colleges"],
    enabled: !!user,
  });

  const filteredColleges = colleges?.filter(college => {
    // Search term filter
    if (searchTerm && !college.name.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false;
    }
    
    // GPA filter
    if (college.averageGPA && (college.averageGPA < filters.gpaMin || college.averageGPA > filters.gpaMax)) {
      return false;
    }
    
    // Selectivity filter
    if (filters.selectivity !== "all" && college.selectivityCategory !== filters.selectivity) {
      return false;
    }
    
    // Cost filter
    if (college.tuitionCost && college.tuitionCost > filters.costMax) {
      return false;
    }
    
    // Region filter (assuming location contains region information)
    if (filters.region !== "all" && college.location && !college.location.includes(filters.region)) {
      return false;
    }
    
    return true;
  });

  // Mock colleges for initial development
  const mockColleges: College[] = [
    {
      id: 1,
      name: "Harvard University",
      selectivityCategory: "reach",
      averageGPA: 4.0,
      tuitionCost: 54000,
      popularMajors: "Computer Science, Economics, Biology",
      location: "Cambridge, MA",
      size: "Medium",
      acceptanceRate: 0.04,
      website: "https://www.harvard.edu",
      description: "Harvard University is a private Ivy League research university in Cambridge, Massachusetts.",
      createdAt: new Date(),
    },
    {
      id: 2,
      name: "Stanford University",
      selectivityCategory: "reach",
      averageGPA: 3.95,
      tuitionCost: 56000,
      popularMajors: "Engineering, Computer Science, Business",
      location: "Stanford, CA",
      size: "Medium",
      acceptanceRate: 0.04,
      website: "https://www.stanford.edu",
      description: "Stanford University is a private research university in Stanford, California.",
      createdAt: new Date(),
    },
    {
      id: 3,
      name: "University of Michigan",
      selectivityCategory: "match",
      averageGPA: 3.8,
      tuitionCost: 49000,
      popularMajors: "Business, Engineering, Psychology",
      location: "Ann Arbor, MI",
      size: "Large",
      acceptanceRate: 0.23,
      website: "https://www.umich.edu",
      description: "The University of Michigan is a public research university in Ann Arbor, Michigan.",
      createdAt: new Date(),
    },
    {
      id: 4,
      name: "Ohio State University",
      selectivityCategory: "safety",
      averageGPA: 3.6,
      tuitionCost: 32000,
      popularMajors: "Business, Engineering, Health Sciences",
      location: "Columbus, OH",
      size: "Large",
      acceptanceRate: 0.54,
      website: "https://www.osu.edu",
      description: "The Ohio State University is a public research university in Columbus, Ohio.",
      createdAt: new Date(),
    },
  ];

  const displayColleges = filteredColleges || mockColleges;

  const handleAddToMyColleges = (collegeId: number) => {
    // This will be implemented later with API
    console.log(`Adding college ${collegeId} to my list`);
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-col space-y-2">
          <h1 className="text-3xl font-bold">Discover Colleges</h1>
          <p className="text-muted-foreground">
            Find colleges that match your academic profile and interests
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Search and Filter</CardTitle>
            <CardDescription>
              Narrow down colleges based on your preferences
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              <div className="space-y-2">
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search colleges..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Selectivity</Label>
                <Select
                  value={filters.selectivity}
                  onValueChange={(value) => setFilters({ ...filters, selectivity: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="All" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="reach">Reach</SelectItem>
                    <SelectItem value="match">Match</SelectItem>
                    <SelectItem value="safety">Safety</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Region</Label>
                <Select 
                  value={filters.region}
                  onValueChange={(value) => setFilters({ ...filters, region: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="All regions" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All regions</SelectItem>
                    <SelectItem value="Northeast">Northeast</SelectItem>
                    <SelectItem value="Midwest">Midwest</SelectItem>
                    <SelectItem value="South">South</SelectItem>
                    <SelectItem value="West">West</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Max Annual Tuition: ${filters.costMax.toLocaleString()}</Label>
                <Slider
                  value={[filters.costMax]}
                  min={0}
                  max={100000}
                  step={5000}
                  onValueChange={(value) => setFilters({ ...filters, costMax: value[0] })}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-4">
          <h2 className="text-xl font-semibold">Results ({displayColleges.length})</h2>
          
          {isLoading ? (
            <div className="flex justify-center py-10">
              <Loader2 className="h-10 w-10 animate-spin text-primary" />
            </div>
          ) : (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {displayColleges.map((college) => (
                <Card key={college.id} className="overflow-hidden">
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2">
                      <School className="h-5 w-5 text-primary" />
                      {college.name}
                    </CardTitle>
                    <CardDescription className="flex items-center gap-2">
                      <MapPin className="h-4 w-4" />
                      {college.location}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-2 text-sm mb-4">
                      <div className="flex items-center gap-1">
                        <Award className="h-4 w-4 text-muted-foreground" />
                        <span className="text-muted-foreground">Avg GPA:</span>
                        <span className="font-medium">{college.averageGPA}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <DollarSign className="h-4 w-4 text-muted-foreground" />
                        <span className="text-muted-foreground">Tuition:</span>
                        <span className="font-medium">${college.tuitionCost?.toLocaleString()}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <BookOpen className="h-4 w-4 text-muted-foreground" />
                        <span className="text-muted-foreground">Type:</span>
                        <span className="font-medium capitalize">{college.selectivityCategory}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="text-muted-foreground">Accept:</span>
                        <span className="font-medium">{(college.acceptanceRate * 100).toFixed(1)}%</span>
                      </div>
                    </div>
                    <p className="text-sm line-clamp-3">{college.description}</p>
                  </CardContent>
                  <CardFooter className="flex justify-between pt-3 border-t">
                    <Button variant="outline" size="sm" asChild>
                      <a href={college.website} target="_blank" rel="noopener noreferrer">Visit Website</a>
                    </Button>
                    <Button 
                      size="sm"
                      onClick={() => handleAddToMyColleges(college.id)}
                    >
                      Add to My Colleges
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}