import session from "express-session";
import connectPg from "connect-pg-simple";
import { eq, and, gte, lte, desc } from "drizzle-orm";
import { pool, db } from "./db";
import { IStorage } from "./storage";
import {
  User, InsertUser, UpdateUser,
  Client, InsertClient,
  Meeting, InsertMeeting,
  Attendee, InsertAttendee,
  ActionItem, InsertActionItem,
  Document, InsertDocument,
  Report, InsertReport,
  College, InsertCollege,
  StudentProfile, InsertStudentProfile, UpdateStudentProfile,
  UserCollege, InsertUserCollege,
  Deadline, InsertDeadline,
  users, clients, meetings, attendees, actionItems, documents, reports,
  colleges, studentProfiles, userColleges, deadlines
} from "@shared/schema";

// Initialize PostgreSQL session store
const PostgresSessionStore = connectPg(session);

/**
 * Database storage implementation using PostgreSQL and Drizzle ORM
 */
export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    // Create session store with auto table creation
    this.sessionStore = new PostgresSessionStore({ 
      pool,
      createTableIfMissing: true,
    });
  }

  // USER METHODS
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: number, updateData: Partial<UpdateUser>): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set(updateData)
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }

  // CLIENT METHODS
  async getClient(id: number): Promise<Client | undefined> {
    const [client] = await db.select().from(clients).where(eq(clients.id, id));
    return client;
  }

  async getClients(): Promise<Client[]> {
    return await db.select().from(clients);
  }

  async getClientsByPriority(priority: string): Promise<Client[]> {
    return await db.select().from(clients).where(eq(clients.priority, priority));
  }

  async createClient(insertClient: InsertClient): Promise<Client> {
    const [client] = await db.insert(clients).values(insertClient).returning();
    return client;
  }

  async updateClient(id: number, updateData: Partial<Client>): Promise<Client | undefined> {
    const [updatedClient] = await db
      .update(clients)
      .set(updateData)
      .where(eq(clients.id, id))
      .returning();
    return updatedClient;
  }

  async deleteClient(id: number): Promise<boolean> {
    const result = await db.delete(clients).where(eq(clients.id, id));
    return !!result;
  }

  // MEETING METHODS
  async getMeeting(id: number): Promise<Meeting | undefined> {
    const [meeting] = await db.select().from(meetings).where(eq(meetings.id, id));
    return meeting;
  }

  async getMeetings(): Promise<Meeting[]> {
    return await db.select().from(meetings);
  }

  async getMeetingsByUserId(userId: number): Promise<Meeting[]> {
    return await db.select().from(meetings).where(eq(meetings.userId, userId));
  }

  async getMeetingsByClientId(clientId: number): Promise<Meeting[]> {
    return await db.select().from(meetings).where(eq(meetings.clientId, clientId));
  }

  async getMeetingsByStatus(status: string): Promise<Meeting[]> {
    return await db.select().from(meetings).where(eq(meetings.status, status));
  }

  async getMeetingsByDateRange(startDate: Date, endDate: Date): Promise<Meeting[]> {
    return await db
      .select()
      .from(meetings)
      .where(
        and(
          gte(meetings.startDate, startDate),
          lte(meetings.startDate, endDate)
        )
      );
  }

  async createMeeting(insertMeeting: InsertMeeting): Promise<Meeting> {
    const [meeting] = await db.insert(meetings).values(insertMeeting).returning();
    return meeting;
  }

  async updateMeeting(id: number, updateData: Partial<Meeting>): Promise<Meeting | undefined> {
    const [updatedMeeting] = await db
      .update(meetings)
      .set(updateData)
      .where(eq(meetings.id, id))
      .returning();
    return updatedMeeting;
  }

  async deleteMeeting(id: number): Promise<boolean> {
    const result = await db.delete(meetings).where(eq(meetings.id, id));
    return !!result;
  }

  // ATTENDEE METHODS
  async getAttendeesByMeetingId(meetingId: number): Promise<Attendee[]> {
    return await db.select().from(attendees).where(eq(attendees.meetingId, meetingId));
  }

  async createAttendee(insertAttendee: InsertAttendee): Promise<Attendee> {
    const [attendee] = await db.insert(attendees).values(insertAttendee).returning();
    return attendee;
  }

  async updateAttendee(id: number, updateData: Partial<Attendee>): Promise<Attendee | undefined> {
    const [updatedAttendee] = await db
      .update(attendees)
      .set(updateData)
      .where(eq(attendees.id, id))
      .returning();
    return updatedAttendee;
  }

  async deleteAttendee(id: number): Promise<boolean> {
    const result = await db.delete(attendees).where(eq(attendees.id, id));
    return !!result;
  }

  // ACTION ITEM METHODS
  async getActionItem(id: number): Promise<ActionItem | undefined> {
    const [actionItem] = await db.select().from(actionItems).where(eq(actionItems.id, id));
    return actionItem;
  }

  async getActionItemsByMeetingId(meetingId: number): Promise<ActionItem[]> {
    return await db.select().from(actionItems).where(eq(actionItems.meetingId, meetingId));
  }

  async getActionItemsByAssignedTo(userId: number): Promise<ActionItem[]> {
    return await db.select().from(actionItems).where(eq(actionItems.assignedTo, userId));
  }

  async getActionItemsByStatus(status: string): Promise<ActionItem[]> {
    return await db.select().from(actionItems).where(eq(actionItems.status, status));
  }

  async createActionItem(insertActionItem: InsertActionItem): Promise<ActionItem> {
    const [actionItem] = await db.insert(actionItems).values(insertActionItem).returning();
    return actionItem;
  }

  async updateActionItem(id: number, updateData: Partial<ActionItem>): Promise<ActionItem | undefined> {
    const [updatedActionItem] = await db
      .update(actionItems)
      .set(updateData)
      .where(eq(actionItems.id, id))
      .returning();
    return updatedActionItem;
  }

  async deleteActionItem(id: number): Promise<boolean> {
    const result = await db.delete(actionItems).where(eq(actionItems.id, id));
    return !!result;
  }

  // DOCUMENT METHODS
  async getDocument(id: number): Promise<Document | undefined> {
    const [document] = await db.select().from(documents).where(eq(documents.id, id));
    return document;
  }

  async getDocumentsByClientId(clientId: number): Promise<Document[]> {
    return await db.select().from(documents).where(eq(documents.clientId, clientId));
  }

  async getDocumentsByMeetingId(meetingId: number): Promise<Document[]> {
    return await db.select().from(documents).where(eq(documents.meetingId, meetingId));
  }

  async createDocument(insertDocument: InsertDocument): Promise<Document> {
    const [document] = await db.insert(documents).values(insertDocument).returning();
    return document;
  }

  async updateDocument(id: number, updateData: Partial<Document>): Promise<Document | undefined> {
    const [updatedDocument] = await db
      .update(documents)
      .set(updateData)
      .where(eq(documents.id, id))
      .returning();
    return updatedDocument;
  }

  async deleteDocument(id: number): Promise<boolean> {
    const result = await db.delete(documents).where(eq(documents.id, id));
    return !!result;
  }

  // REPORT METHODS
  async getReport(id: number): Promise<Report | undefined> {
    const [report] = await db.select().from(reports).where(eq(reports.id, id));
    return report;
  }

  async getReportsByUserId(userId: number): Promise<Report[]> {
    return await db.select().from(reports).where(eq(reports.userId, userId));
  }

  async createReport(insertReport: InsertReport): Promise<Report> {
    const [report] = await db.insert(reports).values(insertReport).returning();
    return report;
  }

  async updateReport(id: number, updateData: Partial<Report>): Promise<Report | undefined> {
    const [updatedReport] = await db
      .update(reports)
      .set(updateData)
      .where(eq(reports.id, id))
      .returning();
    return updatedReport;
  }

  async deleteReport(id: number): Promise<boolean> {
    const result = await db.delete(reports).where(eq(reports.id, id));
    return !!result;
  }

  // COLLEGE METHODS
  async getCollege(id: number): Promise<College | undefined> {
    const [college] = await db.select().from(colleges).where(eq(colleges.id, id));
    return college;
  }

  async getColleges(): Promise<College[]> {
    return await db.select().from(colleges);
  }

  async getCollegesBySelectivity(selectivity: string): Promise<College[]> {
    return await db.select().from(colleges).where(eq(colleges.selectivityCategory, selectivity));
  }

  async createCollege(insertCollege: InsertCollege): Promise<College> {
    const [college] = await db.insert(colleges).values(insertCollege).returning();
    return college;
  }

  async updateCollege(id: number, updateData: Partial<College>): Promise<College | undefined> {
    const [updatedCollege] = await db
      .update(colleges)
      .set(updateData)
      .where(eq(colleges.id, id))
      .returning();
    return updatedCollege;
  }

  async deleteCollege(id: number): Promise<boolean> {
    const result = await db.delete(colleges).where(eq(colleges.id, id));
    return !!result;
  }

  // STUDENT PROFILE METHODS
  async getStudentProfile(userId: number): Promise<StudentProfile | undefined> {
    const [profile] = await db.select().from(studentProfiles).where(eq(studentProfiles.userId, userId));
    return profile;
  }

  async createStudentProfile(insertProfile: InsertStudentProfile): Promise<StudentProfile> {
    const [profile] = await db.insert(studentProfiles).values(insertProfile).returning();
    return profile;
  }

  async updateStudentProfile(userId: number, updateData: Partial<UpdateStudentProfile>): Promise<StudentProfile | undefined> {
    const [updatedProfile] = await db
      .update(studentProfiles)
      .set(updateData)
      .where(eq(studentProfiles.userId, userId))
      .returning();
    return updatedProfile;
  }

  // USER COLLEGE METHODS
  async getUserColleges(userId: number): Promise<(UserCollege & { college: College })[]> {
    const results = await db
      .select({
        userCollege: userColleges,
        college: colleges
      })
      .from(userColleges)
      .leftJoin(colleges, eq(userColleges.collegeId, colleges.id))
      .where(eq(userColleges.userId, userId));
    
    return results.map(item => ({
      ...item.userCollege,
      college: item.college
    }));
  }

  async createUserCollege(insertUserCollege: InsertUserCollege): Promise<UserCollege> {
    const [userCollege] = await db.insert(userColleges).values(insertUserCollege).returning();
    return userCollege;
  }

  async updateUserCollege(id: number, updateData: Partial<UserCollege>): Promise<UserCollege | undefined> {
    const [updatedUserCollege] = await db
      .update(userColleges)
      .set(updateData)
      .where(eq(userColleges.id, id))
      .returning();
    return updatedUserCollege;
  }

  async deleteUserCollege(id: number): Promise<boolean> {
    const result = await db.delete(userColleges).where(eq(userColleges.id, id));
    return !!result;
  }

  // DEADLINE METHODS
  async getDeadline(id: number): Promise<Deadline | undefined> {
    const [deadline] = await db.select().from(deadlines).where(eq(deadlines.id, id));
    return deadline;
  }

  async getDeadlinesByUserId(userId: number): Promise<(Deadline & { college: College })[]> {
    const results = await db
      .select({
        deadline: deadlines,
        college: colleges
      })
      .from(deadlines)
      .leftJoin(colleges, eq(deadlines.collegeId, colleges.id))
      .where(eq(deadlines.userId, userId))
      .orderBy(deadlines.dueDate);
    
    return results.map(item => ({
      ...item.deadline,
      college: item.college
    }));
  }

  async getUpcomingDeadlines(userId: number, limit: number = 5): Promise<(Deadline & { college: College })[]> {
    const today = new Date();
    
    const results = await db
      .select({
        deadline: deadlines,
        college: colleges
      })
      .from(deadlines)
      .leftJoin(colleges, eq(deadlines.collegeId, colleges.id))
      .where(
        and(
          eq(deadlines.userId, userId),
          gte(deadlines.dueDate, today),
          eq(deadlines.isCompleted, false)
        )
      )
      .orderBy(deadlines.dueDate)
      .limit(limit);
    
    return results.map(item => ({
      ...item.deadline,
      college: item.college
    }));
  }

  async createDeadline(insertDeadline: InsertDeadline): Promise<Deadline> {
    const [deadline] = await db.insert(deadlines).values(insertDeadline).returning();
    return deadline;
  }

  async updateDeadline(id: number, updateData: Partial<Deadline>): Promise<Deadline | undefined> {
    const [updatedDeadline] = await db
      .update(deadlines)
      .set(updateData)
      .where(eq(deadlines.id, id))
      .returning();
    return updatedDeadline;
  }

  async deleteDeadline(id: number): Promise<boolean> {
    const result = await db.delete(deadlines).where(eq(deadlines.id, id));
    return !!result;
  }

  // DATA INITIALIZATION - FOR DEVELOPMENT ONLY
  async initializeCollegeSampleData(): Promise<void> {
    // Check if we already have sample colleges
    const existingColleges = await this.getColleges();
    if (existingColleges.length > 0) return;

    // Sample college data
    const sampleColleges = [
      {
        name: "Harvard University",
        selectivityCategory: "reach",
        averageGPA: 4.0,
        tuitionCost: 54000,
        popularMajors: "Computer Science, Economics, Biology",
        location: "Cambridge, MA",
        size: "Medium",
        acceptanceRate: 0.04,
        website: "https://www.harvard.edu",
        description: "Harvard University is a private Ivy League research university in Cambridge, Massachusetts."
      },
      {
        name: "Stanford University",
        selectivityCategory: "reach",
        averageGPA: 3.95,
        tuitionCost: 56000,
        popularMajors: "Engineering, Computer Science, Business",
        location: "Stanford, CA",
        size: "Medium",
        acceptanceRate: 0.04,
        website: "https://www.stanford.edu",
        description: "Stanford University is a private research university in Stanford, California."
      },
      {
        name: "University of Michigan",
        selectivityCategory: "match",
        averageGPA: 3.8,
        tuitionCost: 49000,
        popularMajors: "Business, Engineering, Psychology",
        location: "Ann Arbor, MI",
        size: "Large",
        acceptanceRate: 0.23,
        website: "https://www.umich.edu",
        description: "The University of Michigan is a public research university in Ann Arbor, Michigan."
      },
      {
        name: "Ohio State University",
        selectivityCategory: "safety",
        averageGPA: 3.6,
        tuitionCost: 32000,
        popularMajors: "Business, Engineering, Health Sciences",
        location: "Columbus, OH",
        size: "Large",
        acceptanceRate: 0.54,
        website: "https://www.osu.edu",
        description: "The Ohio State University is a public research university in Columbus, Ohio."
      },
      {
        name: "Cornell University",
        selectivityCategory: "reach",
        averageGPA: 3.9,
        tuitionCost: 59000,
        popularMajors: "Agriculture, Engineering, Hospitality Management",
        location: "Ithaca, NY",
        size: "Medium",
        acceptanceRate: 0.11,
        website: "https://www.cornell.edu",
        description: "Cornell University is a private Ivy League and statutory land-grant research university based in Ithaca, New York."
      },
      {
        name: "University of California, Berkeley",
        selectivityCategory: "match",
        averageGPA: 3.89,
        tuitionCost: 44000,
        popularMajors: "Computer Science, Economics, Political Science",
        location: "Berkeley, CA",
        size: "Large",
        acceptanceRate: 0.16,
        website: "https://www.berkeley.edu",
        description: "The University of California, Berkeley is a public research university in Berkeley, California."
      },
      {
        name: "University of Florida",
        selectivityCategory: "match",
        averageGPA: 3.7,
        tuitionCost: 28000,
        popularMajors: "Business, Engineering, Biology",
        location: "Gainesville, FL",
        size: "Large",
        acceptanceRate: 0.31,
        website: "https://www.ufl.edu",
        description: "The University of Florida is a public land-grant research university in Gainesville, Florida."
      },
      {
        name: "Arizona State University",
        selectivityCategory: "safety",
        averageGPA: 3.5,
        tuitionCost: 29000,
        popularMajors: "Business, Engineering, Communications",
        location: "Tempe, AZ",
        size: "Large",
        acceptanceRate: 0.86,
        website: "https://www.asu.edu",
        description: "Arizona State University is a public research university in the Phoenix metropolitan area."
      }
    ];

    for (const college of sampleColleges) {
      await this.createCollege(college);
    }
  }

  async initializeUserSampleData(): Promise<void> {
    // Check if we already have sample users
    const existingUsers = await this.getUsers();
    if (existingUsers.length > 0) return;

    // Sample user data
    await this.createUser({
      username: "admin",
      password: "password",
      name: "Admin User",
      role: "admin",
      department: "Management",
      email: "admin@yourcollegeplug.com",
      phone: "555-123-4567",
      profileCompleted: 100
    });

    await this.createUser({
      username: "counselor",
      password: "password",
      name: "College Counselor",
      role: "counselor",
      department: "Academic Affairs",
      email: "counselor@yourcollegeplug.com",
      phone: "555-234-5678",
      profileCompleted: 100
    });

    await this.createUser({
      username: "student",
      password: "password",
      name: "Jane Student",
      role: "student",
      email: "student@example.com",
      profileCompleted: 85
    });
  }
}