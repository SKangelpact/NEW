import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import {
  PlusCircle,
  Search,
  Filter,
  Briefcase,
  Phone,
  Mail,
  User,
  Building,
  AlertCircle,
  ArrowUpDown,
  MoreHorizontal,
  ChevronDown,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Client } from "@shared/schema";

export default function ClientsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [priorityFilter, setPriorityFilter] = useState<string | null>(null);
  const [industryFilter, setIndustryFilter] = useState<string | null>(null);

  const { data: clients, isLoading } = useQuery<Client[]>({
    queryKey: ["/api/clients"],
  });

  // Get unique industry values for the filter
  const industries = clients
    ? [...new Set(clients.map((client) => client.industry).filter(Boolean))]
    : [];

  // Filter clients based on search term and filters
  const filteredClients = clients
    ? clients.filter((client) => {
        // Search filter
        const searchMatch =
          !searchTerm ||
          client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          (client.contactPerson &&
            client.contactPerson.toLowerCase().includes(searchTerm.toLowerCase())) ||
          (client.email &&
            client.email.toLowerCase().includes(searchTerm.toLowerCase()));

        // Priority filter
        const priorityMatch = !priorityFilter || client.priority === priorityFilter;

        // Industry filter
        const industryMatch =
          !industryFilter || client.industry === industryFilter;

        return searchMatch && priorityMatch && industryMatch;
      })
    : [];

  // Function to render priority badge
  const getPriorityBadge = (priority: string | null) => {
    if (!priority) return null;
    
    switch (priority.toLowerCase()) {
      case "high":
        return <Badge variant="outline" className="bg-red-50 text-red-700 hover:bg-red-50">High</Badge>;
      case "medium":
        return <Badge variant="outline" className="bg-amber-50 text-amber-700 hover:bg-amber-50">Medium</Badge>;
      case "low":
        return <Badge variant="outline" className="bg-green-50 text-green-700 hover:bg-green-50">Low</Badge>;
      default:
        return <Badge variant="outline">{priority}</Badge>;
    }
  };

  return (
    <div className="space-y-6 p-6">
      <div className="flex flex-col space-y-2">
        <h1 className="text-3xl font-bold tracking-tight">Clients</h1>
        <p className="text-muted-foreground">
          Manage and track your procurement clients
        </p>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
          <div className="relative w-full sm:w-[280px]">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search clients..."
              className="pl-8 w-full"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="flex gap-2 w-full sm:w-auto">
            <Select
              value={priorityFilter || ""}
              onValueChange={(value) => setPriorityFilter(value || null)}
            >
              <SelectTrigger className="w-full sm:w-[180px]">
                <div className="flex items-center gap-2">
                  <Filter className="h-4 w-4" />
                  <SelectValue placeholder="Priority" />
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Priorities</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="low">Low</SelectItem>
              </SelectContent>
            </Select>

            <Select
              value={industryFilter || ""}
              onValueChange={(value) => setIndustryFilter(value || null)}
            >
              <SelectTrigger className="w-full sm:w-[180px]">
                <div className="flex items-center gap-2">
                  <Building className="h-4 w-4" />
                  <SelectValue placeholder="Industry" />
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Industries</SelectItem>
                {industries.map((industry) => (
                  <SelectItem key={industry} value={industry || ""}>
                    {industry}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <Link href="/clients/new">
          <Button>
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Client
          </Button>
        </Link>
      </div>

      {isLoading ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {Array(6)
            .fill(null)
            .map((_, i) => (
              <Card key={i} className="overflow-hidden">
                <CardHeader className="p-6">
                  <Skeleton className="h-6 w-32 mb-2" />
                  <Skeleton className="h-4 w-24" />
                </CardHeader>
                <CardContent className="p-6 pt-0 space-y-3">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-1/2" />
                </CardContent>
              </Card>
            ))}
        </div>
      ) : filteredClients.length > 0 ? (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[300px]">
                  <div className="flex items-center gap-1">
                    Client 
                    <ArrowUpDown className="ml-1 h-3 w-3" />
                  </div>
                </TableHead>
                <TableHead>Contact Person</TableHead>
                <TableHead>Industry</TableHead>
                <TableHead>Priority</TableHead>
                <TableHead>Contact</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredClients.map((client) => (
                <TableRow key={client.id}>
                  <TableCell className="font-medium">
                    <Link href={`/clients/${client.id}`}>
                      <div className="flex items-center gap-2 hover:underline cursor-pointer">
                        <Briefcase className="h-4 w-4 text-muted-foreground" />
                        {client.name}
                      </div>
                    </Link>
                  </TableCell>
                  <TableCell>
                    {client.contactPerson ? (
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4 text-muted-foreground" />
                        {client.contactPerson}
                      </div>
                    ) : (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell>
                    {client.industry || <span className="text-muted-foreground">—</span>}
                  </TableCell>
                  <TableCell>
                    {getPriorityBadge(client.priority)}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      {client.email && (
                        <Button variant="ghost" size="icon" asChild>
                          <a href={`mailto:${client.email}`} title={client.email}>
                            <Mail className="h-4 w-4" />
                          </a>
                        </Button>
                      )}
                      {client.phone && (
                        <Button variant="ghost" size="icon" asChild>
                          <a href={`tel:${client.phone}`} title={client.phone}>
                            <Phone className="h-4 w-4" />
                          </a>
                        </Button>
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">Open menu</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem asChild>
                          <Link href={`/clients/${client.id}`}>View Details</Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem asChild>
                          <Link href={`/clients/${client.id}/edit`}>Edit Client</Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem asChild>
                          <Link href={`/meetings/new?clientId=${client.id}`}>Schedule Meeting</Link>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center rounded-lg border border-dashed p-8 text-center">
          <div className="rounded-full bg-primary/10 p-3 text-primary">
            <Briefcase className="h-6 w-6" />
          </div>
          <h3 className="mt-4 text-lg font-semibold">No clients found</h3>
          <p className="mt-2 text-sm text-muted-foreground">
            {searchTerm || priorityFilter || industryFilter
              ? "Try adjusting your search or filters"
              : "Get started by adding a new client"}
          </p>
          <Link href="/clients/new">
            <Button className="mt-4">
              <PlusCircle className="mr-2 h-4 w-4" />
              Add Client
            </Button>
          </Link>
        </div>
      )}
    </div>
  );
}